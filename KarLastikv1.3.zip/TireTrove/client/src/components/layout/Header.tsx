import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/components/auth/AuthProvider';
import { useWishlist } from '@/hooks/useWishlist';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, Heart, User, ShoppingCart, Menu, X, Camera, 
  LogOut, Settings, Package, UserCircle 
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useSearch } from '@/contexts/SearchContext';
import { useToast } from '@/hooks/use-toast';

const Header = () => {
  const [location, setLocation] = useLocation();
  const { cart } = useCart();
  const { user, logoutMutation } = useAuth();
  const { wishlistItems } = useWishlist();
  const { setSearchQuery } = useSearch();
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [showPhotoSearch, setShowPhotoSearch] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        toast({
          title: "Logged out successfully",
          description: "You have been logged out of your account",
        });
        setLocation('/');
      },
      onError: (error) => {
        toast({
          title: "Logout failed",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchInput.trim()) return;
    
    // Check if the searchInput exactly matches a brand name (case insensitive)
    try {
      const brandResponse = await fetch('/api/brands');
      const brands = await brandResponse.json();
      
      const normalizedSearch = searchInput.trim().toLowerCase();
      const exactBrandMatch = brands.find((b: any) => 
        b.name.toLowerCase() === normalizedSearch
      );
      
      if (exactBrandMatch) {
        // If it's an exact brand match, navigate to the brand-specific page
        setLocation(`/products?brand=${exactBrandMatch.name}`);
        // Clear any existing search
        setSearchQuery('');
        setSearchInput('');
      } else {
        // Otherwise, do a regular search
        localStorage.setItem('lastSearchQuery', normalizedSearch);
        setSearchQuery(searchInput);
        setLocation('/products');
      }
    } catch (error) {
      // If there's an error fetching brands, just do a regular search
      setSearchQuery(searchInput);
      setLocation('/products');
    }
  };

  const toggleCartSidebar = () => {
    const event = new CustomEvent('toggleCart');
    window.dispatchEvent(event);
  };
  
  const handlePhotoSearch = () => {
    setLocation('/photo-search');
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 md:hidden"
          onClick={() => setMobileMenuOpen(false)}
        ></div>
      )}
      {/* Top Bar */}
      <div className="bg-primary text-white px-4 py-2">
        <div className="container mx-auto flex justify-between items-center">
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/store-locator" className="text-sm hover:underline">
              <i className="fa-solid fa-location-dot mr-1"></i> Find a Store
            </Link>
            <Link href="/contact" className="text-sm hover:underline">
              <i className="fa-solid fa-phone mr-1"></i> 1-800-TIRE-HUB
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/become-seller" className="text-sm hover:underline">Sell on TireHub</Link>
            <Link href="/track-order" className="text-sm hover:underline">Track Order</Link>
            <Link href="/help-center" className="text-sm hover:underline">Help</Link>
          </div>
        </div>
      </div>
      
      {/* Mobile Header */}
      <div className="md:hidden container mx-auto px-4 py-2 flex items-center justify-between">
        <div className="flex items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-neutral-700 p-2"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
          <Link href="/" className="text-2xl font-bold flex items-center ml-2">
            <span className="text-black">KAR</span>
            <span className="text-red-600">LASTIK</span>
          </Link>
        </div>
        <div className="flex items-center space-x-4">
          <Link href="/wishlist" className="text-neutral-700 hover:text-primary relative">
            <Heart className="h-5 w-5" />
            {wishlistItems && wishlistItems.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-secondary text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                {wishlistItems.length}
              </span>
            )}
          </Link>
          {user ? (
            <Link href="/account" className="text-neutral-700 hover:text-primary">
              <UserCircle className="h-5 w-5" />
            </Link>
          ) : (
            <Link href="/auth" className="text-neutral-700 hover:text-primary">
              <User className="h-5 w-5" />
            </Link>
          )}
          <button 
            onClick={toggleCartSidebar}
            className="text-neutral-700 hover:text-primary relative"
          >
            <ShoppingCart className="h-5 w-5" />
            <span className="absolute -top-2 -right-2 bg-secondary text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              {cart.length}
            </span>
          </button>
        </div>
      </div>
      
      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          {/* Logo - visible only on md and up */}
          <div className="hidden md:flex items-center mb-4 md:mb-0">
            <Link href="/" className="text-3xl font-bold flex items-center">
              <span className="text-black">KAR</span>
              <span className="text-red-600">LASTIK</span>
            </Link>
          </div>
          
          {/* Search Bar */}
          <div className="w-full md:w-1/2 lg:w-2/5">
            <form onSubmit={handleSearchSubmit} className="relative">
              <div className="relative flex items-center">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 z-10">
                  <Button 
                    type="button"
                    variant="ghost" 
                    size="icon"
                    onClick={handlePhotoSearch}
                    className="p-0 h-5 w-5 hover:bg-transparent focus:bg-transparent"
                  >
                    <Camera className="h-4 w-4 text-neutral-500 hover:text-primary transition-colors" />
                  </Button>
                </div>
                <Input
                  type="text"
                  placeholder="Search by brand (Michelin, Goodyear...) or tire model"
                  className="w-full py-2 pl-10 pr-10"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                />
                <Button 
                  type="submit"
                  variant="ghost" 
                  size="icon"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 text-neutral-500 hover:text-primary"
                >
                  <Search className="h-5 w-5" />
                </Button>
              </div>
            </form>
          </div>
          
          {/* User Actions - only visible on medium screens and up */}
          <div className="hidden md:flex items-center mt-4 md:mt-0 space-x-6">
            <Link href="/wishlist" className="text-neutral-700 hover:text-primary relative">
              <Heart className="h-6 w-6" />
              {wishlistItems && wishlistItems.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-secondary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {wishlistItems.length}
                </span>
              )}
            </Link>
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="text-neutral-700 hover:text-primary focus:outline-none">
                    <UserCircle className="h-6 w-6" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.username}</p>
                      <p className="text-xs leading-none text-neutral-500">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/account?tab=profile" className="cursor-pointer">
                      <UserCircle className="mr-2 h-4 w-4" />
                      <span>My Account</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/account?tab=orders" className="cursor-pointer">
                      <Package className="mr-2 h-4 w-4" />
                      <span>My Orders</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/account?tab=settings" className="cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Account Settings</span>
                    </Link>
                  </DropdownMenuItem>

                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="cursor-pointer" onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth" className="text-neutral-700 hover:text-primary">
                <User className="h-6 w-6" />
              </Link>
            )}
            <button 
              onClick={toggleCartSidebar}
              className="text-neutral-700 hover:text-primary relative"
            >
              <ShoppingCart className="h-6 w-6" />
              <span className="absolute -top-2 -right-2 bg-secondary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {cart.length}
              </span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="bg-white border-t border-neutral-200">
        <div className="container mx-auto px-4">
          {/* Mobile Navigation */}
          <div 
            className={`fixed inset-y-0 left-0 transform ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} 
                        md:hidden bg-white z-50 w-4/5 max-w-sm overflow-y-auto transition duration-200 ease-in-out shadow-xl`}
          >
            <div className="p-4 border-b border-neutral-200 flex justify-between items-center bg-white">
              <h2 className="font-bold text-xl tracking-wider">
                <span className="text-black">KAR</span>
                <span className="text-red-600">LASTIK</span>
              </h2>
              <button 
                onClick={() => setMobileMenuOpen(false)} 
                className="p-1 rounded-full hover:bg-neutral-100 text-black"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <ul className="flex flex-col divide-y divide-neutral-100">
              <li>
                <Link 
                  href="/#shop-by-vehicle" 
                  className="block px-4 py-3 font-medium hover:bg-neutral-50 hover:text-primary flex items-center justify-between"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>Shop By Vehicle</span>
                  <span className="text-neutral-400">›</span>
                </Link>
              </li>
              <li>
                <Link 
                  href="/products?type=all-season" 
                  className="block px-4 py-3 font-medium hover:bg-neutral-50 hover:text-primary flex items-center justify-between"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>All Season Tires</span>
                  <span className="text-neutral-400">›</span>
                </Link>
              </li>
              <li>
                <Link 
                  href="/products?type=winter" 
                  className="block px-4 py-3 font-medium hover:bg-neutral-50 hover:text-primary flex items-center justify-between"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>Winter Tires</span>
                  <span className="text-neutral-400">›</span>
                </Link>
              </li>
              <li>
                <Link 
                  href="/products?type=performance" 
                  className="block px-4 py-3 font-medium hover:bg-neutral-50 hover:text-primary flex items-center justify-between"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>Performance Tires</span>
                  <span className="text-neutral-400">›</span>
                </Link>
              </li>
              <li>
                <Link 
                  href="/products?type=truck-suv" 
                  className="block px-4 py-3 font-medium hover:bg-neutral-50 hover:text-primary flex items-center justify-between"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>Truck & SUV</span>
                  <span className="text-neutral-400">›</span>
                </Link>
              </li>
              <li>
                <Link 
                  href="/products?brand=all" 
                  className="block px-4 py-3 font-medium hover:bg-neutral-50 hover:text-primary flex items-center justify-between"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>Brands</span>
                  <span className="text-neutral-400">›</span>
                </Link>
              </li>
              <li>
                <Link 
                  href="/products?deals=true" 
                  className="block px-4 py-3 font-medium text-secondary hover:bg-neutral-50 flex items-center justify-between"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>Deals</span>
                  <span className="text-secondary">›</span>
                </Link>
              </li>

            </ul>
            <div className="border-t border-neutral-200 mt-2">
              <h3 className="font-semibold text-neutral-600 px-4 pt-4 pb-2">Customer Service</h3>
              <div className="flex flex-col">
                <Link 
                  href="/store-locator" 
                  className="px-4 py-2 text-sm text-neutral-600 hover:text-primary hover:bg-neutral-50 flex items-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="mr-3 text-primary">📍</span> Find a Store
                </Link>
                <Link 
                  href="/contact" 
                  className="px-4 py-2 text-sm text-neutral-600 hover:text-primary hover:bg-neutral-50 flex items-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="mr-3 text-primary">📱</span> 1-800-TIRE-HUB
                </Link>
                <Link 
                  href="/track-order"
                  className="px-4 py-2 text-sm text-neutral-600 hover:text-primary hover:bg-neutral-50 flex items-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="mr-3 text-primary">📦</span> Track Your Order
                </Link>
                <Link 
                  href="/help-center" 
                  className="px-4 py-2 text-sm text-neutral-600 hover:text-primary hover:bg-neutral-50 flex items-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="mr-3 text-primary">📧</span> Support & Help
                </Link>
              </div>
            </div>
            
            <div className="border-t border-neutral-200 py-4 px-4 flex justify-between items-center bg-neutral-50">
              {user ? (
                <div className="w-full">
                  <div className="flex items-center mb-3">
                    <UserCircle className="h-5 w-5 text-primary mr-2" />
                    <div>
                      <p className="text-sm font-medium">{user.username}</p>
                      <p className="text-xs text-neutral-500">{user.email}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Link 
                      href="/account?tab=profile" 
                      onClick={() => setMobileMenuOpen(false)}
                      className="text-sm text-center py-1.5 px-2 bg-primary text-white rounded-md hover:bg-primary/90"
                    >
                      My Account
                    </Link>
                    <button 
                      onClick={() => {
                        setMobileMenuOpen(false);
                        handleLogout();
                      }}
                      className="text-sm py-1.5 px-2 border border-neutral-300 rounded-md hover:bg-neutral-100"
                    >
                      Sign Out
                    </button>
                  </div>

                </div>
              ) : (
                <div className="space-x-3">
                  <Link href="/auth" onClick={() => setMobileMenuOpen(false)} className="text-neutral-600 hover:text-primary">
                    <span className="font-semibold">Log In</span>
                  </Link>
                  <span className="text-neutral-400">|</span>
                  <Link href="/auth" onClick={() => setMobileMenuOpen(false)} className="text-primary hover:text-primary/80">
                    <span className="font-semibold">Sign Up</span>
                  </Link>
                </div>
              )}
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <ul className="hidden md:flex overflow-x-auto space-x-4 py-2 text-base flex-row">
            <li>
              <Link href="/#shop-by-vehicle" className="block px-2 py-2 font-medium hover:text-primary whitespace-nowrap">
                Shop By Vehicle
              </Link>
            </li>
            <li>
              <Link href="/products?type=all-season" className="block px-2 py-2 font-medium hover:text-primary whitespace-nowrap">
                All Season Tires
              </Link>
            </li>
            <li>
              <Link href="/products?type=winter" className="block px-2 py-2 font-medium hover:text-primary whitespace-nowrap">
                Winter Tires
              </Link>
            </li>
            <li>
              <Link href="/products?type=performance" className="block px-2 py-2 font-medium hover:text-primary whitespace-nowrap">
                Performance Tires
              </Link>
            </li>
            <li>
              <Link href="/products?type=truck-suv" className="block px-2 py-2 font-medium hover:text-primary whitespace-nowrap">
                Truck & SUV
              </Link>
            </li>
            <li>
              <Link href="/products?brand=all" className="block px-2 py-2 font-medium hover:text-primary whitespace-nowrap">
                Brands
              </Link>
            </li>
            <li>
              <Link href="/products?deals=true" className="block px-2 py-2 font-medium text-secondary whitespace-nowrap">
                Deals
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;

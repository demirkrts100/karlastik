import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import ProductListingPage from "@/pages/ProductListingPage";
import ProductDetailPage from "@/pages/ProductDetailPage";
import CheckoutPage from "@/pages/CheckoutPage";
import AuthPage from "@/pages/AuthPage";
import AccountPage from "@/pages/AccountPage"; 
import ResetPasswordPage from "@/pages/ResetPasswordPage";
import TrackOrderPage from "@/pages/TrackOrderPage";
import WishlistPage from "@/pages/WishlistPage";
import AdminLoginPage from "@/pages/AdminLoginPage";
import AdminPage from "@/pages/admin/AdminPage";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import CartSidebar from "@/components/cart/CartSidebar";
import WhatsAppButton from "@/components/shared/WhatsAppButton";
import AIAssistant from "@/components/shared/AIAssistant";
import { CartProvider } from "./contexts/CartContext";
import { AuthProvider } from "@/components/auth/AuthProvider";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { useAuth } from "@/components/auth/AuthProvider";
import { useEffect } from "react";

// Admin route component that requires admin role
const AdminRoute = ({ component: Component, ...rest }: { component: () => React.JSX.Element, path: string }) => {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin')) {
      setLocation("/admin/login");
    }
  }, [user, isLoading, setLocation]);
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-neutral-800 border-t-transparent"></div>
      </div>
    );
  }
  
  if (!user || user.role !== 'admin') {
    return null;
  }
  
  return <Component />;
};

// Customer-facing site router
function CustomerRouter() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/products" component={ProductListingPage} />
      <Route path="/product/:id" component={ProductDetailPage} />
      <ProtectedRoute path="/checkout" component={CheckoutPage} />
      <ProtectedRoute path="/account" component={AccountPage} />
      <ProtectedRoute path="/wishlist" component={WishlistPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/reset-password" component={ResetPasswordPage} />
      <Route path="/track-order" component={TrackOrderPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Admin site router
function AdminRouter() {
  return (
    <Switch>
      <Route path="/admin/login" component={AdminLoginPage} />
      <AdminRoute path="/admin" component={() => <AdminPage />} />
      <AdminRoute path="/admin/orders" component={() => <AdminPage />} />
      <AdminRoute path="/admin/products" component={() => <AdminPage />} />
      <AdminRoute path="/admin/reviews" component={() => <AdminPage />} />
      <AdminRoute path="/admin/users" component={() => <AdminPage />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [location] = useLocation();
  const isAdminSite = location.startsWith("/admin");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <CartProvider>
            {isAdminSite ? (
              // Admin Interface
              <div className="flex flex-col min-h-screen">
                <main className="flex-grow">
                  <AdminRouter />
                </main>
              </div>
            ) : (
              // Customer Interface
              <div className="flex flex-col min-h-screen">
                <Header />
                <main className="flex-grow">
                  <CustomerRouter />
                </main>
                <Footer />
                <CartSidebar />
                <WhatsAppButton phoneNumber="1234567890" message="Hello! I'm interested in your tire products." />
              </div>
            )}
          </CartProvider>
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

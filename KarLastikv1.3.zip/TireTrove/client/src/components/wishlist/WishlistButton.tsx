import { Button } from "@/components/ui/button";
import { useWishlist } from "@/hooks/useWishlist";
import { useAuth } from "@/components/auth/AuthProvider";
import { Heart, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface WishlistButtonProps {
  tireId: number;
  variant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive";
  size?: "default" | "sm" | "lg" | "icon";
  className?: string;
}

export function WishlistButton({
  tireId,
  variant = "outline",
  size = "icon",
  className = "",
}: WishlistButtonProps) {
  const { user } = useAuth();
  const { isInWishlist, getWishlistItemByTireId, addToWishlist, removeFromWishlist, isAddingToWishlist, isRemovingFromWishlist } = useWishlist();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const isInUserWishlist = isInWishlist(tireId);
  const wishlistItem = getWishlistItemByTireId(tireId);
  const isLoading = isAddingToWishlist || isRemovingFromWishlist;

  const handleWishlistAction = () => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to add items to your wishlist",
        variant: "default",
      });
      navigate("/auth");
      return;
    }

    if (isInUserWishlist && wishlistItem) {
      removeFromWishlist(wishlistItem.id);
    } else {
      addToWishlist(tireId);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      className={`${className} ${isInUserWishlist ? "text-primary border-primary hover:bg-primary/10" : ""}`}
      onClick={handleWishlistAction}
      disabled={isLoading}
      aria-label={isInUserWishlist ? "Remove from Wishlist" : "Add to Wishlist"}
      title={isInUserWishlist ? "Remove from Wishlist" : "Add to Wishlist"}
    >
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Heart className={`h-4 w-4 ${isInUserWishlist ? "fill-primary" : ""}`} />
      )}
    </Button>
  );
}
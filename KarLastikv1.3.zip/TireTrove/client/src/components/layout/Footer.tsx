import { Link } from 'wouter';
import { Facebook, Twitter, Instagram, Youtube, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-neutral-800 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Customer Service */}
          <div>
            <h3 className="text-lg font-bold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Contact Us</Link></li>
              <li><Link href="/track-order" className="text-neutral-300 hover:text-white transition">Track Order</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Shipping & Delivery</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Returns & Warranties</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Payment Options</Link></li>
            </ul>
          </div>
          
          {/* About TireHub */}
          <div>
            <h3 className="text-lg font-bold mb-4">About TireHub</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Our Story</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Careers</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Press & Media</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Affiliate Program</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Sell on TireHub</Link></li>
            </ul>
          </div>
          
          {/* Resources */}
          <div>
            <h3 className="text-lg font-bold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Tire Buying Guide</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Tire Size Calculator</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Tire Maintenance Tips</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Tire Technology Explained</Link></li>
              <li><Link href="#" className="text-neutral-300 hover:text-white transition">Blog</Link></li>
            </ul>
          </div>
          
          {/* Connect With Us */}
          <div>
            <h3 className="text-lg font-bold mb-4">Connect With Us</h3>
            <div className="flex space-x-4 mb-4">
              <Link href="#" className="text-neutral-300 hover:text-white transition">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-neutral-300 hover:text-white transition">
                <Twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-neutral-300 hover:text-white transition">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-neutral-300 hover:text-white transition">
                <Youtube className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-neutral-300 hover:text-white transition">
                <Linkedin className="h-5 w-5" />
              </Link>
            </div>
            <h4 className="font-medium mb-2">Customer Support</h4>
            <p className="text-neutral-300 mb-2">Mon-Fri: 8AM-8PM ET</p>
            <p className="text-neutral-300 mb-4">Sat-Sun: 9AM-6PM ET</p>
            <p className="text-white font-bold">1-800-TIRE-HUB</p>
          </div>
        </div>
        
        {/* Payment Methods */}
        <div className="border-t border-neutral-700 pt-6 mb-6">
          <div className="flex flex-wrap justify-center gap-4">
            <span className="text-neutral-400">We Accept:</span>
            <div className="flex space-x-4">
              <svg className="h-6 w-10 text-neutral-300" viewBox="0 0 32 20" fill="currentColor">
                <path d="M29.5,2h-27C1.6,2,1,2.6,1,3.5v13c0,0.9,0.6,1.5,1.5,1.5h27c0.9,0,1.5-0.6,1.5-1.5v-13C31,2.6,30.4,2,29.5,2z M9.3,13.6H6.9l-2-7.2h2.1l1.3,5l1.3-5h2.1L9.3,13.6z M13.2,13.6h-2V6.4h2V13.6z M19.4,13.6h-1.8v-0.9c-0.5,0.7-1.2,1-2,1c-1.2,0-2.1-0.8-2.1-2.3V6.4h2v4.4c0,0.8,0.4,1.2,1,1.2c0.6,0,1.1-0.4,1.1-1.2V6.4h2V13.6z M25.6,13.6H25v-1c-0.5,0.8-1.1,1.1-2,1.1c-1.2,0-2.2-1-2.2-2.5c0-1.5,1-2.5,2.2-2.5c0.9,0,1.5,0.3,2,1.1V6.4h2v7.2H25.6z M24.4,11.2c0-0.7-0.5-1.2-1.2-1.2s-1.2,0.5-1.2,1.2c0,0.7,0.5,1.2,1.2,1.2S24.4,11.9,24.4,11.2z" />
              </svg>
              <svg className="h-6 w-10 text-neutral-300" viewBox="0 0 32 20" fill="currentColor">
                <path d="M29.5,2h-27C1.6,2,1,2.6,1,3.5v13c0,0.9,0.6,1.5,1.5,1.5h27c0.9,0,1.5-0.6,1.5-1.5v-13C31,2.6,30.4,2,29.5,2z M11.7,14C9.2,14,7.4,12.1,7.4,9.6s1.8-4.4,4.4-4.4c0.8,0,1.6,0.2,2.3,0.6l-0.7,1.4c-0.5-0.3-1-0.4-1.6-0.4C10.1,6.8,9,8,9,9.6s1.1,2.8,2.7,2.8c0.6,0,1.1-0.1,1.6-0.4l0.7,1.4C13.3,13.8,12.5,14,11.7,14z M17,14c-2,0-3.6-1.6-3.6-3.6s1.6-3.6,3.6-3.6s3.6,1.6,3.6,3.6S19,14,17,14z M24.8,14c-2,0-3.6-1.6-3.6-3.6s1.6-3.6,3.6-3.6c0.9,0,1.7,0.3,2.3,0.8l-0.8,1.3c-0.4-0.3-0.9-0.5-1.5-0.5c-1.2,0-2.1,0.9-2.1,2.1s0.9,2.1,2.1,2.1c0.6,0,1.1-0.2,1.5-0.5l0.8,1.3C26.4,13.7,25.6,14,24.8,14z" />
              </svg>
              <svg className="h-6 w-10 text-neutral-300" viewBox="0 0 32 20" fill="currentColor">
                <path d="M29.5,2h-27C1.6,2,1,2.6,1,3.5v13c0,0.9,0.6,1.5,1.5,1.5h27c0.9,0,1.5-0.6,1.5-1.5v-13C31,2.6,30.4,2,29.5,2z M11.6,14c-2,0-3.6-1.6-3.6-3.6S9.6,6.8,11.6,6.8c0.9,0,1.7,0.3,2.3,0.8l-0.8,1.3c-0.4-0.3-0.9-0.5-1.5-0.5c-1.2,0-2.1,0.9-2.1,2.1s0.9,2.1,2.1,2.1c0.6,0,1.1-0.2,1.5-0.5l0.8,1.3C13.3,13.7,12.5,14,11.6,14z M16.9,14c-2,0-3.6-1.6-3.6-3.6s1.6-3.6,3.6-3.6c2,0,3.6,1.6,3.6,3.6S18.9,14,16.9,14z M24.8,14c-2,0-3.6-1.6-3.6-3.6s1.6-3.6,3.6-3.6c0.9,0,1.7,0.3,2.3,0.8l-0.8,1.3c-0.4-0.3-0.9-0.5-1.5-0.5c-1.2,0-2.1,0.9-2.1,2.1s0.9,2.1,2.1,2.1c0.6,0,1.1-0.2,1.5-0.5l0.8,1.3C26.5,13.7,25.7,14,24.8,14z" />
              </svg>
              <svg className="h-6 w-10 text-neutral-300" viewBox="0 0 32 20" fill="currentColor">
                <path d="M29.5,2h-27C1.6,2,1,2.6,1,3.5v13c0,0.9,0.6,1.5,1.5,1.5h27c0.9,0,1.5-0.6,1.5-1.5v-13C31,2.6,30.4,2,29.5,2z M4.8,11.4l3.1-3.6L4.8,4.2h2.4l1.9,2.2l1.9-2.2h2.4l-3.1,3.6l3.1,3.6h-2.4l-1.9-2.2l-1.9,2.2H4.8z M18.7,11.4h-4.6V9.8h4.3V8.2h-4.3V6.6h4.6V4.2h-7v9h7V11.4z M25.9,13.2l-3.2-4.5l3.2-4.5h-2.6l-2,2.8l-2-2.8h-2.6l3.2,4.5l-3.2,4.5h2.6l2-2.8l2,2.8H25.9z" />
              </svg>
              <svg className="h-6 w-10 text-neutral-300" viewBox="0 0 32 20" fill="currentColor">
                <path d="M29.5,2h-27C1.6,2,1,2.6,1,3.5v13c0,0.9,0.6,1.5,1.5,1.5h27c0.9,0,1.5-0.6,1.5-1.5v-13C31,2.6,30.4,2,29.5,2z M21.6,12.8h-3.2c-0.7,0-1.3-0.1-1.7-0.4c-0.4-0.3-0.6-0.7-0.6-1.2c0-0.3,0.1-0.6,0.3-0.9c0.2-0.2,0.5-0.4,0.8-0.5c-0.3-0.1-0.5-0.2-0.6-0.4c-0.1-0.2-0.2-0.4-0.2-0.6c0-0.3,0.1-0.5,0.2-0.7c0.2-0.2,0.4-0.3,0.8-0.4c-0.4-0.2-0.7-0.4-0.9-0.7c-0.2-0.3-0.3-0.6-0.3-1c0-0.6,0.2-1,0.7-1.4c0.5-0.3,1.1-0.5,1.9-0.5c0.5,0,1,0.1,1.4,0.2c0.4,0.2,0.7,0.4,0.9,0.7h2.2V5.8h-1c0.1,0.2,0.1,0.3,0.1,0.5c0,0.5-0.2,1-0.7,1.3c-0.4,0.3-1,0.5-1.8,0.5h-1.1c-0.2,0-0.4,0-0.5,0.1c-0.1,0.1-0.2,0.2-0.2,0.3c0,0.1,0,0.2,0.1,0.3c0.1,0.1,0.3,0.2,0.5,0.2h1.2c0.8,0,1.4,0.2,1.8,0.5c0.4,0.3,0.7,0.7,0.7,1.3C21.6,11.8,21.6,12.8,21.6,12.8z M14.6,10.7c0,0.2-0.1,0.3-0.2,0.4c-0.1,0.1-0.3,0.2-0.5,0.2H10c-0.2,0-0.3-0.1-0.4-0.2c-0.1-0.1-0.2-0.3-0.2-0.4c0-0.2,0.1-0.3,0.2-0.4c0.1-0.1,0.3-0.2,0.5-0.2h3.8c0.2,0,0.3,0.1,0.5,0.2C14.5,10.4,14.6,10.5,14.6,10.7z M10.6,8.3c-0.4,0-0.7-0.1-0.9-0.3C9.5,7.8,9.4,7.5,9.4,7.2c0-0.3,0.1-0.6,0.3-0.8c0.2-0.2,0.5-0.3,0.9-0.3c0.4,0,0.7,0.1,0.9,0.3c0.2,0.2,0.3,0.5,0.3,0.8c0,0.3-0.1,0.6-0.3,0.8C11.3,8.2,11,8.3,10.6,8.3z M17.8,11c0.3,0,0.6-0.1,0.8-0.2c0.2-0.1,0.2-0.3,0.2-0.6c0-0.2-0.1-0.3-0.2-0.4c-0.1-0.1-0.4-0.1-0.7-0.1h-1.5c-0.1,0.1-0.2,0.3-0.3,0.4c-0.1,0.2-0.1,0.3-0.1,0.5c0,0.2,0.1,0.3,0.2,0.4c0.1,0.1,0.3,0.1,0.5,0.1L17.8,11L17.8,11z M18.1,8.2c0.2,0,0.4-0.1,0.5-0.2c0.1-0.1,0.2-0.3,0.2-0.5c0-0.2-0.1-0.4-0.2-0.5c-0.1-0.1-0.3-0.2-0.5-0.2h-1.4c-0.2,0-0.4,0.1-0.5,0.2c-0.1,0.1-0.2,0.3-0.2,0.5c0,0.2,0.1,0.4,0.2,0.5c0.1,0.1,0.3,0.2,0.5,0.2H18.1z" />
              </svg>
            </div>
          </div>
        </div>
        
        {/* Legal */}
        <div className="border-t border-neutral-700 pt-6 text-center">
          <div className="flex flex-wrap justify-center gap-4 mb-4">
            <Link href="#" className="text-neutral-400 hover:text-neutral-300 text-sm">Terms of Service</Link>
            <Link href="#" className="text-neutral-400 hover:text-neutral-300 text-sm">Privacy Policy</Link>
            <Link href="#" className="text-neutral-400 hover:text-neutral-300 text-sm">Accessibility</Link>
            <Link href="#" className="text-neutral-400 hover:text-neutral-300 text-sm">Cookie Preferences</Link>
            <Link href="#" className="text-neutral-400 hover:text-neutral-300 text-sm">Do Not Sell My Info</Link>
          </div>
          <p className="text-neutral-400 text-sm">© 2023 TireHub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ChevronUp, Car, Circle, CaravanIcon, SlidersHorizontal, Search } from 'lucide-react';
import { Brand } from '@shared/schema';
import { priceRanges, tireTypes, tireSizes, vehicleMakes } from '@/lib/constants';

interface FilterState {
  types: string[];
  brands: string[];
  priceRanges: string[];
  sizes: string[];
  ratings: number[];
  vehicleMake: string;
  vehicleModel: string;
  vehicleYear: string;
  [key: string]: string[] | number[] | string; // Index signature to help TypeScript understand dynamic property access
}

interface ProductFiltersProps {
  onFilter: (filters: FilterState) => void;
  initialFilters?: Partial<FilterState>;
  autoApply?: boolean;
}

const ProductFilters = ({ onFilter, initialFilters = {}, autoApply = false }: ProductFiltersProps) => {
  const [filters, setFilters] = useState<FilterState>({
    types: initialFilters.types || [],
    brands: initialFilters.brands || [],
    priceRanges: initialFilters.priceRanges || [],
    sizes: initialFilters.sizes || [],
    ratings: initialFilters.ratings || [],
    vehicleMake: initialFilters.vehicleMake || '',
    vehicleModel: initialFilters.vehicleModel || '',
    vehicleYear: initialFilters.vehicleYear || '',
  });

  const [vehicleModels, setVehicleModels] = useState<string[]>([]);
  const [years, setYears] = useState<string[]>([]);
  const [searchBrand, setSearchBrand] = useState('');
  
  // Generate some sample vehicle models
  useEffect(() => {
    if (filters.vehicleMake) {
      // This would typically be an API call based on the make
      const models = [
        'Camry', 'Corolla', 'RAV4', 'Highlander', 'Civic', 
        'Accord', 'CR-V', 'F-150', 'Escape', 'Fusion'
      ];
      setVehicleModels(models);
    } else {
      setVehicleModels([]);
    }
  }, [filters.vehicleMake]);

  // Generate years
  useEffect(() => {
    const currentYear = new Date().getFullYear();
    const yearList = [];
    for (let i = currentYear; i >= currentYear - 15; i--) {
      yearList.push(i.toString());
    }
    setYears(yearList);
  }, []);
  
  // Fetch brands for filter
  const { data: brands } = useQuery<Brand[]>({
    queryKey: ['/api/brands'],
  });
  
  // Create a ref to track if we've initialized with the props
  const initializedRef = useRef(false);
  
  // Only update from initialFilters once on mount or when initialFilters changes significantly
  useEffect(() => {
    // Skip if already initialized and we're just getting prop updates in response to our own state changes
    if (initializedRef.current && userChangedFilters) {
      return;
    }
    
    if (initialFilters) {
      // Create a properly typed object by ensuring all properties have values
      const updatedFilters: FilterState = {
        ...filters,
        types: initialFilters.types || [],
        brands: initialFilters.brands || [],
        priceRanges: initialFilters.priceRanges || [],
        sizes: initialFilters.sizes || [],
        ratings: initialFilters.ratings || [],
        vehicleMake: initialFilters.vehicleMake || '',
        vehicleModel: initialFilters.vehicleModel || '',
        vehicleYear: initialFilters.vehicleYear || ''
      };
      
      // Only update if the values are actually different
      const currentFiltersJson = JSON.stringify(filters);
      const newFiltersJson = JSON.stringify(updatedFilters);
      
      if (currentFiltersJson !== newFiltersJson) {
        setFilters(updatedFilters);
        initializedRef.current = true;
      }
    }
  }, [initialFilters, filters]);
  
  // Track if filters were changed by the user vs. initialization
  const [userChangedFilters, setUserChangedFilters] = useState(false);
  
  // Keep a previous filters reference to prevent unnecessary updates
  const prevFiltersRef = useRef<FilterState | null>(null);
  
  // Debounce timer for auto-apply
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Apply filters with debouncing to avoid too many updates
  const applyFiltersWithDebounce = useCallback((currentFilters: FilterState) => {
    // Clear any existing timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    
    // Set a new timer to delay the filter application
    debounceTimerRef.current = setTimeout(() => {
      // Only trigger filter if the values actually changed
      const currentFiltersJson = JSON.stringify(currentFilters);
      const prevFiltersJson = prevFiltersRef.current ? JSON.stringify(prevFiltersRef.current) : '';
      
      if (currentFiltersJson !== prevFiltersJson) {
        prevFiltersRef.current = JSON.parse(JSON.stringify(currentFilters)); // Deep copy the current filters
        onFilter(currentFilters);
      }
      
      debounceTimerRef.current = null;
    }, 300); // 300ms debounce delay
  }, [onFilter]);
  
  // Apply the filters when they change
  useEffect(() => {
    // Auto-apply filters only when they change after user interaction
    if (autoApply && userChangedFilters) {
      applyFiltersWithDebounce(filters);
    }
    
    // Cleanup timeout on unmount
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [filters, autoApply, userChangedFilters, applyFiltersWithDebounce]);

  // Handle checkbox interactions separately to prevent double toggle
  const handleCheckboxChange = (
    category: keyof FilterState, 
    value: string | number, 
    checked: boolean | 'indeterminate'
  ) => {
    // Avoid firing when indeterminate (not really applicable for us but for completeness)
    if (checked === 'indeterminate') return;
    
    setUserChangedFilters(true);
    setFilters(prev => {
      if (Array.isArray(prev[category])) {
        const current = [...(prev[category] as any[])];
        
        if (checked) {
          // If checked and not already in array, add it
          if (current.indexOf(value as never) === -1) {
            current.push(value as never);
          }
        } else {
          // If unchecked and in array, remove it
          const index = current.indexOf(value as never);
          if (index > -1) {
            current.splice(index, 1);
          }
        }
        
        const updatedFilters = { ...prev, [category]: current };
        return updatedFilters;
      }
      return prev;
    });
  };
  
  // Regular toggle function for clicking on filter items (not checkboxes directly)
  const toggleFilter = (category: keyof FilterState, value: string | number) => {
    setUserChangedFilters(true);
    setFilters(prev => {
      // Make sure we're only handling array properties
      if (Array.isArray(prev[category])) {
        const current = [...(prev[category] as any[])]; // Type assertion to any[] to allow operations
        const index = current.indexOf(value as never);
        
        if (index > -1) {
          current.splice(index, 1);
        } else {
          current.push(value as never);
        }
        
        return {
          ...prev,
          [category]: current
        };
      }
      return prev;
    });
  };
  
  const handleSizeSelect = (size: string) => {
    setUserChangedFilters(true);
    setFilters(prev => ({
      ...prev,
      sizes: [size]
    }));
  };

  const handleVehicleMakeSelect = (make: string) => {
    setUserChangedFilters(true);
    setFilters(prev => ({
      ...prev,
      vehicleMake: make === 'none' ? '' : make,
      vehicleModel: '', // Reset model when make changes
      vehicleYear: ''   // Reset year when make changes
    }));
  };

  const handleVehicleModelSelect = (model: string) => {
    setUserChangedFilters(true);
    setFilters(prev => ({
      ...prev,
      vehicleModel: model === 'none' ? '' : model
    }));
  };

  const handleVehicleYearSelect = (year: string) => {
    setUserChangedFilters(true);
    setFilters(prev => ({
      ...prev,
      vehicleYear: year === 'none' ? '' : year
    }));
  };
  
  const applyFilters = () => {
    onFilter(filters);
  };
  
  const resetFilters = () => {
    const resetState: FilterState = {
      types: [],
      brands: [],
      priceRanges: [],
      sizes: [],
      ratings: [],
      vehicleMake: '',
      vehicleModel: '',
      vehicleYear: '',
    };
    setFilters(resetState);
    setSearchBrand('');
    setUserChangedFilters(false); // Stop auto-updating when resetting
    onFilter(resetState);
  };
  
  const [openVehicle, setOpenVehicle] = useState(true);
  const [openSize, setOpenSize] = useState(true);
  const [openTypes, setOpenTypes] = useState(true);
  const [openBrands, setOpenBrands] = useState(true);
  const [openPrice, setOpenPrice] = useState(true);
  const [openRating, setOpenRating] = useState(true);
  
  // Count active filters by category
  const activeTireTypes = filters.types.length;
  const activeBrands = filters.brands.length;
  const activePriceRanges = filters.priceRanges.length;
  const activeSizes = filters.sizes.length;
  const activeRatings = filters.ratings.length;
  const hasVehicleFilter = !!(filters.vehicleMake || filters.vehicleModel || filters.vehicleYear);
  
  // Total active filters
  const totalActiveFilters = activeTireTypes + activeBrands + activePriceRanges + activeSizes + activeRatings + (hasVehicleFilter ? 1 : 0);

  // Filter brands by search term
  const filteredBrands = brands?.filter(brand => 
    !searchBrand || brand.name.toLowerCase().includes(searchBrand.toLowerCase())
  );

  // Find compatible tire sizes for selected vehicle (this would be from API in real implementation)
  const compatibleSizes = filters.vehicleMake && filters.vehicleModel && filters.vehicleYear 
    ? tireSizes.slice(0, 3) // Just showing a subset for demo
    : tireSizes;
  
  return (
    <div className="bg-white rounded-lg shadow-md p-5">
      <div className="flex items-center justify-between border-b border-neutral-200 pb-3 mb-5">
        <h3 className="font-bold text-lg">Filter Products</h3>
        {totalActiveFilters > 0 && (
          <span className="bg-primary text-white text-xs font-bold rounded-full px-2 py-1 inline-flex items-center justify-center min-w-[24px]">
            {totalActiveFilters}
          </span>
        )}
      </div>
      
      {/* Vehicle Selector - New Section */}
      <Collapsible open={openVehicle} onOpenChange={setOpenVehicle} className="mb-6">
        <CollapsibleTrigger className="flex items-center justify-between w-full mb-3 bg-neutral-50 p-3 rounded-md">
          <div className="flex items-center">
            <Car className="h-4 w-4 mr-2 text-primary" />
            <h4 className="font-medium">Find By Vehicle</h4>
            {hasVehicleFilter && (
              <span className="ml-2 text-xs font-semibold bg-primary/10 text-primary rounded-full px-2 py-0.5">
                Active
              </span>
            )}
          </div>
          {openVehicle ? (
            <ChevronUp className="h-4 w-4 text-neutral-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-neutral-500" />
          )}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-3 mt-3 ml-1">
          <div className="space-y-3">
            <div>
              <Label htmlFor="vehicleMake" className="text-sm font-medium block mb-1.5">
                Make
              </Label>
              <Select 
                value={filters.vehicleMake || 'none'} 
                onValueChange={handleVehicleMakeSelect}
              >
                <SelectTrigger id="vehicleMake" className="w-full bg-white">
                  <SelectValue placeholder="Select make" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Select make</SelectItem>
                  {vehicleMakes.map((make) => (
                    <SelectItem key={make} value={make}>{make}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="vehicleModel" className="text-sm font-medium block mb-1.5">
                Model
              </Label>
              <Select 
                value={filters.vehicleModel || 'none'} 
                onValueChange={handleVehicleModelSelect}
                disabled={!filters.vehicleMake}
              >
                <SelectTrigger id="vehicleModel" className="w-full bg-white">
                  <SelectValue placeholder={filters.vehicleMake ? "Select model" : "Select make first"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Select model</SelectItem>
                  {vehicleModels.map((model) => (
                    <SelectItem key={model} value={model}>{model}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="vehicleYear" className="text-sm font-medium block mb-1.5">
                Year
              </Label>
              <Select 
                value={filters.vehicleYear || 'none'} 
                onValueChange={handleVehicleYearSelect}
                disabled={!filters.vehicleModel}
              >
                <SelectTrigger id="vehicleYear" className="w-full bg-white">
                  <SelectValue placeholder={filters.vehicleModel ? "Select year" : "Select model first"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Select year</SelectItem>
                  {years.map((year) => (
                    <SelectItem key={year} value={year}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {filters.vehicleMake && filters.vehicleModel && filters.vehicleYear && (
              <div className="pt-2">
                <Button 
                  className="w-full bg-primary hover:bg-primary/90 text-white"
                  onClick={applyFilters}
                >
                  Find Compatible Tires
                </Button>
              </div>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>
      
      {/* Tire Size Filter */}
      <Collapsible open={openSize} onOpenChange={setOpenSize} className="mb-6">
        <CollapsibleTrigger className="flex items-center justify-between w-full mb-3 bg-neutral-50 p-3 rounded-md">
          <div className="flex items-center">
            <Circle className="h-4 w-4 mr-2 text-primary" />
            <h4 className="font-medium">Tire Size</h4>
            {activeSizes > 0 && (
              <span className="ml-2 text-xs font-semibold bg-primary/10 text-primary rounded-full px-2 py-0.5">
                {activeSizes}
              </span>
            )}
          </div>
          {openSize ? (
            <ChevronUp className="h-4 w-4 text-neutral-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-neutral-500" />
          )}
        </CollapsibleTrigger>
        <CollapsibleContent className="ml-1">
          {filters.vehicleMake && filters.vehicleModel && filters.vehicleYear ? (
            <div className="mb-3">
              <p className="text-sm text-neutral-600 mb-2">
                Compatible sizes for {filters.vehicleYear} {filters.vehicleMake} {filters.vehicleModel}:
              </p>
              <div className="grid grid-cols-2 gap-2">
                {compatibleSizes.map((size) => (
                  <Button
                    key={size}
                    variant={filters.sizes.includes(size) ? "default" : "outline"}
                    size="sm"
                    className={`text-sm ${filters.sizes.includes(size) ? 'bg-primary text-white' : 'border-neutral-200 text-neutral-700'}`}
                    onClick={() => handleSizeSelect(size)}
                  >
                    {size}
                  </Button>
                ))}
              </div>
            </div>
          ) : (
            <div className="mt-2 mb-3">
              <p className="text-sm text-neutral-600 mb-2">Common tire sizes:</p>
              <div className="grid grid-cols-2 gap-2">
                {tireSizes.map((size) => (
                  <Button
                    key={size}
                    variant={filters.sizes.includes(size) ? "default" : "outline"}
                    size="sm"
                    className={`text-sm ${filters.sizes.includes(size) ? 'bg-primary text-white' : 'border-neutral-200 text-neutral-700'}`}
                    onClick={() => handleSizeSelect(size)}
                  >
                    {size}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </CollapsibleContent>
      </Collapsible>
      
      {/* Tire Type Filter */}
      <Collapsible open={openTypes} onOpenChange={setOpenTypes} className="mb-6">
        <CollapsibleTrigger className="flex items-center justify-between w-full mb-3 bg-neutral-50 p-3 rounded-md">
          <div className="flex items-center">
            <CaravanIcon className="h-4 w-4 mr-2 text-primary" />
            <h4 className="font-medium">Tire Type</h4>
            {activeTireTypes > 0 && (
              <span className="ml-2 text-xs font-semibold bg-primary/10 text-primary rounded-full px-2 py-0.5">
                {activeTireTypes}
              </span>
            )}
          </div>
          {openTypes ? (
            <ChevronUp className="h-4 w-4 text-neutral-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-neutral-500" />
          )}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-2 ml-1">
          <div className="grid grid-cols-1 gap-1">
            {tireTypes.map((type) => (
              <div 
                key={type.value} 
                className={`flex items-center p-2 rounded-md cursor-pointer transition-colors ${
                  filters.types.includes(type.value) 
                    ? 'bg-primary/5 border border-primary/30' 
                    : 'hover:bg-neutral-50 border border-transparent'
                }`}
                onClick={() => handleCheckboxChange('types', type.value, !filters.types.includes(type.value))}
              >
                <Checkbox 
                  id={`type-${type.value}`} 
                  checked={filters.types.includes(type.value)} 
                  onCheckedChange={(checked) => handleCheckboxChange('types', type.value, checked)}
                  className="text-primary rounded mr-2"
                />
                <Label htmlFor={`type-${type.value}`} className="text-sm cursor-pointer flex-1">
                  {type.label} <span className="text-neutral-500 text-xs ml-1">({type.count})</span>
                </Label>
              </div>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
      
      {/* Brand Filter */}
      <Collapsible open={openBrands} onOpenChange={setOpenBrands} className="mb-6">
        <CollapsibleTrigger className="flex items-center justify-between w-full mb-3 bg-neutral-50 p-3 rounded-md">
          <div className="flex items-center">
            <SlidersHorizontal className="h-4 w-4 mr-2 text-primary" />
            <h4 className="font-medium">Brand</h4>
            {activeBrands > 0 && (
              <span className="ml-2 text-xs font-semibold bg-primary/10 text-primary rounded-full px-2 py-0.5">
                {activeBrands}
              </span>
            )}
          </div>
          {openBrands ? (
            <ChevronUp className="h-4 w-4 text-neutral-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-neutral-500" />
          )}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-3 ml-1">
          <div className="relative mb-3">
            <Input 
              value={searchBrand}
              onChange={(e) => setSearchBrand(e.target.value)}
              placeholder="Search brands..."
              className="pr-8"
            />
            <Search className="absolute right-2 top-2.5 h-4 w-4 text-neutral-400" />
          </div>
          
          <div className="max-h-48 overflow-y-auto space-y-1 pr-1">
            {filteredBrands?.map((brand) => (
              <div 
                key={brand.id} 
                className={`flex items-center p-2 rounded-md cursor-pointer transition-colors ${
                  filters.brands.includes(brand.name) 
                    ? 'bg-primary/5 border border-primary/30' 
                    : 'hover:bg-neutral-50 border border-transparent'
                }`}
                onClick={() => handleCheckboxChange('brands', brand.name, !filters.brands.includes(brand.name))}
              >
                <Checkbox 
                  id={`brand-${brand.id}`} 
                  checked={filters.brands.includes(brand.name)} 
                  onCheckedChange={(checked) => handleCheckboxChange('brands', brand.name, checked)}
                  className="text-primary rounded mr-2"
                />
                <Label 
                  htmlFor={`brand-${brand.id}`} 
                  className="text-sm cursor-pointer flex-1 flex items-center"
                  onClick={(e) => {
                    e.preventDefault();
                    // Use the new handler to keep state consistent
                    handleCheckboxChange('brands', brand.name, !filters.brands.includes(brand.name));
                  }}
                >
                  {brand.logoUrl && (
                    <img src={brand.logoUrl} alt={brand.name} className="h-5 w-5 mr-2 object-contain" />
                  )}
                  {brand.name}
                </Label>
              </div>
            ))}
            
            {filteredBrands?.length === 0 && (
              <p className="text-sm text-neutral-500 py-2">No brands found</p>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>
      
      {/* Price Filter */}
      <Collapsible open={openPrice} onOpenChange={setOpenPrice} className="mb-6">
        <CollapsibleTrigger className="flex items-center justify-between w-full mb-3 bg-neutral-50 p-3 rounded-md">
          <div className="flex items-center">
            <h4 className="font-medium">Price Range</h4>
            {activePriceRanges > 0 && (
              <span className="ml-2 text-xs font-semibold bg-primary/10 text-primary rounded-full px-2 py-0.5">
                {activePriceRanges}
              </span>
            )}
          </div>
          {openPrice ? (
            <ChevronUp className="h-4 w-4 text-neutral-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-neutral-500" />
          )}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-2 ml-1">
          <div className="grid grid-cols-1 gap-1">
            {priceRanges.map((range) => (
              <div 
                key={range.value} 
                className={`flex items-center p-2 rounded-md cursor-pointer transition-colors ${
                  filters.priceRanges.includes(range.value) 
                    ? 'bg-primary/5 border border-primary/30' 
                    : 'hover:bg-neutral-50 border border-transparent'
                }`}
                onClick={() => handleCheckboxChange('priceRanges', range.value, !filters.priceRanges.includes(range.value))}
              >
                <Checkbox 
                  id={`price-${range.value}`} 
                  checked={filters.priceRanges.includes(range.value)} 
                  onCheckedChange={(checked) => handleCheckboxChange('priceRanges', range.value, checked)}
                  className="text-primary rounded mr-2"
                />
                <Label 
                  htmlFor={`price-${range.value}`} 
                  className="text-sm cursor-pointer flex-1"
                  onClick={(e) => {
                    e.preventDefault();
                    handleCheckboxChange('priceRanges', range.value, !filters.priceRanges.includes(range.value));
                  }}
                >
                  {range.label} <span className="text-neutral-500 text-xs ml-1">({range.count})</span>
                </Label>
              </div>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
      
      {/* Rating Filter */}
      <Collapsible open={openRating} onOpenChange={setOpenRating} className="mb-6">
        <CollapsibleTrigger className="flex items-center justify-between w-full mb-3 bg-neutral-50 p-3 rounded-md">
          <div className="flex items-center">
            <h4 className="font-medium">Customer Rating</h4>
            {activeRatings > 0 && (
              <span className="ml-2 text-xs font-semibold bg-primary/10 text-primary rounded-full px-2 py-0.5">
                {activeRatings}
              </span>
            )}
          </div>
          {openRating ? (
            <ChevronUp className="h-4 w-4 text-neutral-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-neutral-500" />
          )}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-2 ml-1">
          <div className="grid grid-cols-1 gap-1">
            {[5, 4, 3].map((rating) => (
              <div 
                key={rating} 
                className={`flex items-center p-2 rounded-md cursor-pointer transition-colors ${
                  filters.ratings.includes(rating) 
                    ? 'bg-primary/5 border border-primary/30' 
                    : 'hover:bg-neutral-50 border border-transparent'
                }`}
                onClick={() => handleCheckboxChange('ratings', rating, !filters.ratings.includes(rating))}
              >
                <Checkbox 
                  id={`rating-${rating}`} 
                  checked={filters.ratings.includes(rating)} 
                  onCheckedChange={(checked) => handleCheckboxChange('ratings', rating, checked)}
                  className="text-primary rounded mr-2"
                />
                <Label 
                  htmlFor={`rating-${rating}`} 
                  className="text-sm cursor-pointer flex items-center flex-1"
                  onClick={(e) => {
                    e.preventDefault();
                    handleCheckboxChange('ratings', rating, !filters.ratings.includes(rating));
                  }}
                >
                  {Array(rating).fill(0).map((_, i) => (
                    <svg key={i} className="w-4 h-4 text-accent fill-accent" viewBox="0 0 24 24">
                      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                    </svg>
                  ))}
                  {Array(5 - rating).fill(0).map((_, i) => (
                    <svg key={i} className="w-4 h-4 text-neutral-300" viewBox="0 0 24 24">
                      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                    </svg>
                  ))}
                  <span className="ml-1 text-neutral-500 text-xs">or more</span>
                </Label>
              </div>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
      
      <div className="flex space-x-2 sticky bottom-0 bg-white pt-3 pb-1 mt-6">
        <Button 
          variant="outline" 
          className="w-1/2 bg-neutral-50 hover:bg-neutral-100 text-neutral-700 font-medium border-neutral-200"
          onClick={resetFilters}
        >
          Clear All
        </Button>
        <Button 
          className="w-1/2 bg-primary hover:bg-primary/90 text-white font-medium"
          onClick={applyFilters}
        >
          Apply Filters
        </Button>
      </div>
    </div>
  );
};

export default ProductFilters;

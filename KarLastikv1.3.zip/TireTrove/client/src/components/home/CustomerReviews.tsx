import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { Skeleton } from '@/components/ui/skeleton';
import { Star, StarHalf } from 'lucide-react';
import { Review } from '@shared/schema';

const CustomerReviews = () => {
  // Fetch reviews
  const { data: reviews, isLoading, error } = useQuery<Review[]>({
    queryKey: ['/api/reviews'],
  });
  
  // Function to render star ratings
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-accent fill-accent" size={16} />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-accent fill-accent" size={16} />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-accent" size={16} />);
    }
    
    return stars;
  };
  
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">What Our Customers Say</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((item) => (
              <Card key={item} className="overflow-hidden">
                <CardContent className="p-6">
                  <Skeleton className="h-4 w-24 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-4" />
                  <div className="flex justify-between">
                    <div className="flex items-center">
                      <Skeleton className="h-10 w-10 rounded-full mr-3" />
                      <div>
                        <Skeleton className="h-4 w-20 mb-1" />
                        <Skeleton className="h-3 w-32" />
                      </div>
                    </div>
                    <Skeleton className="h-3 w-16" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <div className="text-center p-8">
            <p className="text-red-500">Error loading reviews. Please try again later.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {reviews?.slice(0, 3).map((review) => (
              <Card key={review.id} className="bg-neutral-50 rounded-lg p-6 border border-neutral-200">
                <div className="flex items-center mb-4">
                  <div className="flex mr-2">
                    {renderStars(review.rating)}
                  </div>
                  <span className="text-neutral-500 text-sm">{review.rating.toFixed(1)}</span>
                </div>
                <p className="text-neutral-700 mb-4">"{review.comment}"</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-neutral-300 rounded-full flex items-center justify-center text-neutral-600 font-bold mr-3">
                      {review.userName.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <h4 className="font-medium">{review.userName}</h4>
                      <p className="text-neutral-500 text-sm">{review.userVehicle}</p>
                    </div>
                  </div>
                  <span className="text-xs text-neutral-500">2 weeks ago</span>
                </div>
              </Card>
            ))}
          </div>
        )}
        
        <div className="mt-10 text-center">
          <Button asChild variant="outline" className="inline-block bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 font-medium py-2 px-6 rounded-lg">
            <Link href="/reviews">View All Reviews</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CustomerReviews;

// Tire Types
export const tireTypes = [
  { value: 'all-season', label: 'All-Season', count: 86 },
  { value: 'winter', label: 'Winter/Snow', count: 42 },
  { value: 'performance', label: 'Performance', count: 38 },
  { value: 'all-terrain', label: 'All-Terrain', count: 24 },
  { value: 'touring', label: 'Touring', count: 18 },
];

// Price Ranges
export const priceRanges = [
  { value: 'under100', label: 'Under $100', count: 15 },
  { value: '100-150', label: '$100 - $150', count: 42 },
  { value: '150-200', label: '$150 - $200', count: 36 },
  { value: '200-250', label: '$200 - $250', count: 28 },
  { value: 'over250', label: '$250+', count: 18 },
];

// Common Tire Sizes
export const tireSizes = [
  '205/55R16',
  '215/60R16',
  '225/45R17',
  '225/65R17',
  '235/55R18',
  '245/40R19',
  '265/70R17',
  '275/55R20',
];

// Common Vehicle Makes
export const vehicleMakes = [
  'Toyota',
  'Honda',
  'Ford',
  'Chevrolet',
  'Nissan',
  'BMW',
  'Mercedes-Benz',
  'Audi',
  'Hyundai',
  'Kia',
];

// Installation Services
export const installationServices = [
  { id: 1, name: 'Tire Mounting', price: 15.99 },
  { id: 2, name: 'Wheel Balancing', price: 12.99 },
  { id: 3, name: 'Wheel Alignment', price: 89.99 },
  { id: 4, name: 'Tire Rotation', price: 29.99 },
];

// API error messages
export const errorMessages = {
  CART_ADD_FAILED: 'Failed to add item to cart. Please try again.',
  CART_UPDATE_FAILED: 'Failed to update cart. Please try again.',
  CART_REMOVE_FAILED: 'Failed to remove item from cart. Please try again.',
  PAYMENT_FAILED: 'Payment processing failed. Please check your payment details and try again.',
  SEARCH_FAILED: 'Search failed. Please try a different query or refresh the page.',
  FETCH_FAILED: 'Failed to load data. Please refresh the page and try again.',
};

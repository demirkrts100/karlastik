import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const HeroSection = () => {
  return (
    <section className="relative">
      <div className="h-[400px] md:h-[500px] bg-cover bg-center" style={{ backgroundImage: "url('https://pixabay.com/get/g0269b20a2d31722c0070e07208afb55a4f486df3a6307bccb5b9fcb67c105330d62c99c7abba5a579ce49bb6bfa6f18ca2abda2ccf180ed2b1bce5d4a8d96953_1280.jpg')" }}>
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-900/70 to-transparent flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-xl">
              <h1 className="text-white text-3xl md:text-5xl font-bold mb-4">Winter Ready, Road Ready</h1>
              <p className="text-white text-lg md:text-xl mb-8">Find the perfect tires for your vehicle from top brands at unbeatable prices.</p>
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                <Button asChild className="bg-secondary hover:bg-secondary/90 text-white font-medium py-3 px-6 rounded-lg">
                  <Link href="#shop-by-vehicle">Shop by Vehicle</Link>
                </Button>
                <Button asChild variant="outline" className="bg-white hover:bg-neutral-100 text-primary font-medium py-3 px-6 rounded-lg">
                  <Link href="/products">Explore Our Collection</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;

import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Helmet } from 'react-helmet-async';
import { Grid, List, Loader, ChevronLeft, ChevronRight, SlidersHorizontal, X } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle, SheetFooter } from '@/components/ui/sheet';
import ProductCard from '@/components/product/ProductCard';
import ProductFilters from '@/components/product/ProductFilters';
import { useSearch } from '@/contexts/SearchContext';
import { Tire } from '@shared/schema';

const ProductListingPage = () => {
  const [location] = useLocation();
  const { searchQuery, vehicleParams, searchResults, setSearchResults, clearSearch } = useSearch();
  const [gridView, setGridView] = useState(true);
  const [sortOption, setSortOption] = useState('bestMatch');
  const [currentPage, setCurrentPage] = useState(1);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [filters, setFilters] = useState({
    types: [] as string[],
    brands: [] as string[],
    priceRanges: [] as string[],
    sizes: [] as string[],
    ratings: [] as number[],
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
  });
  
  // Get query params from URL
  const getQueryParams = () => {
    const params = new URLSearchParams(window.location.search);
    return {
      brand: params.get('brand'),
      type: params.get('type'),
    };
  };
  
  const { brand, type } = getQueryParams();
  
  // If we have a brand parameter, we want to query the API for that specific brand
  useEffect(() => {
    // Only set this up if we're not already searching for something else
    if (brand && brand !== 'all' && !searchQuery) {
      // Create a direct API request to get tires by brand
      fetch(`/api/tires/brand/${brand}`)
        .then(res => res.json())
        .then(data => {
          // Set the search results to the tires from this brand
          if (data && Array.isArray(data)) {
            // This avoids the need to filter tires after they come back
            setSearchResults(data);
          }
        })
        .catch(err => {
          console.error("Error fetching brand tires:", err);
        });
    }
  }, [brand, searchQuery, setSearchResults]);
  
  // Check if we are coming from a search or using URL parameters
  useEffect(() => {
    // If we have a search query, we should clear any existing filters
    if (searchQuery) {
      setFilters({
        types: [],
        brands: [],
        priceRanges: [],
        sizes: [],
        ratings: [],
        vehicleMake: '',
        vehicleModel: '',
        vehicleYear: ''
      });
    } 
    // Otherwise, apply URL filters if present
    else if (brand || type) {
      let newFilters = {
        types: [] as string[],
        brands: [] as string[],
        priceRanges: [] as string[],
        sizes: [] as string[],
        ratings: [] as number[],
        vehicleMake: '',
        vehicleModel: '',
        vehicleYear: ''
      };
      
      if (brand && brand !== 'all') {
        newFilters.brands = [brand];
      }
      
      if (type) {
        newFilters.types = [type];
      }
      
      setFilters(newFilters);
    }
  }, [searchQuery, brand, type]);
  
  // Fetch all tires or search if we have a query
  const { data: allTires, isLoading } = useQuery<Tire[]>({
    queryKey: [searchQuery ? `/api/tires/search/${searchQuery}` : '/api/tires'],
    enabled: !searchResults,
  });
  
  // Use search results if available, otherwise use fetched tires
  const tires = searchResults || allTires;
  
  // Determine if we should apply filters or not
  const shouldApplyFilters = !searchQuery || (searchQuery && (
    filters.types.length > 0 || 
    filters.priceRanges.length > 0 || 
    filters.sizes.length > 0 || 
    filters.ratings.length > 0 ||
    filters.brands.length > 0 ||
    filters.vehicleMake || 
    filters.vehicleModel || 
    filters.vehicleYear
  ));
  
  // Apply filters and sorting (if no search query or if filters explicitly set)
  const filteredTires = tires ? tires.filter(tire => {
    // If we're searching and no filters are explicitly set, don't filter the results
    if (!shouldApplyFilters) {
      return true;
    }
    
    // Apply type filter
    if (filters.types.length > 0 && !filters.types.includes(tire.type)) {
      return false;
    }
    
    // Apply brand filter
    if (filters.brands.length > 0 && !filters.brands.includes(tire.brand)) {
      return false;
    }
    
    // Apply price range filter
    if (filters.priceRanges.length > 0) {
      let matchesPrice = false;
      const price = Number(tire.discountedPrice || tire.price);
      
      for (const range of filters.priceRanges) {
        if (range === 'under100' && price < 100) {
          matchesPrice = true;
          break;
        } else if (range === '100-150' && price >= 100 && price <= 150) {
          matchesPrice = true;
          break;
        } else if (range === '150-200' && price > 150 && price <= 200) {
          matchesPrice = true;
          break;
        } else if (range === '200-250' && price > 200 && price <= 250) {
          matchesPrice = true;
          break;
        } else if (range === 'over250' && price > 250) {
          matchesPrice = true;
          break;
        }
      }
      
      if (!matchesPrice) return false;
    }
    
    // Apply size filter
    if (filters.sizes.length > 0 && !filters.sizes.includes(tire.size)) {
      return false;
    }
    
    // Apply rating filter
    if (filters.ratings.length > 0 && !filters.ratings.includes(Math.floor(Number(tire.rating)))) {
      return false;
    }
    
    // Apply vehicle filter - if vehicle make/model/year are selected, ensure compatible tires
    const hasVehicleFilter = filters.vehicleMake && filters.vehicleModel && filters.vehicleYear;
    if (hasVehicleFilter) {
      // In a real implementation, we would check against a vehicle compatibility database
      // For now, we'll use a simple check to simulate vehicle compatibility
      
      // Simulating compatibility by checking tire specs match vehicle requirements
      // This would normally come from an API that knows which tires fit which vehicles
      const vehicleFullName = `${filters.vehicleYear} ${filters.vehicleMake} ${filters.vehicleModel}`;
      
      // For demo purposes, show specific sizes for specific vehicles
      if (vehicleFullName.includes('Toyota') && tire.size !== "225/65R17") {
        return false;
      }
      
      if (vehicleFullName.includes('Honda') && tire.size !== "215/55R17") {
        return false;
      }
      
      if (vehicleFullName.includes('Ford') && tire.size !== "235/65R17") {
        return false;
      }
    }
    
    return true;
  }) : [];
  
  // Sort filtered tires
  const sortedTires = [...filteredTires].sort((a, b) => {
    switch (sortOption) {
      case 'priceLowToHigh':
        return Number(a.discountedPrice || a.price) - Number(b.discountedPrice || b.price);
      case 'priceHighToLow':
        return Number(b.discountedPrice || b.price) - Number(a.discountedPrice || a.price);
      case 'customerRating':
        return Number(b.rating) - Number(a.rating);
      case 'mostPopular':
        return (b.reviewCount || 0) - (a.reviewCount || 0);
      default:
        return 0;
    }
  });
  
  // Pagination
  const tiresPerPage = 15; // Show more products per page to fill our 5-column grid nicely
  const totalPages = Math.ceil(sortedTires.length / tiresPerPage);
  const paginatedTires = sortedTires.slice(
    (currentPage - 1) * tiresPerPage,
    currentPage * tiresPerPage
  );
  
  const handleApplyFilters = (newFilters: any) => {
    // Ensure we have the expected structure with all vehicle properties
    const updatedFilters = {
      ...newFilters,
      vehicleMake: newFilters.vehicleMake || '',
      vehicleModel: newFilters.vehicleModel || '',
      vehicleYear: newFilters.vehicleYear || ''
    };
    setFilters(updatedFilters);
    setCurrentPage(1);
  };
  
  return (
    <>
      <Helmet>
        <title>Shop Tires | TireHub Marketplace</title>
        <meta name="description" content="Browse our wide selection of tires from top brands. Filter by type, size, brand, and price to find the perfect tires for your vehicle." />
      </Helmet>
      
      <div className="py-12 bg-neutral-50">
        <div className="container mx-auto px-4 max-w-7xl">
          <h1 className="text-2xl md:text-3xl font-bold mb-8">
            {searchQuery ? `Search Results for "${searchQuery}"` : 
             vehicleParams ? 'Tires for Your Vehicle' : 
             brand ? `${brand} Tires` : 
             type ? `${type.charAt(0).toUpperCase() + type.slice(1)} Tires` : 
             'All Tires'}
          </h1>
          
          {/* Mobile Filter Sheet */}
          <div className="lg:hidden mb-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button 
                  variant="outline" 
                  className="w-full flex items-center justify-center gap-2 bg-white"
                >
                  <SlidersHorizontal className="h-4 w-4" />
                  Filter Products
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[85%] sm:w-[350px] p-0 overflow-y-auto">
                <SheetHeader className="p-4 border-b sticky top-0 bg-white z-10 flex flex-row items-center justify-between">
                  <SheetTitle className="text-left font-bold">Filter Options</SheetTitle>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-neutral-500 hover:text-primary"
                    onClick={() => {
                      const resetState = {
                        types: [],
                        brands: [],
                        priceRanges: [],
                        sizes: [],
                        ratings: [],
                        vehicleMake: '',
                        vehicleModel: '',
                        vehicleYear: ''
                      };
                      setFilters(resetState);
                      handleApplyFilters(resetState);
                    }}
                  >
                    Clear All
                  </Button>
                </SheetHeader>
                <div className="p-4">
                  <ProductFilters 
                    onFilter={(newFilters) => {
                      handleApplyFilters(newFilters);
                      // Close the drawer after applying filters
                      const closeButton = document.querySelector('[data-state="open"] button[aria-label="Close"]');
                      if (closeButton) {
                        (closeButton as HTMLButtonElement).click();
                      }
                    }} 
                    initialFilters={filters}
                  />
                </div>
                <div className="border-t p-4 sticky bottom-0 bg-white">
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-white font-medium"
                    onClick={() => {
                      // Close the drawer
                      const closeButton = document.querySelector('[data-state="open"] button[aria-label="Close"]');
                      if (closeButton) {
                        (closeButton as HTMLButtonElement).click();
                      }
                    }}
                  >
                    Show Results ({filteredTires.length})
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters Sidebar - Left (Desktop only) */}
            <div className="hidden lg:block lg:w-1/4 xl:w-1/5">
              <div className="sticky top-20">
                <ProductFilters 
                  onFilter={handleApplyFilters} 
                  initialFilters={filters}
                  autoApply={true}
                />
              </div>
            </div>
            
            {/* Product Grid */}
            <div className="lg:w-3/4 xl:w-4/5">
              {/* Sort Controls */}
              <Card className="bg-white rounded-lg shadow-sm p-4 mb-6">
                <div className="flex flex-col sm:flex-row justify-between items-center">
                  <div className="mb-3 sm:mb-0">
                    <span className="text-neutral-600">{filteredTires.length} results</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <label className="text-sm text-neutral-600">Sort by:</label>
                    <Select value={sortOption} onValueChange={setSortOption}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Best Match" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bestMatch">Best Match</SelectItem>
                        <SelectItem value="priceLowToHigh">Price: Low to High</SelectItem>
                        <SelectItem value="priceHighToLow">Price: High to Low</SelectItem>
                        <SelectItem value="customerRating">Customer Rating</SelectItem>
                        <SelectItem value="mostPopular">Most Popular</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="hidden md:flex space-x-2">
                      <Button 
                        variant={gridView ? "default" : "outline"} 
                        size="icon"
                        onClick={() => setGridView(true)}
                        className={gridView ? "bg-primary text-white" : "border-neutral-300 text-neutral-600"}
                      >
                        <Grid className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant={!gridView ? "default" : "outline"} 
                        size="icon"
                        onClick={() => setGridView(false)}
                        className={!gridView ? "bg-primary text-white" : "border-neutral-300 text-neutral-600"}
                      >
                        <List className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              
              {/* Products */}
              {isLoading ? (
                <div className="flex justify-center items-center py-16">
                  <Loader className="animate-spin h-8 w-8 text-primary" />
                  <span className="ml-2">Loading products...</span>
                </div>
              ) : paginatedTires.length === 0 ? (
                <Card className="p-8 text-center">
                  <h2 className="text-xl font-semibold mb-4">No products found</h2>
                  <p className="text-neutral-600 mb-6">Try adjusting your filters or search for a different term.</p>
                  <Button 
                    className="bg-primary hover:bg-primary/90 text-white"
                    onClick={() => {
                      const resetState = {
                        types: [],
                        brands: [],
                        priceRanges: [],
                        sizes: [],
                        ratings: [],
                        vehicleMake: '',
                        vehicleModel: '',
                        vehicleYear: ''
                      };
                      setFilters(resetState);
                      clearSearch();
                    }}
                  >
                    Clear All Filters
                  </Button>
                </Card>
              ) : (
                <div className={gridView ? "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4" : "space-y-4"}>
                  {paginatedTires.map((tire) => (
                    <div key={tire.id} className="flex">
                      {gridView ? (
                        <ProductCard tire={tire} />
                      ) : (
                        <Card className="flex flex-col md:flex-row overflow-hidden hover:shadow-md transition-shadow">
                          <div className="md:w-1/3">
                            <img src={tire.imageUrl} alt={tire.name} className="w-full h-48 md:h-full object-cover" />
                          </div>
                          <CardContent className="p-4 md:w-2/3 flex flex-col">
                            <div className="mb-2">
                              <Link href={`/product/${tire.id}`} className="font-bold text-lg hover:text-primary">
                                {tire.name}
                              </Link>
                              <div className="flex mt-1">
                                {Array(Math.floor(Number(tire.rating))).fill(0).map((_, i) => (
                                  <svg key={i} className="w-4 h-4 text-accent fill-accent" viewBox="0 0 24 24">
                                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                                  </svg>
                                ))}
                                <span className="text-xs text-neutral-500 ml-1">({tire.reviewCount})</span>
                              </div>
                            </div>
                            <p className="text-neutral-600 text-sm mb-2">{tire.description}</p>
                            <p className="text-sm text-neutral-600">Size: {tire.size}</p>
                            <div className="mt-auto pt-4 flex justify-between items-center">
                              <div>
                                {tire.discountedPrice ? (
                                  <>
                                    <span className="text-neutral-500 line-through text-sm">${tire.price}</span>
                                    <span className="font-bold text-secondary text-lg ml-2">${tire.discountedPrice}</span>
                                  </>
                                ) : (
                                  <span className="font-bold text-lg">${tire.price}</span>
                                )}
                              </div>
                              <div>
                                <Button 
                                  asChild
                                  className="bg-primary hover:bg-primary/90 text-white font-medium"
                                >
                                  <Link href={`/product/${tire.id}`}>View Details</Link>
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  ))}
                </div>
              )}
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-8 flex justify-center">
                  <div className="inline-flex rounded-md shadow-sm">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-2 text-sm font-medium text-neutral-500 bg-white border border-neutral-300 rounded-l-lg hover:bg-neutral-50"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                      <Button
                        key={page}
                        variant={page === currentPage ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(page)}
                        className={`px-3 py-2 text-sm font-medium ${
                          page === currentPage 
                            ? "text-white bg-primary border border-primary" 
                            : "text-neutral-700 bg-white border border-neutral-300 hover:bg-neutral-50"
                        }`}
                      >
                        {page}
                      </Button>
                    ))}
                    
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="px-3 py-2 text-sm font-medium text-neutral-500 bg-white border border-neutral-300 rounded-r-lg hover:bg-neutral-50"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductListingPage;

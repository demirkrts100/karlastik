import { ReactNode } from "react";
import AdminHeader from "./AdminHeader";
import { Toaster } from "@/components/ui/toaster";

interface AdminLayoutProps {
  children: ReactNode;
  title?: string;
}

const AdminLayout = ({ children, title = "TireHub Admin" }: AdminLayoutProps) => {
  return (
    <div className="min-h-screen flex flex-col bg-neutral-100">
      <AdminHeader title={title} />
      <main className="flex-1 container mx-auto px-4 py-6">
        {children}
      </main>
      <footer className="bg-neutral-800 text-white py-3">
        <div className="container mx-auto px-4 text-center text-sm text-neutral-400">
          &copy; {new Date().getFullYear()} TireHub Admin Portal. All rights reserved.
        </div>
      </footer>
      <Toaster />
    </div>
  );
};

export default AdminLayout;
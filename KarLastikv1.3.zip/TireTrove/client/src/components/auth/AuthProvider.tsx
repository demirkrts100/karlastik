import { createContext, ReactNode, useContext } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { User, loginSchema, registrationSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

// Define a type for the profile update form
const profileUpdateSchema = z.object({
  firstName: z.string().nullable().optional(),
  lastName: z.string().nullable().optional(),
  phone: z.string().nullable().optional(),
  address: z.string().nullable().optional(),
  city: z.string().nullable().optional(),
  state: z.string().nullable().optional(),
  zipCode: z.string().nullable().optional(),
});

// Define a type for the password change form
const passwordChangeSchema = z.object({
  currentPassword: z.string(),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
});

type AuthUser = Omit<User, "password">;

type LoginForm = z.infer<typeof loginSchema>;
type RegistrationForm = z.infer<typeof registrationSchema>;
type ProfileUpdateForm = z.infer<typeof profileUpdateSchema>;
type PasswordChangeForm = z.infer<typeof passwordChangeSchema>;

interface AuthContextType {
  user: AuthUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: ReturnType<typeof useMutation<AuthUser, Error, LoginForm>>;
  registerMutation: ReturnType<typeof useMutation<AuthUser, Error, RegistrationForm>>;
  logoutMutation: ReturnType<typeof useMutation<void, Error, void>>;
  updateProfileMutation: ReturnType<typeof useMutation<AuthUser, Error, ProfileUpdateForm>>;
  changePasswordMutation: ReturnType<typeof useMutation<{ message: string }, Error, PasswordChangeForm>>;
}

// Create the context
export const AuthContext = createContext<AuthContextType | null>(null);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const { toast } = useToast();
  
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<AuthUser | null, Error>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/user");
        if (res.status === 401) {
          return null;
        }
        return await res.json();
      } catch (err) {
        return null;
      }
    },
  });

  const loginMutation = useMutation<AuthUser, Error, LoginForm>({
    mutationFn: async (credentials) => {
      const res = await apiRequest("POST", "/api/login", credentials);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Login failed");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/user"], data);
      toast({
        title: "Login successful",
        description: `Welcome back, ${data.username}!`,
      });
    },
    onError: (error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation<AuthUser, Error, RegistrationForm>({
    mutationFn: async (userData) => {
      const res = await apiRequest("POST", "/api/register", userData);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Registration failed");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/user"], data);
      toast({
        title: "Registration successful",
        description: `Welcome to TireMax, ${data.username}!`,
      });
    },
    onError: (error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation<void, Error, void>({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/logout");
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Logout failed");
      }
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const updateProfileMutation = useMutation<AuthUser, Error, ProfileUpdateForm>({
    mutationFn: async (profileData) => {
      const res = await apiRequest("PUT", "/api/user", profileData);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Profile update failed");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/user"], data);
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Profile update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const changePasswordMutation = useMutation<{ message: string }, Error, PasswordChangeForm>({
    mutationFn: async (passwordData) => {
      const res = await apiRequest("POST", "/api/change-password", passwordData);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Password change failed");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Password changed",
        description: data.message || "Your password has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Password change failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  return (
    <AuthContext.Provider value={{
      user: user || null,
      isLoading,
      error,
      loginMutation,
      registerMutation,
      logoutMutation,
      updateProfileMutation,
      changePasswordMutation,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
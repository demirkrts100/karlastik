// Test Order Creator Script
// This script creates test orders with various statuses for tracking testing
import fetch from 'node-fetch';

async function createTestOrders() {
    console.log('🔍 Creating test orders for tracking tests');
    
    const testSessionId = 'test-session-' + Date.now();
    const testEmail = 'test@example.com';
    
    try {
        // Test different statuses for tracking
        const statusesToTest = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
        const createdOrders = [];
        
        // First create a cart item
        console.log('1. Creating cart item...');
        const cartResponse = await fetch('http://localhost:5000/api/cart/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                sessionId: testSessionId,
                tireId: 1,
                quantity: 4,
                price: '149.99'
            })
        });
        
        if (!cartResponse.ok) {
            throw new Error(`Failed to create cart item: ${cartResponse.status}`);
        }
        
        const cartItem = await cartResponse.json();
        console.log(`✅ Added test item to cart`);
        
        // Now create orders with different statuses
        for (const status of statusesToTest) {
            console.log(`\n2. Creating test order with status: ${status}`);
            
            const orderResponse = await fetch('http://localhost:5000/api/order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sessionId: testSessionId,
                    customerEmail: testEmail,
                    customerName: 'Test Customer',
                    shippingAddress: '123 Test Street, Testville, CA 12345',
                    totalAmount: '599.96',
                    status: status
                })
            });
            
            if (!orderResponse.ok) {
                throw new Error(`Failed to create order with status ${status}: ${orderResponse.status}`);
            }
            
            const order = await orderResponse.json();
            console.log(`✅ Created order #${order.id} with status: ${status}`);
            createdOrders.push(order);
            
            // For shipped and delivered orders, also create a tracking number
            if (status === 'shipped' || status === 'delivered') {
                // This would normally be done on the backend, but we're manually updating for testing
                console.log(`   Generating tracking number for ${status} order...`);
                
                const updateResponse = await fetch(`http://localhost:5000/api/orders/${order.id}/tracking`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        trackingNumber: `TRK${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`
                    })
                });
                
                if (!updateResponse.ok) {
                    console.warn(`   ⚠️ Couldn't set tracking number. This is OK if the API endpoint doesn't exist yet.`);
                } else {
                    console.log(`   ✅ Added tracking number to ${status} order`);
                }
            }
        }
        
        // Display summary of created orders
        console.log('\n📝 Created test orders with the following IDs:');
        createdOrders.forEach(order => {
            console.log(`   - Order #${order.id} (${order.status})`);
        });
        
        console.log('\n👉 You can use these orders to test the tracking page at /track-order');
        console.log('   Use any order number from above with the email: test@example.com');
        
    } catch (error) {
        console.error('❌ Test failed with error:', error);
    }
}

// Run the test order creation
createTestOrders();
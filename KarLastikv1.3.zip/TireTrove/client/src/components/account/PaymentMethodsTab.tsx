import { useState } from 'react';
import { CreditCard, Plus, Check, Trash2, Edit } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { usePaymentMethods } from '@/hooks/usePaymentMethods';
import PaymentMethodForm from './PaymentMethodForm';
import { FaCcVisa, FaCcMastercard, FaCcAmex, FaCcDiscover, FaCreditCard } from "react-icons/fa";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';

const PaymentMethodsTab = () => {
  const { 
    paymentMethods, 
    isLoading, 
    deletePaymentMethodMutation, 
    setDefaultPaymentMethodMutation 
  } = usePaymentMethods();
  
  const [isAddFormOpen, setIsAddFormOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  
  // Get a card icon based on the card type
  const getCardTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'visa':
        return <FaCcVisa size={32} className="text-blue-600" />;
      case 'mastercard':
        return <FaCcMastercard size={32} className="text-blue-500" />;
      case 'amex':
        return <FaCcAmex size={32} className="text-blue-400" />;
      case 'discover':
        return <FaCcDiscover size={32} className="text-orange-500" />;
      default:
        return <FaCreditCard size={32} className="text-gray-500" />;
    }
  };
  
  // Function to format card number as **** **** **** 1234
  const formatCardNumber = (lastFour: string) => {
    return `•••• •••• •••• ${lastFour}`;
  };
  
  // Handle setting a card as default
  const handleSetDefault = async (id: number) => {
    await setDefaultPaymentMethodMutation.mutateAsync(id);
  };
  
  // Handle deleting a card
  const handleDelete = async (id: number) => {
    await deletePaymentMethodMutation.mutateAsync(id);
    setDeletingId(null);
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Payment Methods</CardTitle>
          <CardDescription>
            Manage your saved payment methods
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-[120px] w-full rounded-md" />
            <Skeleton className="h-[120px] w-full rounded-md" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Payment Methods</CardTitle>
          <CardDescription>
            Manage your saved payment methods
          </CardDescription>
        </div>
        <Button onClick={() => setIsAddFormOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Card
        </Button>
      </CardHeader>
      <CardContent>
        {paymentMethods.length === 0 ? (
          <div className="text-center py-8">
            <CreditCard className="h-12 w-12 mx-auto text-neutral-300 mb-2" />
            <h3 className="text-lg font-medium">No payment methods saved</h3>
            <p className="text-neutral-500 mt-1">Add a payment method to make checkout faster</p>
            <Button className="mt-4" onClick={() => setIsAddFormOpen(true)}>
              Add Payment Method
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {paymentMethods.map((method) => (
              <div
                key={method.id}
                className="p-4 border rounded-lg flex flex-col md:flex-row md:items-center md:justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  {getCardTypeIcon(method.cardType)}
                  <div>
                    <p className="font-medium">{formatCardNumber(method.lastFourDigits)}</p>
                    <p className="text-sm text-neutral-500">
                      {method.cardholderName} | Expires {method.expiryMonth}/{method.expiryYear}
                    </p>
                  </div>
                  {method.isDefault && (
                    <span className="ml-2 text-xs bg-primary/10 text-primary px-2 py-1 rounded-full flex items-center">
                      <Check className="h-3 w-3 mr-1" /> Default
                    </span>
                  )}
                </div>
                
                <div className="flex items-center space-x-2 self-end md:self-auto">
                  {!method.isDefault && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleSetDefault(method.id)}
                    >
                      Set Default
                    </Button>
                  )}
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          width="16" 
                          height="16" 
                          viewBox="0 0 24 24" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2" 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          className="h-4 w-4"
                        >
                          <circle cx="12" cy="12" r="1" />
                          <circle cx="19" cy="12" r="1" />
                          <circle cx="5" cy="12" r="1" />
                        </svg>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <DropdownMenuItem 
                            onSelect={(e) => {
                              e.preventDefault();
                              setDeletingId(method.id);
                            }}
                            className="text-destructive focus:bg-destructive focus:text-destructive-foreground"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Payment Method</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this payment method?
                              This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setDeletingId(null)}>
                              Cancel
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(method.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      
      <PaymentMethodForm
        isOpen={isAddFormOpen}
        onClose={() => setIsAddFormOpen(false)}
      />
    </Card>
  );
};

export default PaymentMethodsTab;
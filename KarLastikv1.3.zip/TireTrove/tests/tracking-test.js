// Order Tracking Test Script
// This script tests the order tracking endpoint by creating a test order
// and then verifying that it can be tracked properly

import { storage } from '../server/storage.ts';
import fetch from 'node-fetch';

async function runTest() {
    console.log('🔍 Running Order Tracking Test');
    
    // Step 1: Create a test order
    console.log('\n📦 Creating test order...');
    
    const testSessionId = 'test-session-' + Date.now();
    const testEmail = 'test@example.com';
    
    try {
        // Create a test order with various statuses for testing
        // We'll create several orders with different statuses to test all scenarios
        const statusesToTest = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
        const createdOrders = [];
        
        for (const status of statusesToTest) {
            const order = await storage.createOrder({
                sessionId: testSessionId,
                status: status,
                customerEmail: testEmail,
                customerName: 'Test Customer',
                shippingAddress: '123 Test Street, Testville, CA 12345',
                totalAmount: '599.96',
                createdAt: new Date()
            });
            
            console.log(`✅ Created order #${order.id} with status: ${status}`);
            createdOrders.push(order);
        }
        
        // Step 2: Test tracking each order
        console.log('\n🔍 Testing order tracking endpoint...');
        
        for (const order of createdOrders) {
            console.log(`\n📝 Testing order #${order.id} with status: ${order.status}`);
            
            // Make a request to the tracking endpoint
            const response = await fetch('http://localhost:5000/api/orders/track', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    orderNumber: order.id.toString(),
                    email: testEmail
                })
            });
            
            if (!response.ok) {
                throw new Error(`Failed to track order #${order.id}. Status: ${response.status}`);
            }
            
            const trackingData = await response.json();
            
            // Verify tracking response contains expected data
            console.log(`✅ Successfully tracked order #${order.id}`);
            console.log(`   Status: ${trackingData.status}`);
            console.log(`   Status History Items: ${trackingData.statusHistory.length}`);
            
            // Verify status history is correctly generated based on current status
            if (order.status === 'pending') {
                if (trackingData.statusHistory.length !== 1) {
                    console.error(`❌ Expected 1 status history item for pending order, got ${trackingData.statusHistory.length}`);
                } else {
                    console.log('✅ Status history correct for pending order');
                }
            } else if (order.status === 'processing') {
                if (trackingData.statusHistory.length !== 2) {
                    console.error(`❌ Expected 2 status history items for processing order, got ${trackingData.statusHistory.length}`);
                } else {
                    console.log('✅ Status history correct for processing order');
                }
            } else if (order.status === 'shipped') {
                if (trackingData.statusHistory.length !== 3) {
                    console.error(`❌ Expected 3 status history items for shipped order, got ${trackingData.statusHistory.length}`);
                } else {
                    console.log('✅ Status history correct for shipped order');
                }
            } else if (order.status === 'delivered') {
                if (trackingData.statusHistory.length !== 4) {
                    console.error(`❌ Expected 4 status history items for delivered order, got ${trackingData.statusHistory.length}`);
                } else {
                    console.log('✅ Status history correct for delivered order');
                }
            } else if (order.status === 'cancelled') {
                if (trackingData.statusHistory.length !== 2) {
                    console.error(`❌ Expected 2 status history items for cancelled order, got ${trackingData.statusHistory.length}`);
                } else {
                    console.log('✅ Status history correct for cancelled order');
                }
            }
            
            // Check if shipped/delivered orders have tracking numbers
            if (order.status === 'shipped' || order.status === 'delivered') {
                if (!trackingData.trackingNumber) {
                    console.error('❌ Shipped/delivered order missing tracking number');
                } else {
                    console.log(`✅ Order has tracking number: ${trackingData.trackingNumber}`);
                }
            }
        }
        
        // Step 3: Test invalid tracking scenarios
        console.log('\n🧪 Testing invalid tracking scenarios...');
        
        // Test with non-existent order number
        let invalidResponse = await fetch('http://localhost:5000/api/orders/track', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                orderNumber: '99999',
                email: testEmail
            })
        });
        
        if (invalidResponse.status === 404) {
            console.log('✅ Correctly rejected non-existent order number');
        } else {
            console.error(`❌ Expected 404 for non-existent order, got ${invalidResponse.status}`);
        }
        
        // Test with wrong email
        invalidResponse = await fetch('http://localhost:5000/api/orders/track', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                orderNumber: createdOrders[0].id.toString(),
                email: 'wrong@example.com'
            })
        });
        
        if (invalidResponse.status === 404) {
            console.log('✅ Correctly rejected tracking with wrong email');
        } else {
            console.error(`❌ Expected 404 for wrong email, got ${invalidResponse.status}`);
        }
        
        // Test with missing fields
        invalidResponse = await fetch('http://localhost:5000/api/orders/track', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: testEmail
                // Missing orderNumber
            })
        });
        
        if (invalidResponse.status === 400) {
            console.log('✅ Correctly rejected request with missing orderNumber');
        } else {
            console.error(`❌ Expected 400 for missing orderNumber, got ${invalidResponse.status}`);
        }
        
        console.log('\n✅ Order tracking tests completed successfully!');
        console.log('📝 Created test orders with IDs:');
        createdOrders.forEach(order => {
            console.log(`   - Order #${order.id} (${order.status})`);
        });
        console.log('\n👉 You can use these orders to manually test the tracking page at /track-order');
        console.log('   Use order number and email: test@example.com');
    } catch (error) {
        console.error('❌ Test failed with error:', error);
    }
}

// Run the test
runTest();
import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/components/auth/AuthProvider";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Redirect, useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, XCircle, Info, Package, TruckIcon, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";

// Admin Review Management Tab
const ReviewModeration = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: pendingReviews, isLoading: isPendingReviewsLoading } = useQuery({
    queryKey: ['/api/admin/reviews/pending'],
    retry: false
  });
  
  const moderateReviewMutation = useMutation({
    mutationFn: async ({ id, isApproved, moderationNotes }: { id: number, isApproved: boolean, moderationNotes: string | null }) => {
      const response = await apiRequest('PUT', `/api/admin/reviews/${id}/moderate`, { isApproved, moderationNotes });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/reviews/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/reviews'] });
      toast({
        title: "Review moderated successfully",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to moderate review",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleModerateReview = (id: number, isApproved: boolean, moderationNotes: string | null = null) => {
    moderateReviewMutation.mutate({ id, isApproved, moderationNotes });
  };
  
  if (isPendingReviewsLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!pendingReviews || pendingReviews.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
        <h3 className="text-xl font-medium mb-2">No Reviews Pending Approval</h3>
        <p className="text-muted-foreground">All reviews have been moderated.</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Pending Reviews</h2>
        <div className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium flex items-center">
          <AlertCircle className="h-4 w-4 mr-1" />
          {pendingReviews.length} Pending
        </div>
      </div>
      
      {pendingReviews.map((review: any) => (
        <Card key={review.id} className="overflow-hidden">
          <CardHeader className="bg-muted/50 pb-4">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  Review for {review.tireName || "Unknown Product"}
                </CardTitle>
                <CardDescription>
                  By {review.userName} • {format(new Date(review.createdAt), 'MMM d, yyyy')}
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleModerateReview(review.id, false, "Violates community guidelines")}
                  disabled={moderateReviewMutation.isPending}
                  className="border-red-300 hover:bg-red-50 text-red-600 hover:text-red-700"
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Reject
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleModerateReview(review.id, true)}
                  disabled={moderateReviewMutation.isPending}
                  className="border-green-300 hover:bg-green-50 text-green-600 hover:text-green-700"
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Approve
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="flex gap-2 mb-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <span 
                  key={i} 
                  className={`text-xl ${i < review.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                >
                  ★
                </span>
              ))}
            </div>
            <p className="text-sm mb-4">{review.comment}</p>
            
            {review.images && review.images.length > 0 && (
              <div className="flex gap-2 mb-4">
                {review.images.map((image: string, idx: number) => (
                  <img 
                    key={idx} 
                    src={image} 
                    alt={`Review image ${idx + 1}`} 
                    className="w-20 h-20 object-cover rounded-md border"
                  />
                ))}
              </div>
            )}
            
            {review.userVehicle && (
              <div className="text-sm text-muted-foreground flex items-center">
                <Info className="h-4 w-4 mr-1" />
                Vehicle: {review.userVehicle}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

// Admin Order Management Tab
const OrderManagement = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: orders, isLoading: isOrdersLoading } = useQuery({
    queryKey: ['/api/admin/orders'],
    retry: false
  });
  
  const updateOrderMutation = useMutation({
    mutationFn: async ({ id, update }: { id: number, update: any }) => {
      const response = await apiRequest('PUT', `/api/admin/orders/${id}`, update);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/orders'] });
      toast({
        title: "Order updated successfully",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update order",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const updateOrderStatus = (id: number, status: string) => {
    updateOrderMutation.mutate({ 
      id, 
      update: { 
        status,
        lastUpdated: new Date()
      } 
    });
  };
  
  // Simplified for this implementation - would normally have a form for tracking details
  const updateOrderTracking = (id: number, carrier: string, trackingNumber: string) => {
    updateOrderMutation.mutate({
      id,
      update: {
        carrier,
        trackingNumber,
        lastUpdated: new Date()
      }
    });
  };
  
  if (isOrdersLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!orders || orders.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <Package className="h-12 w-12 text-gray-400 mb-4" />
        <h3 className="text-xl font-medium mb-2">No Orders Found</h3>
        <p className="text-muted-foreground">There are no orders in the system yet.</p>
      </div>
    );
  }
  
  // Group orders by status
  const pendingOrders = orders.filter((order: any) => 
    order.status === 'pending' || order.status === 'processing'
  );
  
  const shippedOrders = orders.filter((order: any) => 
    order.status === 'shipped'
  );
  
  const completedOrders = orders.filter((order: any) => 
    order.status === 'delivered' || order.status === 'completed'
  );
  
  return (
    <div className="space-y-8">
      {/* Pending Orders Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Package className="h-5 w-5 text-amber-500" />
          <h2 className="text-xl font-semibold">Pending Orders</h2>
          <div className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium">
            {pendingOrders.length}
          </div>
        </div>
        
        {pendingOrders.length === 0 ? (
          <p className="text-muted-foreground italic">No pending orders</p>
        ) : (
          <div className="space-y-4">
            {pendingOrders.map((order: any) => (
              <Card key={order.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <div>
                      <CardTitle className="text-base">Order #{order.id}</CardTitle>
                      <CardDescription>
                        {format(new Date(order.createdAt), 'MMM d, yyyy')} • ${order.totalAmount}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateOrderStatus(order.id, 'shipped')}
                        disabled={updateOrderMutation.isPending}
                      >
                        <TruckIcon className="h-4 w-4 mr-1" />
                        Mark Shipped
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-sm space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Customer:</span>
                      <span className="font-medium">{order.customerName || 'Guest'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Email:</span>
                      <span>{order.customerEmail}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <span className="capitalize font-medium">{order.status}</span>
                    </div>
                    {order.shippingAddress && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Ship to:</span>
                        <span className="text-right">{order.shippingAddress}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      {/* Shipped Orders Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <TruckIcon className="h-5 w-5 text-blue-500" />
          <h2 className="text-xl font-semibold">Shipped Orders</h2>
          <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
            {shippedOrders.length}
          </div>
        </div>
        
        {shippedOrders.length === 0 ? (
          <p className="text-muted-foreground italic">No shipped orders</p>
        ) : (
          <div className="space-y-4">
            {shippedOrders.map((order: any) => (
              <Card key={order.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <div>
                      <CardTitle className="text-base">Order #{order.id}</CardTitle>
                      <CardDescription>
                        Shipped on {order.lastUpdated ? format(new Date(order.lastUpdated), 'MMM d, yyyy') : 'Unknown'}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => updateOrderStatus(order.id, 'delivered')}
                        disabled={updateOrderMutation.isPending}
                        className="border-green-300 hover:bg-green-50 text-green-600 hover:text-green-700"
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Mark Delivered
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-sm space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Customer:</span>
                      <span className="font-medium">{order.customerName || 'Guest'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Email:</span>
                      <span>{order.customerEmail}</span>
                    </div>
                    {order.trackingNumber && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Tracking:</span>
                        <span className="font-medium">{order.trackingNumber}</span>
                      </div>
                    )}
                    {order.carrier && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Carrier:</span>
                        <span>{order.carrier}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      {/* Simplified view of Completed Orders */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <CheckCircle className="h-5 w-5 text-green-500" />
          <h2 className="text-xl font-semibold">Completed Orders</h2>
          <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
            {completedOrders.length}
          </div>
        </div>
        
        {completedOrders.length === 0 ? (
          <p className="text-muted-foreground italic">No completed orders</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {completedOrders.map((order: any) => (
              <Card key={order.id}>
                <CardHeader className="py-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-sm">Order #{order.id}</CardTitle>
                      <CardDescription className="text-xs">
                        Completed {order.lastUpdated ? format(new Date(order.lastUpdated), 'MMM d, yyyy') : 'Unknown'}
                      </CardDescription>
                    </div>
                    <div className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">
                      {order.status}
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Main Admin Page Component
const AdminPage = () => {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!user || user.role !== 'admin') {
    // Redirect non-admin users
    return <Redirect to="/" />;
  }
  
  return (
    <>
      <Helmet>
        <title>Admin Dashboard | TireHub</title>
        <meta name="description" content="Admin dashboard for TireHub marketplace - manage reviews, orders and inventory" />
      </Helmet>
      
      <div className="container max-w-screen-xl mx-auto py-8 px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage reviews, orders, and content</p>
          </div>
          <Button onClick={() => setLocation("/")} variant="outline">
            Return to Site
          </Button>
        </div>
        
        <Tabs defaultValue="reviews" className="w-full">
          <TabsList className="w-full md:w-auto grid grid-cols-2 md:flex mb-6">
            <TabsTrigger value="reviews">Review Moderation</TabsTrigger>
            <TabsTrigger value="orders">Order Management</TabsTrigger>
          </TabsList>
          <Separator className="mb-6" />
          
          <TabsContent value="reviews" className="mt-0">
            <ReviewModeration />
          </TabsContent>
          
          <TabsContent value="orders" className="mt-0">
            <OrderManagement />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default AdminPage;
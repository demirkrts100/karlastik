import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import createMemoryStore from "memorystore";
import crypto, { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";

// Extend Express.User to use our User type
declare global {
  namespace Express {
    interface User extends User {}
  }
}

const scryptAsync = promisify(scrypt);
const MemoryStore = createMemoryStore(session);

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

/**
 * Check if a password meets security requirements
 * @param password The password to validate
 * @returns Array of issues found with the password, empty if password is valid
 */
function validatePasswordStrength(password: string): string[] {
  const issues: string[] = [];
  
  if (password.length < 8) {
    issues.push("Password must be at least 8 characters long");
  }
  
  if (!/[A-Z]/.test(password)) {
    issues.push("Password must contain at least one uppercase letter");
  }
  
  if (!/[a-z]/.test(password)) {
    issues.push("Password must contain at least one lowercase letter");
  }
  
  if (!/[0-9]/.test(password)) {
    issues.push("Password must contain at least one number");
  }
  
  if (!/[^A-Za-z0-9]/.test(password)) {
    issues.push("Password must contain at least one special character");
  }
  
  // Check for common passwords
  const commonPasswords = [
    "password", "123456", "12345678", "qwerty", "admin", 
    "welcome", "123123", "password123", "letmein"
  ];
  
  if (commonPasswords.some(common => 
    password.toLowerCase().includes(common))) {
    issues.push("Password contains common phrases that are easily guessed");
  }
  
  return issues;
}

export async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  try {
    // Make sure the stored password is in the correct format
    if (!stored.includes('.')) {
      console.error('Invalid stored password format. No salt separator found.');
      return false;
    }
    
    const [hashed, salt] = stored.split(".");
    console.log(`Password comparison - Hash length: ${hashed.length}, Salt: ${salt}`);
    
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    
    console.log(`Password comparison - HashedBuf length: ${hashedBuf.length}, SuppliedBuf length: ${suppliedBuf.length}`);
    
    // Check if the buffers have the same length before comparing
    if (hashedBuf.length !== suppliedBuf.length) {
      console.error(`Buffer length mismatch: ${hashedBuf.length} vs ${suppliedBuf.length}`);
      return false;
    }
    
    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error('Error in password comparison:', error);
    return false;
  }
}

export function setupAuth(app: Express) {
  // Create memory session store
  const sessionStore = new MemoryStore({
    checkPeriod: 86400000 // Prune expired entries every 24h
  });

  // Configure default session settings (without "remember me")
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "tiremax-session-secret",
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24, // 1 day default
      httpOnly: true,
      sameSite: "lax"
    }
  };

  // If in production, set secure cookie
  if (app.get("env") === "production") {
    app.set("trust proxy", 1);
    if (sessionSettings.cookie) {
      sessionSettings.cookie.secure = true;
    }
  }

  // Set up session middleware
  app.use(session(sessionSettings));
  
  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Set up local strategy for authentication
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        
        if (!user) {
          return done(null, false, { message: "User not found" });
        }
        
        // Check if account is suspended
        if (user.status === "suspended") {
          return done(null, false, { message: "This account has been suspended" });
        }
        
        const isValid = await comparePasswords(password, user.password);
        
        if (!isValid) {
          return done(null, false, { message: "Incorrect password" });
        }
        
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  // Serialize user to store in session
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  // Deserialize user from session
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUserById(id);
      if (!user) {
        return done(new Error("User not found"), null);
      }
      done(null, user);
    } catch (err) {
      done(err, null);
    }
  });

  // Register route
  app.post("/api/register", async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { username, email, password, confirmPassword } = req.body;
      
      // Check if passwords match
      if (password !== confirmPassword) {
        return res.status(400).json({ message: "Passwords do not match" });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      // Validate password strength
      const passwordIssues = validatePasswordStrength(password);
      if (passwordIssues.length > 0) {
        return res.status(400).json({ 
          message: "Password does not meet security requirements", 
          issues: passwordIssues 
        });
      }
      
      // Hash password
      const hashedPassword = await hashPassword(password);
      
      // Create user
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword
      });
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      // Log user in
      req.login(user, (err) => {
        if (err) return next(err);
        return res.status(201).json(userWithoutPassword);
      });
    } catch (err) {
      next(err);
    }
  });

  // Track failed login attempts
  const failedLoginAttempts = new Map<string, { count: number, lastAttempt: Date }>();
  const MAX_FAILED_ATTEMPTS = 5;
  const LOCKOUT_TIME = 15 * 60 * 1000; // 15 minutes in milliseconds
  
  // Login route
  app.post("/api/login", (req: Request, res: Response, next: NextFunction) => {
    const { username, rememberMe } = req.body;
    
    // Check if account is locked
    const userAttempts = failedLoginAttempts.get(username);
    if (userAttempts && userAttempts.count >= MAX_FAILED_ATTEMPTS) {
      const timeElapsed = Date.now() - userAttempts.lastAttempt.getTime();
      if (timeElapsed < LOCKOUT_TIME) {
        const minutesLeft = Math.ceil((LOCKOUT_TIME - timeElapsed) / 60000);
        return res.status(429).json({ 
          message: `Account temporarily locked due to multiple failed login attempts. Please try again in ${minutesLeft} minutes.` 
        });
      } else {
        // Reset failed attempts after lockout period
        failedLoginAttempts.delete(username);
      }
    }
    
    passport.authenticate("local", (err: Error | null, user: User | false, info: { message: string } | undefined) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        // Track failed login attempt
        if (!userAttempts) {
          failedLoginAttempts.set(username, { count: 1, lastAttempt: new Date() });
        } else {
          userAttempts.count += 1;
          userAttempts.lastAttempt = new Date();
          failedLoginAttempts.set(username, userAttempts);
        }
        
        const attemptsLeft = MAX_FAILED_ATTEMPTS - (userAttempts?.count || 1);
        let errorMsg = info?.message || "Authentication failed";
        
        if (attemptsLeft > 0 && attemptsLeft < MAX_FAILED_ATTEMPTS) {
          errorMsg += `. ${attemptsLeft} attempts remaining before your account is temporarily locked.`;
        }
        
        return res.status(401).json({ message: errorMsg });
      }
      
      // Check if the account is suspended
      if (user.status === 'suspended') {
        return res.status(403).json({ 
          message: "Your account has been suspended. Please contact customer support for assistance.",
          status: 'suspended'
        });
      }
      
      // Reset failed login attempts on successful login
      failedLoginAttempts.delete(username);
      
      // Set session expiration based on Remember Me option
      if (req.session && req.session.cookie && rememberMe) {
        req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 30; // 30 days
      }
      
      req.login(user, (loginErr) => {
        if (loginErr) {
          return next(loginErr);
        }
        
        // Remove password from response
        const { password: _, ...userWithoutPassword } = user;
        
        return res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  // Logout route
  app.post("/api/logout", (req: Request, res: Response) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.sendStatus(200);
    });
  });

  // Get current user route
  app.get("/api/user", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Check if the user's status has changed since login (e.g., if admin suspended the account)
    const freshUser = await storage.getUserById(req.user.id);
    if (!freshUser) {
      // User might have been deleted, log them out
      req.logout((err) => {
        if (err) {
          return res.status(500).json({ message: "Logout failed" });
        }
        return res.status(401).json({ message: "User no longer exists" });
      });
      return;
    }
    
    // If user has been suspended since login, log them out
    if (freshUser.status === "suspended") {
      req.logout((err) => {
        if (err) {
          return res.status(500).json({ message: "Logout failed" });
        }
        return res.status(403).json({ message: "This account has been suspended" });
      });
      return;
    }
    
    // Update the session with the latest user data
    req.user = freshUser;
    
    // Remove password from response
    const { password: _, ...userWithoutPassword } = freshUser;
    
    res.json(userWithoutPassword);
  });
  
  // Update user route
  app.put("/api/user", async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.user.id;
      
      // Don't allow updating username, email, or password through this endpoint
      const { username, email, password, ...updateData } = req.body;
      
      // Update user in database
      const updatedUser = await storage.updateUser(userId, updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = updatedUser;
      
      // Update session
      req.login(updatedUser, (err) => {
        if (err) return next(err);
        return res.json(userWithoutPassword);
      });
    } catch (err) {
      next(err);
    }
  });
  
  // Add password change endpoint
  app.post("/api/change-password", async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.user.id;
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current password and new password are required" });
      }
      
      // Get current user with password
      const user = await storage.getUserById(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify current password
      const isPasswordValid = await comparePasswords(currentPassword, user.password);
      
      if (!isPasswordValid) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }
      
      // Check if new password is same as current
      if (currentPassword === newPassword) {
        return res.status(400).json({ message: "New password must be different from current password" });
      }
      
      // Perform password strength validation
      const passwordIssues = validatePasswordStrength(newPassword);
      if (passwordIssues.length > 0) {
        return res.status(400).json({ 
          message: "Password does not meet security requirements", 
          issues: passwordIssues 
        });
      }
      
      // Hash new password
      const hashedPassword = await hashPassword(newPassword);
      
      // Update password in database
      const updatedUser = await storage.updateUser(userId, { password: hashedPassword });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update password" });
      }
      
      return res.status(200).json({ message: "Password updated successfully" });
    } catch (err) {
      next(err);
    }
  });
  
  // Forgot password route
  app.post("/api/forgot-password", async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      // Check if user exists
      const user = await storage.getUserByEmail(email);
      
      // Always return a success response even if the email doesn't exist
      // This prevents user enumeration attacks
      if (!user) {
        return res.status(200).json({ 
          message: "If an account with that email exists, a password reset link has been sent" 
        });
      }
      
      // Generate a secure random token
      const resetToken = randomBytes(32).toString('hex');
      
      // Store the token with the user (expires in 1 hour)
      await storage.setResetToken(email, resetToken, 1);
      
      // In a real application, send an email with the reset link
      // For now, we'll just return the token in the response
      console.log(`Reset token for ${email}: ${resetToken}`);
      
      return res.status(200).json({ 
        message: "If an account with that email exists, a password reset link has been sent",
        token: resetToken // Remove this in production
      });
    } catch (err) {
      next(err);
    }
  });
  
  // Reset password route
  app.post("/api/reset-password", async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { token, password, confirmPassword } = req.body;
      
      if (!token || !password || !confirmPassword) {
        return res.status(400).json({ message: "Token, password, and password confirmation are required" });
      }
      
      // Check if passwords match
      if (password !== confirmPassword) {
        return res.status(400).json({ message: "Passwords do not match" });
      }
      
      // Perform password strength validation
      const passwordIssues = validatePasswordStrength(password);
      if (passwordIssues.length > 0) {
        return res.status(400).json({ 
          message: "Password does not meet security requirements", 
          issues: passwordIssues 
        });
      }
      
      // Get user by reset token
      const user = await storage.getUserByResetToken(token);
      
      if (!user) {
        return res.status(400).json({ message: "Invalid or expired token" });
      }
      
      // Hash new password
      const hashedPassword = await hashPassword(password);
      
      // Update user password and clear reset token
      const updatedUser = await storage.updateUser(user.id, { 
        password: hashedPassword,
        resetToken: null,
        resetTokenExpiry: null
      });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to reset password" });
      }
      
      return res.status(200).json({ message: "Password has been reset successfully" });
    } catch (err) {
      next(err);
    }
  });
}
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/components/auth/AuthProvider';
import { Star, Pencil, Loader2, Trash2, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger
} from '@/components/ui/alert-dialog';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Textarea } from '@/components/ui/textarea';
import { Review, Tire } from '@shared/schema';
import { Link } from 'wouter';

type UserReview = Review & {
  tire: Tire;
};

// Component to render star ratings
const RatingStars = ({ rating }: { rating: number }) => {
  const stars = [];
  for (let i = 0; i < 5; i++) {
    stars.push(
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
      />
    );
  }
  return <div className="flex">{stars}</div>;
};

const ReviewsTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [editReviewData, setEditReviewData] = useState<{ review: UserReview; isOpen: boolean }>({
    review: {} as UserReview,
    isOpen: false,
  });
  const [deleteReviewId, setDeleteReviewId] = useState<number | null>(null);
  const [editRating, setEditRating] = useState(0);
  const [editComment, setEditComment] = useState('');

  // Fetch user reviews from backend
  const {
    data: userReviews = [],
    isLoading,
    isError,
    error,
    refetch
  } = useQuery<UserReview[]>({
    queryKey: ['/api/reviews/user'],
    enabled: !!user,
  });

  // Function to open edit dialog
  const openEditDialog = (review: UserReview) => {
    setEditReviewData({
      review,
      isOpen: true,
    });
    setEditRating(review.rating);
    setEditComment(review.comment);
  };

  // Function to close edit dialog
  const closeEditDialog = () => {
    setEditReviewData({
      review: {} as UserReview,
      isOpen: false,
    });
    setEditRating(0);
    setEditComment('');
  };

  // Function to handle star rating selection in edit dialog
  const handleStarClick = (rating: number) => {
    setEditRating(rating);
  };

  // Function to update review
  const handleUpdateReview = async () => {
    try {
      await apiRequest('PUT', `/api/reviews/${editReviewData.review.id}`, {
        rating: editRating,
        comment: editComment,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/reviews/user'] });
      toast({
        title: 'Review Updated',
        description: 'Your review has been updated successfully.',
      });
      closeEditDialog();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update review.',
        variant: 'destructive',
      });
    }
  };

  // Function to delete review
  const handleDeleteReview = async () => {
    if (!deleteReviewId) return;
    
    try {
      await apiRequest('DELETE', `/api/reviews/${deleteReviewId}`);
      
      queryClient.invalidateQueries({ queryKey: ['/api/reviews/user'] });
      toast({
        title: 'Review Deleted',
        description: 'Your review has been deleted successfully.',
      });
      setDeleteReviewId(null);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete review.',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500">Error loading your reviews: {error?.message}</p>
        <Button onClick={() => refetch()} className="mt-4">
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>My Reviews</CardTitle>
        <CardDescription>
          Manage reviews you've left on products
        </CardDescription>
      </CardHeader>
      <CardContent>
        {userReviews.length === 0 ? (
          <div className="text-center py-8">
            <div className="mx-auto w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mb-4">
              <Star className="h-6 w-6 text-neutral-400" />
            </div>
            <h3 className="text-lg font-medium">No reviews yet</h3>
            <p className="text-neutral-500 mt-1">You haven't written any product reviews yet.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {userReviews.map((review) => (
              <div key={review.id} className="border rounded-lg p-4 hover:shadow-sm transition-shadow">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium">{review.tire.name}</h3>
                    <div className="flex items-center mt-1 mb-2">
                      <RatingStars rating={review.rating} />
                      <span className="ml-2 text-sm text-neutral-500">
                        {review.createdAt ? new Date(review.createdAt).toLocaleDateString() : 'Unknown date'}
                      </span>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => openEditDialog(review)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <AlertDialog open={deleteReviewId === review.id} onOpenChange={(open) => !open && setDeleteReviewId(null)}>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setDeleteReviewId(review.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Review</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete this review? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={handleDeleteReview}
                            className="bg-red-500 hover:bg-red-600"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
                <p className="text-neutral-700">{review.comment}</p>
                <Separator className="my-4" />
                <div className="flex items-center">
                  <img 
                    src={review.tire.imageUrl} 
                    alt={review.tire.name} 
                    className="w-12 h-12 object-contain mr-3"
                  />
                  <div>
                    <div className="text-sm text-neutral-500">Size: {review.tire.size}</div>
                    <div className="text-sm font-medium">${review.tire.price}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* Edit Review Dialog */}
      <Dialog open={editReviewData.isOpen} onOpenChange={(open) => !open && closeEditDialog()}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Your Review</DialogTitle>
            <DialogDescription>
              Update your review for {editReviewData.review.tire?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <img 
                  src={editReviewData.review.tire?.imageUrl} 
                  alt={editReviewData.review.tire?.name} 
                  className="w-14 h-14 object-contain"
                />
                <div>
                  <h4 className="font-medium">{editReviewData.review.tire?.name}</h4>
                  <div className="text-sm text-neutral-500">Size: {editReviewData.review.tire?.size}</div>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Rating</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    onClick={() => handleStarClick(rating)}
                    className="focus:outline-none"
                  >
                    <Star
                      className={`h-6 w-6 cursor-pointer ${
                        rating <= editRating
                          ? "text-yellow-400 fill-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Review</label>
              <Textarea
                value={editComment}
                onChange={(e) => setEditComment(e.target.value)}
                placeholder="Share your experience with this product..."
                rows={5}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeEditDialog}>
              Cancel
            </Button>
            <Button onClick={handleUpdateReview}>
              Update Review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default ReviewsTab;
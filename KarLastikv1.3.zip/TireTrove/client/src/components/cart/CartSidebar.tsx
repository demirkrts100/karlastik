import { useEffect, useState } from 'react';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { X, Trash2 } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Skeleton } from '@/components/ui/skeleton';
import { CartItem, Tire } from '@shared/schema';

interface EnrichedCartItem extends CartItem {
  tire?: Tire;
}

const CartSidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { cart, updateQuantity, removeItem, clearCart } = useCart();
  const queryClient = useQueryClient();
  
  // Get cart items with product details
  const { data: cartItems, isLoading, refetch } = useQuery<EnrichedCartItem[]>({
    queryKey: ['/api/cart'],
    enabled: isOpen,
    staleTime: 0, // Always refetch when requested
    networkMode: 'always', // Always try to fetch even if offline
    refetchOnWindowFocus: false, // Don't refetch when window regains focus (avoid delays)
  });
  
  // Refetch cart data when the sidebar is opened
  useEffect(() => {
    if (isOpen) {
      refetch();
    }
  }, [isOpen, refetch]);
  
  // Calculate totals
  const subtotal = cartItems?.reduce((sum, item) => {
    const price = item.tire?.discountedPrice || item.tire?.price || 0;
    return sum + (Number(price) * item.quantity);
  }, 0) || 0;
  
  const tax = subtotal * 0.08; // 8% tax rate
  const total = subtotal + tax;
  
  // Handle open/close of sidebar
  useEffect(() => {
    const toggleCart = () => {
      setIsOpen(prev => !prev);
      
      // Also trigger a refetch when opening
      if (!isOpen) {
        queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      }
    };
    
    window.addEventListener('toggleCart', toggleCart);
    
    return () => {
      window.removeEventListener('toggleCart', toggleCart);
    };
  }, [isOpen, queryClient]);
  
  useEffect(() => {
    // Close cart when navigating to checkout
    if (location === '/checkout') {
      setIsOpen(false);
    }
  }, [location]);
  
  const handleUpdateQuantity = async (id: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    // Optimistically update the UI
    const oldCartItems = cartItems ? [...cartItems] : [];
    const updatedCartItems = cartItems?.map(item => 
      item.id === id ? { ...item, quantity: newQuantity } : item
    );
    
    // Calculate new totals
    queryClient.setQueryData(['/api/cart'], updatedCartItems);
    
    try {
      // Send update in the background
      await updateQuantity(id, newQuantity);
      
      // Silent background refresh after server response
      queryClient.invalidateQueries({ 
        queryKey: ['/api/cart'], 
        refetchType: 'none' // Don't trigger loading states
      });
    } catch (error) {
      console.error('Failed to update quantity:', error);
      // Revert to original state if there was an error
      queryClient.setQueryData(['/api/cart'], oldCartItems);
    }
  };
  
  const handleRemoveItem = async (id: number) => {
    // Optimistically update UI first for immediate feedback
    const oldCartItems = cartItems ? [...cartItems] : [];
    const updatedCartItems = cartItems?.filter(item => item.id !== id);
    
    // Update UI immediately
    queryClient.setQueryData(['/api/cart'], updatedCartItems);
    
    try {
      // Send request in the background
      await removeItem(id);
      
      // Silent refresh after server confirms
      queryClient.invalidateQueries({ 
        queryKey: ['/api/cart'],
        refetchType: 'none'
      });
    } catch (error) {
      console.error('Failed to remove item:', error);
      // Restore previous state if error occurs
      queryClient.setQueryData(['/api/cart'], oldCartItems);
    }
  };
  
  const handleClearCart = async () => {
    // Store old cart items for potential rollback
    const oldCartItems = cartItems ? [...cartItems] : [];
    
    // Update UI immediately
    queryClient.setQueryData(['/api/cart'], []);
    
    try {
      // Process in background
      await clearCart();
      
      // Silent refresh without triggering loading states
      queryClient.invalidateQueries({ 
        queryKey: ['/api/cart'],
        refetchType: 'none'
      });
    } catch (error) {
      console.error('Failed to clear cart:', error);
      // Restore previous state on error
      queryClient.setQueryData(['/api/cart'], oldCartItems);
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-50 bg-black/50" onClick={() => setIsOpen(false)}>
      <div 
        className="fixed top-0 right-0 w-full sm:w-3/4 md:w-96 h-full bg-white shadow-lg transform transition-transform duration-300 z-50 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 border-b border-neutral-200 flex justify-between items-center">
          <h3 className="font-bold text-lg">Your Cart ({cart.length})</h3>
          <button 
            className="text-neutral-500 hover:text-neutral-700"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto p-4">
          {isLoading ? (
            Array(2).fill(0).map((_, index) => (
              <div key={index} className="flex border-b border-neutral-200 pb-4 mb-4">
                <Skeleton className="w-20 h-20 rounded" />
                <div className="ml-4 flex-grow">
                  <div className="flex justify-between">
                    <Skeleton className="h-5 w-32 mb-2" />
                    <Skeleton className="h-5 w-5" />
                  </div>
                  <Skeleton className="h-4 w-24 mb-2" />
                  <div className="flex items-center mt-2">
                    <Skeleton className="h-8 w-24" />
                    <Skeleton className="h-4 w-16 ml-auto" />
                  </div>
                </div>
              </div>
            ))
          ) : cartItems && cartItems.length > 0 ? (
            cartItems.map((item) => (
              <div key={item.id} className="flex border-b border-neutral-200 pb-4 mb-4">
                {item.tire && (
                  <>
                    <img 
                      src={item.tire.imageUrl} 
                      alt={item.tire.name} 
                      className="w-20 h-20 object-cover rounded"
                    />
                    <div className="ml-4 flex-grow">
                      <div className="flex justify-between">
                        <h4 className="font-medium">{item.tire.name}</h4>
                        <button 
                          className="text-neutral-500 hover:text-neutral-700"
                          onClick={() => handleRemoveItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="text-sm text-neutral-600">Size: {item.tire.size}</p>
                      <div className="flex items-center mt-2">
                        <div className="flex items-center border border-neutral-300 rounded">
                          <button 
                            className="w-8 h-8 flex items-center justify-center text-neutral-500 hover:bg-neutral-100 active:bg-neutral-200 transition-colors"
                            onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                            </svg>
                          </button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <button 
                            className="w-8 h-8 flex items-center justify-center text-neutral-500 hover:bg-neutral-100 active:bg-neutral-200 transition-colors"
                            onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                            </svg>
                          </button>
                        </div>
                        <span className="ml-auto font-medium">
                          ${((Number(item.tire.discountedPrice || item.tire.price) * item.quantity).toFixed(2))}
                        </span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center h-full">
              <p className="text-neutral-500 mb-4">Your cart is empty</p>
              <Button 
                variant="outline" 
                className="bg-primary text-white hover:bg-primary/90"
                onClick={() => {
                  setIsOpen(false);
                  window.location.href = '/products';
                }}
              >
                Continue Shopping
              </Button>
            </div>
          )}
          
          {cartItems && cartItems.length > 0 && (
            <div className="mb-4">
              <h4 className="font-medium mb-2">Promo Code</h4>
              <div className="flex">
                <input 
                  type="text" 
                  placeholder="Enter code" 
                  className="flex-grow p-2 border border-neutral-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <Button className="bg-neutral-800 hover:bg-neutral-700 text-white font-medium rounded-l-none">
                  Apply
                </Button>
              </div>
            </div>
          )}
        </div>
        
        {cartItems && cartItems.length > 0 && (
          <div className="p-4 border-t border-neutral-200">
            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-neutral-600">Subtotal</span>
                <span className="font-medium">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Shipping</span>
                <span className="font-medium">FREE</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Tax</span>
                <span className="font-medium">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-lg font-bold pt-2 border-t border-neutral-200">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
            
            <Button asChild className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-3 px-4 rounded-lg mb-2">
              <Link href="/checkout">Proceed to Checkout</Link>
            </Button>
            <Button 
              variant="outline" 
              className="w-full bg-white border border-neutral-300 text-neutral-800 font-medium py-3 px-4 rounded-lg hover:bg-neutral-50"
              onClick={() => {
                setIsOpen(false);
                window.location.href = '/products';
              }}
            >
              Continue Shopping
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartSidebar;

import { useQuery } from '@tanstack/react-query';
import { Tire } from '@shared/schema';

interface UseProductsOptions {
  type?: string;
  brand?: string;
  featured?: boolean;
  searchQuery?: string;
}

export const useProducts = (options: UseProductsOptions = {}) => {
  const { type, brand, featured, searchQuery } = options;
  
  // Determine the right endpoint based on options
  let endpoint = '/api/tires';
  
  if (searchQuery) {
    endpoint = `/api/tires/search/${searchQuery}`;
  } else if (featured) {
    endpoint = '/api/tires/featured';
  } else if (type) {
    endpoint = `/api/tires/type/${type}`;
  } else if (brand) {
    endpoint = `/api/tires/brand/${brand}`;
  }
  
  const { data, isLoading, error } = useQuery<Tire[]>({
    queryKey: [endpoint],
  });
  
  return {
    products: data,
    isLoading,
    error,
  };
};

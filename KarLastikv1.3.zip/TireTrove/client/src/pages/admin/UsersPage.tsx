import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Users,
  User,
  UserPlus,
  Search,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Shield,
  LockIcon,
  Eye,
  Pencil,
  Trash2,
  MoreHorizontal,
  Filter,
  Clock,
  ShoppingBag,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { fetchUsers, suspendUser, activateUser, deleteUser } from "@/services/adminService";

interface AdminUsersPageProps {
  title?: string;
}

type UserRole = "customer" | "admin";

interface UserData {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: UserRole;
  location: string;
  phone: string | null;
  createdAt: string;
  lastLogin: string;
  status: "active" | "inactive" | "pending";
  ordersCount: number;
  totalSpent: string;
}

const AdminUsersPage = ({ title = "Users" }: AdminUsersPageProps) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null);
  const [viewUserOpen, setViewUserOpen] = useState(false);
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // State for storing overall statistics 
  const [stats, setStats] = useState({ newUsersCount: 0 });
  
  // Fetch users data from API with their purchase information
  useEffect(() => {
    const loadUsers = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Get users data with purchase information
        const result = await fetchUsers();
        if (result && result.data) {
          // Set users with real data
          setUsers(result.data);
          
          // Store overall statistics
          if (result.meta) {
            setStats({
              newUsersCount: result.meta.newUsersCount || 0
            });
          }
        }
      } catch (err: any) {
        console.error("Error loading users:", err);
        setError("Failed to load users. Please try again.");
        toast({
          title: "Error",
          description: "Could not load users. Please try again.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    
    loadUsers();
  }, [toast]);
  
  // Filter users based on search term and filters
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.fullName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    const matchesStatus = statusFilter === "all" || user.status === statusFilter;
    
    return matchesSearch && matchesRole && matchesStatus;
  });

  const handleViewUser = (user: UserData) => {
    setSelectedUser(user);
    setViewUserOpen(true);
  };
  
  // Handle user account actions
  const handleUserAction = async (action: 'suspend' | 'activate' | 'delete', userId: number) => {
    try {
      let result;
      
      switch(action) {
        case 'suspend':
          result = await suspendUser(userId);
          break;
        case 'activate':
          result = await activateUser(userId);
          break;
        case 'delete':
          result = await deleteUser(userId);
          break;
      }
      
      if (result?.success) {
        toast({
          title: "Success",
          description: result.message,
        });
        
        // Close dialog if open
        if (viewUserOpen && selectedUser) {
          setViewUserOpen(false);
        }
        
        // Update users list to reflect changes
        if (action === 'delete') {
          // Remove the user from the list
          setUsers(users.filter(u => u.id !== userId));
        } else {
          // Update the user status
          setUsers(users.map(u => {
            if (u.id === userId) {
              if (action === 'suspend') {
                return { ...u, status: 'inactive' as const };
              } else if (action === 'activate') {
                return { ...u, status: 'active' as const };
              }
            }
            return u;
          }));
        }
      } else {
        // Handle error from the API
        throw new Error(result?.message || `Failed to ${action} user account`);
      }
    } catch (error: any) {
      console.error(`Error during ${action} operation:`, error);
      toast({
        title: "Error",
        description: error.message || `Failed to ${action} user account.`,
        variant: "destructive"
      });
    }
  };

  const getStatusColor = (status: "active" | "inactive" | "pending") => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 border-green-200";
      case "inactive":
        return "bg-neutral-100 text-neutral-800 border-neutral-200";
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default:
        return "";
    }
  };

  return (
    <>
      <Helmet>
        <title>{title} | TireHub Admin</title>
        <meta name="description" content={`TireHub admin ${title.toLowerCase()} management interface.`} />
      </Helmet>
      <AdminLayout title={title}>
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-neutral-800">{title}</h1>
          <p className="text-neutral-600">Manage user accounts and permissions</p>
        </div>

        {/* Filters and Actions */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <Input 
              placeholder="Search users..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="w-full sm:w-40">
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="customer">Customer</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="w-full sm:w-40">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" size="icon" className="w-10 h-10 shrink-0">
            <Filter className="h-4 w-4" />
            <span className="sr-only">More filters</span>
          </Button>
          <Button className="shrink-0">
            <UserPlus className="mr-2 h-4 w-4" />
            Add User
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Total Users</p>
                <p className="text-xl font-bold">{users.length}</p>
              </div>
              <Users className="h-5 w-5 text-blue-500" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Active Users</p>
                <p className="text-xl font-bold">{users.filter(u => u.status === 'active').length}</p>
              </div>
              <User className="h-5 w-5 text-green-500" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Admins</p>
                <p className="text-xl font-bold">{users.filter(u => u.role === 'admin').length}</p>
              </div>
              <Shield className="h-5 w-5 text-purple-500" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">New Users (30d)</p>
                <p className="text-xl font-bold">{stats.newUsersCount}</p>
              </div>
              <UserPlus className="h-5 w-5 text-indigo-500" />
            </CardContent>
          </Card>
        </div>

        {/* Users Table */}
        <Card>
          <CardHeader className="px-6 py-4">
            <CardTitle className="text-lg">User Accounts</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                <p className="text-neutral-600">Loading user data...</p>
              </div>
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-12 text-red-500">
                <p>{error}</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => window.location.reload()}
                >
                  Retry
                </Button>
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-neutral-500">
                <p className="mb-2">No users found</p>
                {searchTerm || roleFilter !== 'all' || statusFilter !== 'all' ? (
                  <p className="text-sm">Try adjusting your filters</p>
                ) : (
                  <Button 
                    className="mt-4"
                    onClick={() => {}}
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    Add First User
                  </Button>
                )}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[200px]">User</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead className="text-center">Orders</TableHead>
                    <TableHead className="text-center">Total Spent</TableHead>
                    <TableHead className="text-center">Joined</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {user.fullName.split(" ").map(n => n?.[0] || "").join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{user.fullName}</p>
                            <p className="text-xs text-neutral-500">{user.username}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.location}</TableCell>
                      <TableCell>
                        {user.role === "admin" ? (
                          <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
                            Admin
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                            Customer
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className={`${getStatusColor(user.status)} capitalize`}>
                          {user.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        {user.ordersCount}
                      </TableCell>
                      <TableCell className="text-center font-medium">
                        {user.totalSpent}
                      </TableCell>
                      <TableCell className="text-center text-sm text-neutral-500">
                        {user.createdAt}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleViewUser(user)}>
                              <Eye className="mr-2 h-4 w-4" />
                              <span>View Details</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Pencil className="mr-2 h-4 w-4" />
                              <span>Edit User</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <LockIcon className="mr-2 h-4 w-4" />
                              <span>Reset Password</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            {user.status === 'active' ? (
                              <DropdownMenuItem 
                                className="text-amber-600"
                                onClick={() => handleUserAction('suspend', user.id)}
                              >
                                <LockIcon className="mr-2 h-4 w-4" />
                                <span>Suspend User</span>
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem 
                                className="text-green-600"
                                onClick={() => handleUserAction('activate', user.id)}
                              >
                                <LockIcon className="mr-2 h-4 w-4" />
                                <span>Activate User</span>
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem 
                              className="text-red-600"
                              onClick={() => handleUserAction('delete', user.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              <span>Delete User</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* User Details Dialog */}
        {selectedUser && (
          <Dialog open={viewUserOpen} onOpenChange={setViewUserOpen}>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>User Details</DialogTitle>
                <DialogDescription>
                  Detailed information for {selectedUser.fullName}
                </DialogDescription>
              </DialogHeader>
              
              <Tabs defaultValue="profile">
                <TabsList className="mb-4">
                  <TabsTrigger value="profile">Profile</TabsTrigger>
                  <TabsTrigger value="orders">Orders</TabsTrigger>
                  <TabsTrigger value="activity">Activity</TabsTrigger>
                </TabsList>
                
                <TabsContent value="profile" className="space-y-4">
                  <div className="flex items-start gap-6">
                    <Avatar className="h-20 w-20">
                      <AvatarFallback className="text-lg bg-primary/10 text-primary">
                        {selectedUser.fullName.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 space-y-1">
                      <h3 className="text-xl font-semibold">{selectedUser.fullName}</h3>
                      <div className="flex items-center gap-2 text-sm text-neutral-500">
                        <User className="h-4 w-4" />
                        <span>@{selectedUser.username}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-neutral-500">
                        <Mail className="h-4 w-4" />
                        <span>{selectedUser.email}</span>
                      </div>
                      {selectedUser.phone && (
                        <div className="flex items-center gap-2 text-sm text-neutral-500">
                          <Phone className="h-4 w-4" />
                          <span>{selectedUser.phone}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-sm text-neutral-500">
                        <MapPin className="h-4 w-4" />
                        <span>{selectedUser.location}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Badge variant="outline" className={`${getStatusColor(selectedUser.status)} capitalize block`}>
                        {selectedUser.status}
                      </Badge>
                      <Badge variant="outline" className={selectedUser.role === "admin" ? 
                        "bg-purple-100 text-purple-800 border-purple-200 block" : 
                        "bg-blue-100 text-blue-800 border-blue-200 block"}>
                        {selectedUser.role}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6 border-t pt-4">
                    <div>
                      <h4 className="font-medium mb-2">Account Information</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-neutral-500">Joined:</span>
                          <span>{selectedUser.createdAt}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-neutral-500">Last Login:</span>
                          <span>{selectedUser.lastLogin || "Never"}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-neutral-500">Orders:</span>
                          <span>{selectedUser.ordersCount}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-neutral-500">Total Spent:</span>
                          <span className="font-medium">${selectedUser.totalSpent}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Account Actions</h4>
                      <div className="space-y-2">
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <Pencil className="mr-2 h-4 w-4" />
                          <span>Edit Profile</span>
                        </Button>
                        <Button variant="outline" size="sm" className="w-full justify-start">
                          <LockIcon className="mr-2 h-4 w-4" />
                          <span>Reset Password</span>
                        </Button>
                        {selectedUser.status === "active" ? (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="w-full justify-start text-yellow-600"
                            onClick={() => handleUserAction('suspend', selectedUser.id)}
                          >
                            <Clock className="mr-2 h-4 w-4" />
                            <span>Suspend Account</span>
                          </Button>
                        ) : (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="w-full justify-start text-green-600"
                            onClick={() => handleUserAction('activate', selectedUser.id)}
                          >
                            <User className="mr-2 h-4 w-4" />
                            <span>Activate Account</span>
                          </Button>
                        )}
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full justify-start text-destructive"
                          onClick={() => handleUserAction('delete', selectedUser.id)}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Delete Account</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="orders">
                  {selectedUser.ordersCount > 0 ? (
                    <div className="space-y-4">
                      {/* Display user's orders with real total spent information */}
                      {[...Array(selectedUser.ordersCount)].map((_, i) => {
                        // Calculate individual order amount - total spent divided by number of orders
                        // This is a rough estimation for visualization
                        const orderAmount = selectedUser.ordersCount > 0 
                          ? (parseFloat(selectedUser.totalSpent) / selectedUser.ordersCount).toFixed(2)
                          : "0.00";
                          
                        return (
                          <div key={i} className="flex items-center justify-between p-4 border rounded-md">
                            <div className="flex items-center gap-4">
                              <div className="bg-neutral-100 p-2 rounded-md">
                                <ShoppingBag className="h-6 w-6 text-neutral-600" />
                              </div>
                              <div>
                                <p className="font-medium">Order #{7000 + i}</p>
                                <p className="text-sm text-neutral-500">2025-05-0{1 + i}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">${orderAmount}</p>
                              <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                                Completed
                              </Badge>
                            </div>
                            <Button variant="ghost" size="sm">View</Button>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-neutral-500">
                      <ShoppingBag className="h-12 w-12 mx-auto mb-4 text-neutral-300" />
                      <p>No orders found for this user</p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="activity">
                  <div className="space-y-4">
                    <div className="border-l-2 border-neutral-200 pl-4 ml-4 relative">
                      <div className="absolute w-3 h-3 bg-blue-500 rounded-full -left-[7px] top-1.5"></div>
                      <p className="text-sm font-medium">Login</p>
                      <p className="text-xs text-neutral-500">2025-05-08 09:45 AM</p>
                    </div>
                    
                    {selectedUser.ordersCount > 0 && (
                      <div className="border-l-2 border-neutral-200 pl-4 ml-4 relative">
                        <div className="absolute w-3 h-3 bg-green-500 rounded-full -left-[7px] top-1.5"></div>
                        <p className="text-sm font-medium">Placed Order #{7000 + selectedUser.ordersCount - 1}</p>
                        <p className="text-xs text-neutral-500">2025-05-07 02:30 PM</p>
                      </div>
                    )}
                    
                    <div className="border-l-2 border-neutral-200 pl-4 ml-4 relative">
                      <div className="absolute w-3 h-3 bg-blue-500 rounded-full -left-[7px] top-1.5"></div>
                      <p className="text-sm font-medium">Login</p>
                      <p className="text-xs text-neutral-500">2025-05-07 10:15 AM</p>
                    </div>
                    
                    <div className="border-l-2 border-neutral-200 pl-4 ml-4 relative">
                      <div className="absolute w-3 h-3 bg-purple-500 rounded-full -left-[7px] top-1.5"></div>
                      <p className="text-sm font-medium">Updated Profile</p>
                      <p className="text-xs text-neutral-500">2025-05-05 11:20 AM</p>
                    </div>
                    
                    <div className="border-l-2 border-neutral-200 pl-4 ml-4 relative">
                      <div className="absolute w-3 h-3 bg-yellow-500 rounded-full -left-[7px] top-1.5"></div>
                      <p className="text-sm font-medium">Account Created</p>
                      <p className="text-xs text-neutral-500">{selectedUser.createdAt} 09:00 AM</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setViewUserOpen(false)}>
                  Close
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </AdminLayout>
    </>
  );
};

export default AdminUsersPage;
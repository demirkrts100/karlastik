import { useQuery, useMutation } from '@tanstack/react-query';
import { WishlistItem, Tire } from '@shared/schema';
import { useToast } from './use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/components/auth/AuthProvider';

// Type for the enriched wishlist item that includes the tire data
export type EnrichedWishlistItem = WishlistItem & {
  tire: Tire;
};

export function useWishlist() {
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Query to get all wishlist items for the current user
  const {
    data: wishlistItems = [],
    isLoading,
    isError,
    error,
    refetch
  } = useQuery<EnrichedWishlistItem[]>({
    queryKey: ['/api/wishlist'],
    enabled: !!user, // Only run the query if the user is authenticated
  });
  
  // Mutation to add a tire to the wishlist
  const addToWishlistMutation = useMutation({
    mutationFn: async (tireId: number) => {
      const res = await apiRequest('POST', '/api/wishlist/add', { tireId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: 'Added to Wishlist',
        description: 'The tire has been added to your wishlist',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to add item to wishlist',
        variant: 'destructive',
      });
    },
  });
  
  // Mutation to remove a tire from the wishlist
  const removeFromWishlistMutation = useMutation({
    mutationFn: async (wishlistItemId: number) => {
      const res = await apiRequest('DELETE', `/api/wishlist/${wishlistItemId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: 'Removed from Wishlist',
        description: 'The tire has been removed from your wishlist',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to remove item from wishlist',
        variant: 'destructive',
      });
    },
  });
  
  // Mutation to clear the entire wishlist
  const clearWishlistMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('DELETE', '/api/wishlist');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: 'Wishlist Cleared',
        description: 'All items have been removed from your wishlist',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to clear wishlist',
        variant: 'destructive',
      });
    },
  });
  
  // Check if a tire is in the wishlist
  const isInWishlist = (tireId: number) => {
    return wishlistItems.some(item => item.tireId === tireId);
  };
  
  // Find a wishlist item by tire ID
  const getWishlistItemByTireId = (tireId: number) => {
    return wishlistItems.find(item => item.tireId === tireId);
  };
  
  return {
    wishlistItems,
    isLoading,
    isError,
    error,
    refetch,
    addToWishlist: addToWishlistMutation.mutate,
    removeFromWishlist: removeFromWishlistMutation.mutate,
    clearWishlist: clearWishlistMutation.mutate,
    isAddingToWishlist: addToWishlistMutation.isPending,
    isRemovingFromWishlist: removeFromWishlistMutation.isPending,
    isClearingWishlist: clearWishlistMutation.isPending,
    isInWishlist,
    getWishlistItemByTireId,
  };
}
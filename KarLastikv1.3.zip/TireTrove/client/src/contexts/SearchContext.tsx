import { createContext, useState, ReactNode, useContext } from 'react';
import { Tire } from '@shared/schema';

interface VehicleParams {
  year: string;
  make: string;
  model: string;
  trim?: string;
  tireSize?: string;
}

interface SearchContextProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  vehicleParams: VehicleParams | null;
  setVehicleParams: (params: VehicleParams) => void;
  searchResults: Tire[] | null;
  setSearchResults: (results: Tire[] | null) => void;
  clearSearch: () => void;
}

export const SearchContext = createContext<SearchContextProps>({
  searchQuery: '',
  setSearchQuery: () => {},
  vehicleParams: null,
  setVehicleParams: () => {},
  searchResults: null,
  setSearchResults: () => {},
  clearSearch: () => {},
});

// Custom hook to use the search context
export const useSearch = () => {
  const context = useContext(SearchContext);
  
  if (context === undefined) {
    throw new Error('useSearch must be used within a SearchProvider');
  }
  
  return context;
};

interface SearchProviderProps {
  children: ReactNode;
}

export const SearchProvider = ({ children }: SearchProviderProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [vehicleParams, setVehicleParams] = useState<VehicleParams | null>(null);
  const [searchResults, setSearchResults] = useState<Tire[] | null>(null);
  
  const clearSearch = () => {
    setSearchQuery('');
    setVehicleParams(null);
    setSearchResults(null);
  };
  
  return (
    <SearchContext.Provider
      value={{
        searchQuery,
        setSearchQuery,
        vehicleParams,
        setVehicleParams,
        searchResults,
        setSearchResults,
        clearSearch,
      }}
    >
      {children}
    </SearchContext.Provider>
  );
};

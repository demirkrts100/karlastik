import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { Link } from 'wouter';

interface FAQ {
  question: string;
  answer: string;
}

const FAQSection = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  
  const faqs: FAQ[] = [
    {
      question: "How do I find the right tires for my vehicle?",
      answer: "The easiest way is to use our \"Shop by Vehicle\" feature. Enter your vehicle's year, make, and model to see all compatible tires. You can also search by tire size, which can be found on your current tire's sidewall or in your vehicle's owner manual."
    },
    {
      question: "How often should I replace my tires?",
      answer: "Most tire manufacturers recommend replacing tires every 6 years, regardless of tread wear. However, you should also check your tire tread regularly. If the tread depth is less than 2/32 of an inch, it's time to replace your tires. You can use the penny test: insert a penny with Lincoln's head upside down into a tire groove. If you can see all of Lincoln's head, it's time for new tires."
    },
    {
      question: "Do you offer installation services?",
      answer: "Yes, we partner with thousands of certified installation centers nationwide. During checkout, you can choose to have your tires shipped to a nearby installer, or you can choose to have them shipped to your home and take them to an installer of your choice."
    },
    {
      question: "What's the difference between all-season and winter tires?",
      answer: "All-season tires are designed to provide a comfortable ride and adequate traction in most weather conditions, including light winter conditions. Winter tires, on the other hand, are specifically designed for optimal performance in snow, ice, and cold temperatures. They have special tread patterns and rubber compounds that remain flexible in cold weather, providing better grip and braking in winter conditions."
    },
    {
      question: "What is your return policy?",
      answer: "We offer a 45-day satisfaction guarantee on most tires. If you're not satisfied with your eligible tire purchase, you can return them within 45 days of the purchase date. Please note that tires must be unused and in their original condition. Shipping and installation costs are non-refundable."
    }
  ];
  
  const toggleFAQ = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };
  
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">Frequently Asked Questions</h2>
        
        <div className="max-w-3xl mx-auto">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-neutral-200 rounded-lg overflow-hidden">
                <button 
                  className="flex justify-between items-center w-full p-4 text-left font-medium focus:outline-none hover:bg-neutral-50"
                  onClick={() => toggleFAQ(index)}
                >
                  <span>{faq.question}</span>
                  <ChevronDown 
                    className={`text-neutral-500 transition-transform ${activeIndex === index ? 'rotate-180' : ''}`}
                  />
                </button>
                <div 
                  className={`px-4 pb-4 ${activeIndex === index ? 'block' : 'hidden'}`}
                >
                  <p className="text-neutral-600">{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 text-center">
            <Link href="/faqs" className="text-primary hover:underline font-medium">
              View All FAQs
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;

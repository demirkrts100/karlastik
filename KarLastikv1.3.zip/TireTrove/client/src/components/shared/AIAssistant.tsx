import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Bot, X, Send, Loader2 } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'assistant', 
      content: 'Hi there! I\'m TireHub Assistant. How can I help you find the perfect tires for your vehicle?' 
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of chat when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { role: 'user' as const, content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // In a real implementation, this would call your backend AI service
      // For now we'll simulate a response
      setTimeout(() => {
        const assistantResponse = { 
          role: 'assistant' as const, 
          content: getSimulatedResponse(input) 
        };
        setMessages(prev => [...prev, assistantResponse]);
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error getting AI response:', error);
      setIsLoading(false);
    }
  };

  // Simple simulation of responses - in a real app, this would connect to an AI API
  const getSimulatedResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('winter') || lowerQuery.includes('snow')) {
      return "For winter driving, I recommend our Michelin X-Ice or Bridgestone Blizzak series. They provide excellent traction on snow and ice. Would you like more specific recommendations based on your vehicle?";
    }
    
    if (lowerQuery.includes('all season')) {
      return "All-season tires are a great choice for moderate climates. The Michelin CrossClimate2 and Continental ExtremeContact DWS06 are popular options with excellent performance in both dry and wet conditions.";
    }
    
    if (lowerQuery.includes('delivery') || lowerQuery.includes('shipping')) {
      return "We offer free standard shipping on all tire orders, and expedited shipping options are available at checkout. Most orders are delivered within 2-5 business days, depending on your location.";
    }
    
    if (lowerQuery.includes('price') || lowerQuery.includes('cost') || lowerQuery.includes('cheap')) {
      return "We have tires at various price points to fit your budget. Our value options start around $70 per tire, while premium tires can range from $150-$300. May I ask what vehicle you're shopping for to provide more specific pricing?";
    }
    
    if (lowerQuery.includes('warranty')) {
      return "All tires come with the manufacturer's warranty, typically covering defects for the life of the tread. Additionally, we offer our own Road Hazard Protection for a small fee, which covers damage from potholes, nails, and other road hazards.";
    }
    
    return "Thanks for your question! I'd be happy to help with information about our tire selection, vehicle compatibility, pricing, or installation services. Could you provide a bit more detail about what you're looking for?";
  };

  return (
    <>
      {/* Chat toggle button */}
      <Button
        onClick={() => setIsOpen(prev => !prev)}
        aria-label="Chat with AI Assistant"
        className={`fixed ${isOpen ? 'hidden' : 'flex'} bottom-6 right-6 z-50 h-12 w-12 rounded-full shadow-xl bg-primary hover:bg-primary/90`}
      >
        <Bot className="h-6 w-6" />
      </Button>

      {/* Chat interface */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 w-80 sm:w-96 h-[450px] z-50 shadow-xl flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-primary text-white p-3 flex justify-between items-center">
            <h3 className="font-medium flex items-center">
              <Bot className="mr-2 h-5 w-5" />
              TireHub Assistant
            </h3>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-8 w-8 text-white hover:bg-primary-foreground/10">
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          {/* Messages */}
          <div className="flex-grow p-3 overflow-y-auto bg-neutral-50">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`mb-3 ${
                  message.role === 'user' ? 'ml-auto' : 'mr-auto'
                }`}
              >
                <div
                  className={`p-3 rounded-lg max-w-[80%] ${
                    message.role === 'user'
                      ? 'ml-auto bg-primary text-white rounded-br-none'
                      : 'mr-auto bg-white shadow-sm rounded-bl-none'
                  }`}
                >
                  {message.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="mb-3 mr-auto">
                <div className="p-3 rounded-lg max-w-[80%] mr-auto bg-white shadow-sm rounded-bl-none">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          {/* Input */}
          <form onSubmit={handleSubmit} className="p-3 border-t bg-white">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your question..."
                className="flex-grow"
                disabled={isLoading}
              />
              <Button 
                type="submit" 
                size="icon" 
                disabled={isLoading || !input.trim()}
                className="h-10 w-10"
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </form>
        </Card>
      )}
    </>
  );
};

export default AIAssistant;
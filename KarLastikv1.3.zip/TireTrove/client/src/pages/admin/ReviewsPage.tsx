import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Star,
  StarHalf,
  Search,
  Check,
  X,
  Trash2,
  Clock,
  MessageSquare,
  Filter,
  Eye,
  Edit,
  Image,
  Loader2,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { fetchReviews } from "@/services/adminService";

interface AdminReviewsPageProps {
  title?: string;
}

type ReviewStatus = "pending" | "approved" | "rejected";

interface Review {
  id: number;
  date: string;
  createdAt?: string;
  author?: string;
  userName: string;
  rating: number;
  comment: string;
  product?: string;
  brand?: string;
  status: ReviewStatus;
  hasImages?: boolean;
  images?: string[];
  moderationNotes?: string;
  tireId?: number; 
}

const getStatusColor = (status: ReviewStatus) => {
  switch (status) {
    case "pending":
      return "bg-yellow-100 text-yellow-800 border-yellow-200";
    case "approved":
      return "bg-green-100 text-green-800 border-green-200";
    case "rejected":
      return "bg-red-100 text-red-800 border-red-200";
    default:
      return "bg-gray-100 text-gray-800 border-gray-200";
  }
};

const getStatusIcon = (status: ReviewStatus) => {
  switch (status) {
    case "pending":
      return <Clock className="h-4 w-4 text-yellow-500" />;
    case "approved":
      return <Check className="h-4 w-4 text-green-500" />;
    case "rejected":
      return <X className="h-4 w-4 text-red-500" />;
    default:
      return null;
  }
};

const renderStars = (rating: number) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 !== 0;
  
  return (
    <div className="flex text-yellow-500">
      {[...Array(fullStars)].map((_, i) => (
        <Star key={`star-${i}`} className="h-4 w-4 fill-current" />
      ))}
      {hasHalfStar && <StarHalf className="h-4 w-4 fill-current" />}
      {[...Array(5 - Math.ceil(rating))].map((_, i) => (
        <Star key={`empty-star-${i}`} className="h-4 w-4 text-neutral-300" />
      ))}
    </div>
  );
};

const AdminReviewsPage = ({ title = "Reviews" }: AdminReviewsPageProps) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedReview, setSelectedReview] = useState<Review | null>(null);
  const [viewOpen, setViewOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [moderationNotes, setModerationNotes] = useState("");
  const [editedComment, setEditedComment] = useState("");
  const [editedRating, setEditedRating] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    approved: 0,
    rejected: 0
  });
  
  // Fetch reviews data
  useEffect(() => {
    const loadReviews = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        const result = await fetchReviews();
        if (result && result.data) {
          setReviews(result.data);
          
          // Calculate stats
          setStats({
            total: result.data.length,
            pending: result.data.filter((r: Review) => r.status === 'pending').length,
            approved: result.data.filter((r: Review) => r.status === 'approved').length,
            rejected: result.data.filter((r: Review) => r.status === 'rejected').length,
          });
        }
      } catch (err) {
        console.error("Error loading reviews:", err);
        setError("Failed to load reviews. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };
    
    loadReviews();
  }, []);
  
  const filteredReviews = reviews.filter(review => {
    const matchesSearch = 
      review.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (review.product || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      review.comment.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || review.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const handleViewReview = (review: Review) => {
    setSelectedReview(review);
    setModerationNotes(review.moderationNotes || "");
    setViewOpen(true);
  };

  const handleEditReview = (review: Review) => {
    setSelectedReview(review);
    setEditedComment(review.comment);
    setEditedRating(review.rating);
    setEditOpen(true);
  };

  const handleDeleteReview = async (reviewId: number) => {
    if (!confirm("Are you sure you want to delete this review? This action cannot be undone.")) {
      return;
    }
    
    try {
      setIsSubmitting(true);
      const response = await apiRequest("DELETE", `/api/reviews/${reviewId}`);
      
      if (response.ok) {
        toast({
          title: "Review deleted",
          description: "The review has been successfully deleted.",
        });
        
        // Update the local state
        setReviews(prevReviews => prevReviews.filter(r => r.id !== reviewId));
        setStats(prev => ({
          ...prev,
          total: prev.total - 1,
          pending: reviews.find(r => r.id === reviewId)?.status === 'pending' ? prev.pending - 1 : prev.pending,
          approved: reviews.find(r => r.id === reviewId)?.status === 'approved' ? prev.approved - 1 : prev.approved,
          rejected: reviews.find(r => r.id === reviewId)?.status === 'rejected' ? prev.rejected - 1 : prev.rejected,
        }));
      } else {
        const error = await response.json();
        throw new Error(error.message || "Failed to delete review");
      }
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message || "Failed to delete review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateStatus = async (reviewId: number, status: ReviewStatus) => {
    try {
      setIsSubmitting(true);
      
      const response = await apiRequest("PUT", `/api/admin/reviews/${reviewId}/moderate`, {
        status,
        moderationNotes
      });
      
      if (response.ok) {
        const updatedReview = await response.json();
        
        toast({
          title: `Review ${status}`,
          description: `The review has been ${status} successfully.`,
        });
        
        // Update the review in the local state
        setReviews(prevReviews => 
          prevReviews.map(r => 
            r.id === reviewId ? { ...r, status, moderationNotes } : r
          )
        );
        
        // Update stats
        if (selectedReview) {
          const oldStatus = selectedReview.status;
          setStats(prev => ({
            ...prev,
            pending: oldStatus === 'pending' ? prev.pending - 1 : prev.pending,
            approved: status === 'approved' ? prev.approved + 1 : oldStatus === 'approved' ? prev.approved - 1 : prev.approved,
            rejected: status === 'rejected' ? prev.rejected + 1 : oldStatus === 'rejected' ? prev.rejected - 1 : prev.rejected,
          }));
        }
        
        setViewOpen(false);
      } else {
        const error = await response.json();
        throw new Error(error.message || "Failed to update review status");
      }
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message || "Failed to update review status. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleApprove = () => {
    if (!selectedReview) return;
    handleUpdateStatus(selectedReview.id, 'approved');
  };

  const handleReject = () => {
    if (!selectedReview) return;
    handleUpdateStatus(selectedReview.id, 'rejected');
  };

  const handleSaveEdit = async () => {
    if (!selectedReview) return;
    
    try {
      setIsSubmitting(true);
      
      const response = await apiRequest("PUT", `/api/reviews/${selectedReview.id}`, {
        rating: editedRating,
        comment: editedComment
      });
      
      if (response.ok) {
        const updatedReview = await response.json();
        
        toast({
          title: "Review updated",
          description: "The review has been updated successfully.",
        });
        
        // Update the review in the local state
        setReviews(prevReviews => 
          prevReviews.map(r => 
            r.id === selectedReview.id ? 
            { ...r, rating: editedRating, comment: editedComment } : r
          )
        );
        
        setEditOpen(false);
      } else {
        const error = await response.json();
        throw new Error(error.message || "Failed to update review");
      }
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message || "Failed to update review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>{title} | TireHub Admin</title>
        <meta name="description" content={`TireHub admin ${title.toLowerCase()} management interface.`} />
      </Helmet>
      <AdminLayout title={title}>
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-neutral-800">{title}</h1>
          <p className="text-neutral-600">Manage and moderate customer reviews</p>
        </div>

        {/* Filters */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <Input 
              placeholder="Search reviews..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="w-full sm:w-48">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Reviews</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" size="icon" className="w-10 h-10 shrink-0">
            <Filter className="h-4 w-4" />
            <span className="sr-only">More filters</span>
          </Button>
        </div>

        {/* Reviews Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Total Reviews</p>
                <p className="text-xl font-bold">{reviews.length}</p>
              </div>
              <MessageSquare className="h-5 w-5 text-neutral-400" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Pending</p>
                <p className="text-xl font-bold">{reviews.filter(r => r.status === 'pending').length}</p>
              </div>
              <Clock className="h-5 w-5 text-yellow-500" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Approved</p>
                <p className="text-xl font-bold">{reviews.filter(r => r.status === 'approved').length}</p>
              </div>
              <Check className="h-5 w-5 text-green-500" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Rejected</p>
                <p className="text-xl font-bold">{reviews.filter(r => r.status === 'rejected').length}</p>
              </div>
              <X className="h-5 w-5 text-red-500" />
            </CardContent>
          </Card>
        </div>

        {/* Reviews Table */}
        <Card>
          <CardHeader className="px-6 py-4">
            <CardTitle className="text-lg">Customer Reviews</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">Rating</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Author</TableHead>
                  <TableHead>Comment</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-center">Media</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredReviews.map((review) => (
                  <TableRow key={review.id}>
                    <TableCell>{renderStars(review.rating)}</TableCell>
                    <TableCell className="font-medium">{review.product}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarFallback className="text-xs">
                            {review.userName?.substring(0, 2).toUpperCase() || 'UN'}
                          </AvatarFallback>
                        </Avatar>
                        {review.userName}
                      </div>
                    </TableCell>
                    <TableCell className="max-w-xs truncate">{review.comment}</TableCell>
                    <TableCell>{review.date}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`${getStatusColor(review.status)} flex w-fit items-center gap-1 capitalize`}>
                        {getStatusIcon(review.status)}
                        {review.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      {review.hasImages ? (
                        <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                          <Image className="h-3 w-3 mr-1" />
                          Images
                        </Badge>
                      ) : (
                        "-"
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8"
                        onClick={() => handleViewReview(review)}
                      >
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View</span>
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Review View/Moderation Dialog */}
        {selectedReview && (
          <Dialog open={viewOpen} onOpenChange={setViewOpen}>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Review Details</DialogTitle>
                <DialogDescription>
                  Review for {selectedReview.product} by {selectedReview.userName}
                </DialogDescription>
              </DialogHeader>
              
              <Tabs defaultValue="details">
                <TabsList className="mb-4">
                  <TabsTrigger value="details">Review Details</TabsTrigger>
                  <TabsTrigger value="moderation">Moderation</TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar>
                        <AvatarFallback>
                          {selectedReview.userName?.substring(0, 2).toUpperCase() || 'UN'}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{selectedReview.userName}</p>
                        <p className="text-sm text-neutral-500">{selectedReview.date}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className={`${getStatusColor(selectedReview.status)} flex items-center gap-1 capitalize`}>
                      {getStatusIcon(selectedReview.status)}
                      {selectedReview.status}
                    </Badge>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-neutral-500 mb-1">Product</p>
                    <p>{selectedReview.product}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-neutral-500 mb-1">Rating</p>
                    <div className="flex items-center gap-2">
                      {renderStars(selectedReview.rating)}
                      <span className="text-sm">{selectedReview.rating}/5</span>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm font-medium text-neutral-500 mb-1">Review</p>
                    <p className="p-3 bg-neutral-50 rounded-md">{selectedReview.comment}</p>
                  </div>
                  
                  {selectedReview.hasImages && (
                    <div>
                      <p className="text-sm font-medium text-neutral-500 mb-1">Images</p>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="aspect-square bg-neutral-100 rounded-md flex items-center justify-center">
                          <Image className="h-8 w-8 text-neutral-400" />
                        </div>
                        <div className="aspect-square bg-neutral-100 rounded-md flex items-center justify-center">
                          <Image className="h-8 w-8 text-neutral-400" />
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="moderation" className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-neutral-500 mb-1">Moderation Notes</p>
                    <Textarea
                      placeholder="Add notes about why this review was approved or rejected..."
                      className="min-h-[100px]"
                      value={moderationNotes}
                      onChange={(e) => setModerationNotes(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex justify-between">
                    <div>
                      <Button variant="destructive" onClick={handleReject}>
                        <X className="h-4 w-4 mr-2" />
                        Reject Review
                      </Button>
                    </div>
                    <div>
                      <Button variant="outline" className="mr-2" onClick={() => setViewOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleApprove}>
                        <Check className="h-4 w-4 mr-2" />
                        Approve Review
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>
        )}
      </AdminLayout>
    </>
  );
};

export default AdminReviewsPage;
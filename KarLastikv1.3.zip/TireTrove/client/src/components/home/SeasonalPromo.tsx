import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'wouter';
import { Skeleton } from '@/components/ui/skeleton';
import { Promotion } from '@shared/schema';

const SeasonalPromo = () => {
  // Fetch active promotions
  const { data: promotions, isLoading, error } = useQuery<Promotion[]>({
    queryKey: ['/api/promotions'],
  });
  
  return (
    <section className="py-12 bg-gradient-to-br from-primary/90 to-primary">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-10">Seasonal Tire Guide</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item) => (
              <Card key={item} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-1/2 mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <Skeleton className="h-4 w-32" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <div className="text-center p-8 bg-white rounded-lg">
            <p className="text-red-500">Error loading promotions. Please try again later.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {promotions?.map((promo) => (
              <Card key={promo.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <img src={promo.imageUrl} alt={promo.title} className="w-full h-48 object-cover" />
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg mb-2">{promo.title}</h3>
                  <p className="text-neutral-600 text-sm mb-4">{promo.description}</p>
                  <Link href={promo.linkUrl} className="text-primary hover:underline font-medium">
                    Shop {promo.title}
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default SeasonalPromo;

import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface PasswordStrengthIndicatorProps {
  password: string;
}

export const PasswordStrengthIndicator = ({ password }: PasswordStrengthIndicatorProps) => {
  const [strength, setStrength] = useState(0);
  const [checks, setChecks] = useState({
    minLength: false,
    hasUpperCase: false,
    hasLowerCase: false,
    hasNumber: false,
    hasSpecialChar: false
  });

  useEffect(() => {
    // Calculate password strength
    const calculateStrength = () => {
      const newChecks = {
        minLength: password.length >= 8,
        hasUpperCase: /[A-Z]/.test(password),
        hasLowerCase: /[a-z]/.test(password),
        hasNumber: /\d/.test(password),
        hasSpecialChar: /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)
      };
      
      setChecks(newChecks);
      
      // Calculate score (0-100)
      const passedChecks = Object.values(newChecks).filter(Boolean).length;
      const score = Math.floor((passedChecks / 5) * 100);
      setStrength(score);
    };
    
    calculateStrength();
  }, [password]);

  const getStrengthText = () => {
    if (strength >= 100) return "Strong";
    if (strength >= 60) return "Good";
    if (strength >= 40) return "Fair";
    return "Weak";
  };

  const getStrengthColor = () => {
    if (strength >= 100) return "bg-green-500";
    if (strength >= 60) return "bg-yellow-500";
    if (strength >= 40) return "bg-orange-400";
    return "bg-red-500";
  };

  return (
    <div className="space-y-2 mt-2">
      <div className="flex justify-between items-center">
        <div className="text-sm font-medium">Password Strength:</div>
        <div className={cn("text-xs font-semibold", {
          "text-red-500": strength < 40,
          "text-orange-400": strength >= 40 && strength < 60,
          "text-yellow-500": strength >= 60 && strength < 100,
          "text-green-500": strength >= 100
        })}>
          {getStrengthText()}
        </div>
      </div>
      
      <Progress value={strength} className={`h-2 ${getStrengthColor()}`} />
      
      <ul className="text-xs space-y-1 text-gray-500 mt-1">
        <li className={checks.minLength ? "text-green-600" : ""}>
          {checks.minLength ? "✓" : "○"} At least 8 characters
        </li>
        <li className={checks.hasUpperCase ? "text-green-600" : ""}>
          {checks.hasUpperCase ? "✓" : "○"} At least one uppercase letter
        </li>
        <li className={checks.hasLowerCase ? "text-green-600" : ""}>
          {checks.hasLowerCase ? "✓" : "○"} At least one lowercase letter
        </li>
        <li className={checks.hasNumber ? "text-green-600" : ""}>
          {checks.hasNumber ? "✓" : "○"} At least one number
        </li>
        <li className={checks.hasSpecialChar ? "text-green-600" : ""}>
          {checks.hasSpecialChar ? "✓" : "○"} At least one special character
        </li>
      </ul>
    </div>
  );
};
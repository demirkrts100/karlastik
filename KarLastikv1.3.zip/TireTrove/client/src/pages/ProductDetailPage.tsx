import React, { useState, useRef } from 'react';
import { useParams, Link, useLocation } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Breadcrumb, 
  BreadcrumbItem, 
  BreadcrumbLink, 
  BreadcrumbSeparator,
  BreadcrumbList
} from '@/components/ui/breadcrumb';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/useCart';
import { useWishlist } from '@/hooks/useWishlist';
import { useAuth } from '@/components/auth/AuthProvider';
import { Star, StarHalf, Minus, Plus, Heart, ArrowRight, Truck, Clock, Award, Shield, InfoIcon, Loader2, Image as ImageIcon, Upload, X, ZoomIn, Search, Maximize2, Check, ShoppingCart, Loader, ChevronLeft, ChevronRight } from 'lucide-react';
import { Tire, Review } from '@shared/schema';
import ProductCard from '@/components/product/ProductCard';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { WishlistButton } from '@/components/wishlist/WishlistButton';

const ProductDetailPage = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { addItem } = useCart();
  const { user } = useAuth();
  const { 
    wishlistItems, 
    addToWishlist, 
    removeFromWishlist, 
    isAddingToWishlist,
    isRemovingFromWishlist 
  } = useWishlist();
  const [quantity, setQuantity] = useState(1);
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewImages, setReviewImages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Purchase verification state
  const [canReview, setCanReview] = useState(false);
  const [hasPurchased, setHasPurchased] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);
  const [isPurchaseChecking, setIsPurchaseChecking] = useState(false);
  
  // State for image zoom dialog
  const [zoomImageUrl, setZoomImageUrl] = useState<string | null>(null);
  
  // Create review mutation
  const createReviewMutation = useMutation({
    mutationFn: async () => {
      if (!user || !tire) {
        throw new Error('Authentication required to leave a review');
      }
      
      const reviewData = {
        tireId: tire.id,
        userId: user.id, // Adding userId explicitly
        rating: reviewRating,
        comment: reviewComment,
        userName: user.username,
        userVehicle: null,
        images: reviewImages.length > 0 ? reviewImages : null
      };
      
      try {
        console.log('Submitting review:', reviewData);
        const res = await apiRequest('POST', '/api/reviews', reviewData);
        
        // Check if the response is ok
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.message || 'Failed to submit review');
        }
        
        const data = await res.json();
        console.log('Review submission response:', data);
        return data;
      } catch (error) {
        console.error('Error submitting review:', error);
        throw error;
      }
    },
    onSuccess: () => {
      // Invalidate the reviews query to trigger a refetch
      queryClient.invalidateQueries({ queryKey: [`/api/reviews/tire/${id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/reviews/user'] });
      
      // Reset form and close dialog
      setReviewRating(5);
      setReviewComment('');
      setReviewImages([]);
      setIsReviewDialogOpen(false);
      
      toast({
        title: 'Review submitted',
        description: 'Thank you for sharing your experience with this product!',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to submit review. Please try again.',
        variant: 'destructive',
      });
    }
  });
  
  // Image handling functions
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;
    
    const file = files[0];
    // Only allow images
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload only image files.',
        variant: 'destructive',
      });
      return;
    }
    
    // Limit file size to 5MB
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Please upload images smaller than 5MB.',
        variant: 'destructive',
      });
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setReviewImages(prev => [...prev, imageUrl]);
    };
    reader.readAsDataURL(file);
    
    // Reset the file input so the same file can be selected again if needed
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  // Remove an uploaded image
  const removeImage = (index: number) => {
    setReviewImages(prev => prev.filter((_, i) => i !== index));
  };
  
  // Open review dialog function
  const openReviewDialog = () => {
    if (!user) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to write a review.',
        variant: 'destructive'
      });
      navigate('/auth');
      return;
    }
    
    setIsReviewDialogOpen(true);
  };
  
  // Fetch tire details
  const { data: tire, isLoading: tireLoading, error: tireError } = useQuery<Tire>({
    queryKey: [`/api/tires/${id}`],
  });
  
  // Fetch tire reviews
  const { data: reviews, isLoading: reviewsLoading } = useQuery<Review[]>({
    queryKey: [`/api/reviews/tire/${id}`],
    enabled: !!tire,
  });
  
  // Fetch similar tires
  const { data: similarTires, isLoading: similarLoading } = useQuery<Tire[]>({
    queryKey: ['/api/tires'],
    enabled: !!tire,
  });
  
  // Check if user has purchased this tire (only run if user is logged in and tire exists)
  const { data: purchaseStatus, isLoading: isPurchaseStatusLoading } = useQuery({
    queryKey: [`/api/user/purchased/${id}`],
    queryFn: async () => {
      if (!user || !tire) return { hasPurchased: false, hasReviewed: false, canReview: false };
      const res = await fetch(`/api/user/purchased/${id}`);
      if (!res.ok) {
        throw new Error('Failed to fetch purchase status');
      }
      return res.json();
    },
    enabled: !!user && !!tire,
  });
  
  // Handle purchase status data
  React.useEffect(() => {
    if (purchaseStatus) {
      setHasPurchased(purchaseStatus.hasPurchased);
      setHasReviewed(purchaseStatus.hasReviewed);
      setCanReview(purchaseStatus.canReview);
      setIsPurchaseChecking(false);
    }
  }, [purchaseStatus]);
  
  // Handle quantity change
  const updateQuantity = (newQuantity: number) => {
    if (newQuantity < 1) return;
    setQuantity(newQuantity);
  };
  
  // Add to cart
  const handleAddToCart = async () => {
    if (!tire) return;
    
    try {
      await addItem(tire.id, quantity);
      
      toast({
        title: "Added to cart",
        description: `${quantity} x ${tire.name} has been added to your cart.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add item to cart. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Check if item is in wishlist
  const wishlistItem = wishlistItems?.find(item => 
    item.tire.id === Number(id)
  );
  
  // Toggle wishlist
  const toggleWishlist = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to add items to your wishlist.",
        variant: "destructive"
      });
      navigate("/auth");
      return;
    }
    
    if (!tire) return;
    
    try {
      if (wishlistItem) {
        await removeFromWishlist(wishlistItem.id);
        toast({
          title: "Removed from wishlist",
          description: `${tire.name} has been removed from your wishlist.`
        });
      } else {
        await addToWishlist(tire.id);
        toast({
          title: "Added to wishlist",
          description: `${tire.name} has been added to your wishlist.`
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update wishlist. Please try again.",
        variant: "destructive"
      });
    }
  };
  

  
  // Function to render star ratings
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-accent fill-accent" size={18} />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-accent fill-accent" size={18} />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-accent" size={18} />);
    }
    
    return stars;
  };
  
  if (tireLoading) {
    return (
      <div className="container mx-auto px-4 py-16 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (tireError || !tire) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="bg-white p-8 rounded-lg shadow-sm text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <p className="mb-6">The tire you're looking for doesn't exist or has been removed.</p>
          <Button asChild className="bg-primary hover:bg-primary/90 text-white">
            <Link href="/products">Browse All Tires</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>{tire.name} | TireHub</title>
        <meta name="description" content={`${tire.description}. Size: ${tire.size}, Type: ${tire.type}, Brand: ${tire.brand}`} />
      </Helmet>
      
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4 max-w-7xl">
          {/* Breadcrumbs - Desktop */}
          <nav className="mb-6 hidden md:flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-2">
              <li className="inline-flex items-center">
                <Link href="/" className="text-sm text-neutral-600 hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-neutral-400">/</span>
                  <Link href="/products" className="text-sm text-neutral-600 hover:text-primary">
                    Tires
                  </Link>
                </div>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-neutral-400">/</span>
                  <Link href={`/products?type=${tire.type}`} className="text-sm text-neutral-600 hover:text-primary">
                    {tire.type.charAt(0).toUpperCase() + tire.type.slice(1)}
                  </Link>
                </div>
              </li>
              <li>
                <div className="flex items-center">
                  <span className="mx-2 text-neutral-400">/</span>
                  <span className="text-sm font-medium text-primary">
                    {tire.name}
                  </span>
                </div>
              </li>
            </ol>
          </nav>
          
          {/* Mobile Breadcrumbs - Simplified */}
          <div className="flex items-center mb-4 md:hidden">
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center text-neutral-600 p-0 h-8"
              onClick={() => window.history.back()}
            >
              <ArrowRight className="h-3.5 w-3.5 mr-1 rotate-180" />
              <span className="text-sm">Back</span>
            </Button>
            <span className="mx-2 text-neutral-400">/</span>
            <Link href="/products" className="text-sm text-neutral-600 hover:text-primary">
              All Tires
            </Link>
          </div>
          
          {/* Product Details */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden p-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Product Image */}
              <div className="relative">
                <div className="border border-neutral-200 rounded-lg overflow-hidden">
                  <img 
                    src={tire.imageUrl} 
                    alt={tire.name} 
                    className="w-full h-auto object-cover aspect-square"
                  />
                </div>
                {tire.hasPromo && (
                  <div className="absolute top-4 left-4 bg-accent text-white px-3 py-1 font-bold text-sm rounded">
                    {tire.promoText || 'SAVE'}
                  </div>
                )}
              </div>
              
              {/* Product Info */}
              <div>
                <h1 className="text-2xl md:text-3xl font-bold mb-2">{tire.name}</h1>
                <div className="flex items-center mb-4">
                  <div className="flex mr-2">
                    {renderStars(Number(tire.rating))}
                  </div>
                  <span className="text-neutral-600">{Number(tire.rating).toFixed(1)} ({tire.reviewCount} reviews)</span>
                </div>
                
                <p className="text-neutral-700 mb-6">{tire.description}</p>
                
                <div className="mb-6">
                  <div className="flex items-center mb-2">
                    <InfoIcon className="h-4 w-4 text-neutral-500 mr-2" />
                    <span className="text-sm text-neutral-600">Size: <span className="font-medium">{tire.size}</span></span>
                  </div>
                  <div className="flex items-center mb-2">
                    <InfoIcon className="h-4 w-4 text-neutral-500 mr-2" />
                    <span className="text-sm text-neutral-600">Type: <span className="font-medium">{tire.type.charAt(0).toUpperCase() + tire.type.slice(1)}</span></span>
                  </div>
                  <div className="flex items-center mb-2">
                    <InfoIcon className="h-4 w-4 text-neutral-500 mr-2" />
                    <span className="text-sm text-neutral-600">Brand: <span className="font-medium">{tire.brand}</span></span>
                  </div>
                  <div className="flex items-center">
                    <InfoIcon className="h-4 w-4 text-neutral-500 mr-2" />
                    <span className="text-sm text-neutral-600">Stock: <span className="font-medium">{tire.stock && tire.stock > 0 ? `${tire.stock} available` : 'Out of stock'}</span></span>
                  </div>
                </div>
                
                <div className="border-t border-b border-neutral-200 py-4 mb-6">
                  <div className="flex items-center">
                    <div className="mr-4">
                      {tire.discountedPrice ? (
                        <>
                          <span className="text-neutral-500 line-through text-lg">${tire.price}</span>
                          <span className="font-bold text-secondary text-3xl ml-2">${tire.discountedPrice}</span>
                        </>
                      ) : (
                        <span className="font-bold text-3xl">${tire.price}</span>
                      )}
                      <span className="text-sm text-neutral-500 ml-1">each</span>
                    </div>
                    <span className="bg-success/10 text-success text-sm font-medium px-2 py-1 rounded">Free Shipping</span>
                  </div>
                </div>
                
                <div className="mb-6">
                  <label className="block text-sm font-medium mb-2">Quantity</label>
                  <div className="flex items-center">
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => updateQuantity(quantity - 1)}
                      disabled={quantity <= 1}
                      className="h-10 w-10 md:h-12 md:w-12 transition-all"
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="mx-4 font-medium text-lg">{quantity}</span>
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => updateQuantity(quantity + 1)}
                      disabled={quantity >= (tire.stock || 0)}
                      className="h-10 w-10 md:h-12 md:w-12 transition-all"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-3 mb-6 w-full">
                  <Button 
                    className="bg-primary hover:bg-primary/90 text-white font-medium py-3 px-6 flex-grow h-12 md:h-14 flex items-center justify-center transition-all"
                    onClick={handleAddToCart}
                    disabled={(tire.stock || 0) <= 0}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    Add to Cart
                  </Button>
                  <Button 
                    variant="outline" 
                    className={`flex items-center justify-center h-12 md:h-14 border transition-all ${wishlistItem ? 'border-secondary text-secondary' : 'border-neutral-300'}`}
                    onClick={toggleWishlist}
                    disabled={isAddingToWishlist || isRemovingFromWishlist}
                  >
                    {isAddingToWishlist || isRemovingFromWishlist ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Heart className={`mr-2 h-4 w-4 ${wishlistItem ? 'fill-current' : ''}`} />
                    )}
                    {wishlistItem ? 'Saved' : 'Save for Later'}
                  </Button>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="flex items-center">
                    <Truck className="h-5 w-5 text-primary mr-2" />
                    <span className="text-sm">Free Shipping</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-primary mr-2" />
                    <span className="text-sm">Fast Delivery</span>
                  </div>
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-primary mr-2" />
                    <span className="text-sm">45-Day Returns</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Product Tabs */}
          <Tabs defaultValue="details" className="mb-8">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="details">Product Details</TabsTrigger>
              <TabsTrigger value="reviews">Reviews ({tire.reviewCount})</TabsTrigger>
              <TabsTrigger value="shipping">Shipping & Returns</TabsTrigger>
            </TabsList>
            <TabsContent value="details">
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4">Product Specifications</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border-b border-neutral-200 py-2">
                      <span className="text-neutral-500">Brand:</span>
                      <span className="float-right font-medium">{tire.brand}</span>
                    </div>
                    <div className="border-b border-neutral-200 py-2">
                      <span className="text-neutral-500">Size:</span>
                      <span className="float-right font-medium">{tire.size}</span>
                    </div>
                    <div className="border-b border-neutral-200 py-2">
                      <span className="text-neutral-500">Type:</span>
                      <span className="float-right font-medium">{tire.type.charAt(0).toUpperCase() + tire.type.slice(1)}</span>
                    </div>
                    <div className="border-b border-neutral-200 py-2">
                      <span className="text-neutral-500">Load Rating:</span>
                      <span className="float-right font-medium">95H</span>
                    </div>
                    <div className="border-b border-neutral-200 py-2">
                      <span className="text-neutral-500">Warranty:</span>
                      <span className="float-right font-medium">50,000 miles</span>
                    </div>
                    <div className="border-b border-neutral-200 py-2">
                      <span className="text-neutral-500">Speed Rating:</span>
                      <span className="float-right font-medium">H (130 mph)</span>
                    </div>
                  </div>
                  
                  <h2 className="text-xl font-bold mt-8 mb-4">Features & Benefits</h2>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>All-season traction and handling for year-round performance</li>
                    <li>Advanced tread compound for enhanced wet grip and braking</li>
                    <li>Optimized pattern design for reduced road noise</li>
                    <li>Reinforced sidewalls for improved durability</li>
                    <li>Fuel-efficient design to help improve gas mileage</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="reviews">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold">Customer Reviews</h2>
                    {user ? (
                      isPurchaseStatusLoading ? (
                        <Button disabled className="bg-neutral-300 text-neutral-700 cursor-not-allowed">
                          <Loader className="w-4 h-4 mr-2 animate-spin" />
                          Checking...
                        </Button>
                      ) : canReview ? (
                        <Button 
                          className="bg-primary hover:bg-primary/90 text-white"
                          onClick={openReviewDialog}
                        >
                          Write a Review
                        </Button>
                      ) : hasReviewed ? (
                        <Button disabled className="bg-neutral-300 text-neutral-700 cursor-not-allowed">
                          You've Already Reviewed
                        </Button>
                      ) : hasPurchased ? (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span>
                              <Button disabled className="bg-neutral-300 text-neutral-700 cursor-not-allowed">
                                You've Already Reviewed
                              </Button>
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>You've already submitted a review for this product.</p>
                          </TooltipContent>
                        </Tooltip>
                      ) : (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span>
                              <Button disabled className="bg-neutral-300 text-neutral-700 cursor-not-allowed">
                                Purchase to Review
                              </Button>
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Only verified purchasers can review this product.</p>
                          </TooltipContent>
                        </Tooltip>
                      )
                    ) : (
                      <Button 
                        className="bg-primary hover:bg-primary/90 text-white"
                        onClick={() => navigate("/auth")}
                      >
                        Sign in to Review
                      </Button>
                    )}
                  </div>
                  
                  <div className="flex flex-col md:flex-row gap-6 mb-8">
                    <div className="md:w-1/3 bg-neutral-50 p-6 rounded-lg">
                      <div className="text-center mb-4">
                        <span className="text-5xl font-bold">{Number(tire.rating).toFixed(1)}</span>
                        <div className="flex justify-center my-2">
                          {renderStars(Number(tire.rating))}
                        </div>
                        <p className="text-sm text-neutral-500">Based on {tire.reviewCount} reviews</p>
                      </div>
                      
                      <div className="space-y-2">
                        {[5, 4, 3, 2, 1].map((star) => (
                          <div key={star} className="flex items-center">
                            <span className="text-sm w-8">{star} star</span>
                            <div className="flex-1 mx-2 bg-neutral-200 rounded-full h-2">
                              <div 
                                className="bg-accent h-2 rounded-full" 
                                style={{ width: `${Math.floor(Math.random() * (star === 5 ? 65 : star === 4 ? 25 : 10) + 5)}%` }}
                              ></div>
                            </div>
                            <span className="text-sm w-8 text-right">{Math.floor(Math.random() * (star === 5 ? 65 : star === 4 ? 25 : 10) + 5)}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="md:w-2/3">
                      {reviewsLoading ? (
                        <div className="flex justify-center py-8">
                          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                        </div>
                      ) : reviews && reviews.length > 0 ? (
                        <div className="space-y-6">
                          {reviews.map((review) => (
                            <div key={review.id} className="border-b border-neutral-200 pb-6">
                              <div className="flex items-center mb-2">
                                <div className="flex mr-2">
                                  {renderStars(review.rating)}
                                </div>
                                <span className="text-neutral-600 text-sm">{review.rating}.0</span>
                              </div>
                              <p className="text-neutral-700 mb-4">"{review.comment}"</p>
                              
                              {/* Review Images */}
                              {review.images && review.images.length > 0 && (
                                <div className="flex gap-2 mb-4">
                                  {review.images.map((image, index) => (
                                    <div 
                                      key={index} 
                                      className="w-20 h-20 border border-neutral-200 rounded-md overflow-hidden relative group cursor-pointer"
                                      onClick={() => setZoomImageUrl(image)}
                                    >
                                      <img 
                                        src={image} 
                                        alt={`Review image ${index + 1}`} 
                                        className="w-full h-full object-cover"
                                      />
                                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-200 flex items-center justify-center opacity-0 group-hover:opacity-100">
                                        <ZoomIn className="text-white" size={20} />
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                              
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <div className="w-8 h-8 bg-neutral-300 rounded-full flex items-center justify-center text-neutral-600 font-bold mr-2">
                                    {review.userName.split(' ').map(n => n[0]).join('')}
                                  </div>
                                  <div>
                                    <div className="flex items-center gap-2">
                                      <h4 className="font-medium text-sm">{review.userName}</h4>
                                      {/* Verified Purchaser Badge */}
                                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                        <Check className="w-3 h-3 mr-1" />
                                        Verified Purchase
                                      </span>
                                    </div>
                                    {review.userVehicle && (
                                      <p className="text-neutral-500 text-xs">{review.userVehicle}</p>
                                    )}
                                  </div>
                                </div>
                                <span className="text-xs text-neutral-500">{review.createdAt ? new Date(review.createdAt).toLocaleDateString() : 'Unknown'}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-neutral-500 mb-4">No reviews yet for this product.</p>
                          {user && hasPurchased && !hasReviewed && !isPurchaseStatusLoading ? (
                            <Button 
                              className="bg-primary hover:bg-primary/90 text-white"
                              onClick={openReviewDialog}
                            >
                              Be the First to Review
                            </Button>
                          ) : user ? (
                            <p className="text-neutral-600">Only verified purchasers can review this product.</p>
                          ) : (
                            <div className="mt-4">
                              <Button 
                                className="bg-primary hover:bg-primary/90 text-white"
                                onClick={() => navigate("/auth")}
                              >
                                Sign in to Review
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="shipping">
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4">Shipping Information</h2>
                  <div className="mb-6">
                    <h3 className="font-medium text-lg mb-2">Free Shipping</h3>
                    <p className="text-neutral-600 mb-2">Free standard shipping on all orders over $100. Typically arrives in 3-5 business days.</p>
                    <ul className="list-disc pl-5 text-sm text-neutral-500">
                      <li>Orders placed before 2 PM EST ship same day (Mon-Fri)</li>
                      <li>Deliveries are made Monday through Friday</li>
                      <li>No deliveries on weekends or holidays</li>
                    </ul>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="font-medium text-lg mb-2">Expedited Shipping</h3>
                    <p className="text-neutral-600">Need your tires faster? Expedited shipping options are available at checkout for an additional fee.</p>
                  </div>
                  
                  <h2 className="text-xl font-bold mb-4 mt-8">Returns & Warranty</h2>
                  <div className="mb-6">
                    <h3 className="font-medium text-lg mb-2">45-Day Satisfaction Guarantee</h3>
                    <p className="text-neutral-600 mb-2">If you're not completely satisfied with your tire purchase, you can return it within 45 days for a full refund or exchange.</p>
                    <p className="text-sm text-neutral-500">Note: Tires must be unused and in their original condition.</p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-lg mb-2">Manufacturer Warranty</h3>
                    <p className="text-neutral-600 mb-2">This tire comes with the manufacturer's standard warranty covering defects in materials and workmanship.</p>
                    <p className="text-sm text-neutral-500">Warranty details are included with your purchase and can also be found on the manufacturer's website.</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          {/* You Might Also Like */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold">You Might Also Like</h2>
              <Link href={`/products?type=${tire.type}`} className="text-black hover:underline font-medium flex items-center group">
                See More <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
            
            {similarLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : similarTires ? (
              <div className="relative">
                <div className="overflow-x-auto hide-scrollbar pb-4 -mx-4 px-4">
                  <div className="flex gap-4 snap-x">
                    {similarTires
                      .filter(t => t.id !== tire.id && t.type === tire.type)
                      .slice(0, 6)
                      .map((similarTire) => (
                        <div 
                          key={similarTire.id}
                          className="flex-none w-64 snap-start"
                        >
                          <div className="bg-white rounded-lg shadow-sm overflow-hidden group hover:shadow-md transition-shadow h-full flex flex-col relative border border-gray-100">
                            <Link href={`/product/${similarTire.id}`}>
                              <div className="relative">
                                <img src={similarTire.imageUrl} alt={similarTire.name} className="w-full h-36 object-contain p-2" />
                                {similarTire.hasPromo && (
                                  <div className="absolute bottom-0 left-0 right-0 bg-accent/90 text-white px-2 py-1 text-xs font-medium text-center">
                                    Flash sale
                                  </div>
                                )}
                                {similarTire.discountedPrice && !similarTire.hasPromo && (
                                  <div className="absolute top-2 left-2 bg-red-500 text-white rounded-full w-10 h-10 flex items-center justify-center text-xs font-bold">
                                    -
                                    {Math.round(
                                      ((Number(similarTire.price) - Number(similarTire.discountedPrice)) / 
                                      Number(similarTire.price)) * 100
                                    )}%
                                  </div>
                                )}
                              </div>
                            </Link>
                            
                            <div className="absolute top-2 right-2">
                              <WishlistButton
                                tireId={similarTire.id}
                                size="icon"
                                variant="ghost"
                                className="bg-white hover:bg-white p-1.5 h-7 w-7 rounded-full shadow-sm"
                              />
                            </div>
                            
                            <div className="p-3 flex-grow flex flex-col">
                              <div className="text-lg font-bold">
                                ${similarTire.discountedPrice || similarTire.price}
                              </div>
                              
                              <Link href={`/product/${similarTire.id}`}>
                                <h3 className="text-sm text-neutral-800 line-clamp-2 my-1 hover:text-primary cursor-pointer min-h-[40px]">
                                  {similarTire.name}
                                </h3>
                              </Link>
                              
                              <div className="flex items-center justify-between mt-2">
                                <div className="flex items-center">
                                  <div className="flex items-center text-xs font-medium">
                                    <svg width="22" height="22" viewBox="0 0 22 22" className="mr-1.5">
                                      <path d="M11 2C6.03 2 2 6.03 2 11C2 15.97 6.03 20 11 20C15.97 20 20 15.97 20 11C20 6.03 15.97 2 11 2Z" fill="#1E8FFF"/>
                                      <path d="M11 2C10.22 2 9.45 2.12 8.73 2.34C9.89 2.12 11.11 2.12 12.27 2.34C13.43 2.56 14.53 2.99 15.5 3.6C16.47 4.21 17.29 5.01 17.9 5.98C18.51 6.95 18.94 8.05 19.16 9.21C19.38 10.37 19.38 11.59 19.16 12.75C18.94 13.91 18.51 15.01 17.9 15.98C17.29 16.95 16.49 17.77 15.52 18.38C14.55 18.99 13.45 19.42 12.29 19.64C11.13 19.86 9.91 19.86 8.75 19.64C7.59 19.42 6.49 18.99 5.52 18.38C4.55 17.77 3.73 16.97 3.12 16C2.51 15.03 2.08 13.93 1.86 12.77C1.64 11.61 1.64 10.39 1.86 9.23C2.08 8.07 2.51 6.97 3.12 6C3.73 5.03 4.51 4.21 5.48 3.6C6.45 2.99 7.55 2.56 8.71 2.34C9.45 2.12 10.22 2 11 2Z" fill="#2196F3"/>
                                      <path d="M11 2.5C6.31 2.5 2.5 6.31 2.5 11C2.5 15.69 6.31 19.5 11 19.5C15.69 19.5 19.5 15.69 19.5 11C19.5 6.31 15.69 2.5 11 2.5ZM15.81 8.63L10.38 14.06C10.19 14.25 9.92 14.35 9.65 14.35C9.38 14.35 9.11 14.25 8.92 14.06L6.19 11.34C5.8 10.95 5.8 10.31 6.19 9.92C6.58 9.53 7.22 9.53 7.61 9.92L9.65 11.96L14.39 7.22C14.78 6.83 15.42 6.83 15.81 7.22C16.2 7.61 16.2 8.24 15.81 8.63Z" fill="#0F8EFF"/>
                                      <path d="M15.81 7.22C15.42 6.83 14.78 6.83 14.39 7.22L9.65 11.96L7.61 9.92C7.22 9.53 6.58 9.53 6.19 9.92C5.8 10.31 5.8 10.95 6.19 11.34L8.92 14.06C9.11 14.25 9.38 14.35 9.65 14.35C9.92 14.35 10.19 14.25 10.38 14.06L15.81 8.63C16.2 8.24 16.2 7.61 15.81 7.22Z" fill="white"/>
                                    </svg>
                                    <span className="text-black font-medium">KarLastik</span>
                                  </div>
                                </div>
                                
                                <Button
                                  size="icon"
                                  variant="default"
                                  className="rounded-full h-8 w-8 bg-primary hover:bg-primary/90"
                                  onClick={() => {
                                    addItem(similarTire.id, 1);
                                    toast({
                                      title: "Added to cart",
                                      description: `${similarTire.name} has been added to your cart.`,
                                    });
                                  }}
                                >
                                  <ShoppingCart className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
                <div className="absolute left-0 top-1/2 transform -translate-y-1/2 -ml-4 hidden md:block">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-10 w-10 rounded-full bg-white shadow-md hover:bg-neutral-100"
                    onClick={() => {
                      const container = document.querySelector('.overflow-x-auto');
                      if (container) {
                        container.scrollBy({ left: -300, behavior: 'smooth' });
                      }
                    }}
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                </div>
                
                <div className="absolute right-0 top-1/2 transform -translate-y-1/2 -mr-4 hidden md:block">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-10 w-10 rounded-full bg-white shadow-md hover:bg-neutral-100"
                    onClick={() => {
                      const container = document.querySelector('.overflow-x-auto');
                      if (container) {
                        container.scrollBy({ left: 300, behavior: 'smooth' });
                      }
                    }}
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
      
      {/* Review Dialog */}
      <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Write a Review</DialogTitle>
            <DialogDescription>
              Share your experience with this product to help other customers.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label>Rating</Label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    onClick={() => setReviewRating(rating)}
                    className="focus:outline-none"
                  >
                    <Star 
                      className={`h-8 w-8 ${reviewRating >= rating ? 'text-accent fill-accent' : 'text-neutral-300'}`} 
                    />
                  </button>
                ))}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="comment">Your Review</Label>
              <Textarea
                id="comment"
                placeholder="What did you like or dislike about this product?"
                rows={5}
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                className="resize-none"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Add Photos (Optional)</Label>
              <div className="flex flex-wrap gap-2">
                {reviewImages.map((image, index) => (
                  <div 
                    key={index} 
                    className="relative w-20 h-20 rounded-md overflow-hidden border border-neutral-200"
                  >
                    <img 
                      src={image} 
                      alt={`Review image ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute top-0 right-0 p-1 bg-black/70 rounded-bl-md"
                    >
                      <X className="h-3 w-3 text-white" />
                    </button>
                  </div>
                ))}
                
                {reviewImages.length < 3 && (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-20 h-20 flex flex-col items-center justify-center border border-dashed border-neutral-300 rounded-md hover:border-primary transition-colors"
                  >
                    <Upload className="h-6 w-6 text-neutral-500" />
                    <span className="text-xs text-neutral-500 mt-1">Add Photo</span>
                  </button>
                )}
                
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
              <p className="text-xs text-neutral-500 mt-1">
                You can add up to 3 images (Max 5MB each)
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsReviewDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              className="bg-primary hover:bg-primary/90 text-white"
              onClick={() => createReviewMutation.mutate()}
              disabled={createReviewMutation.isPending || !reviewComment.trim()}
            >
              {createReviewMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Review'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Image Zoom Dialog */}
      <Dialog open={!!zoomImageUrl} onOpenChange={(open) => !open && setZoomImageUrl(null)}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] p-1 overflow-hidden">
          <div className="relative w-full h-full">
            <DialogClose className="absolute top-2 right-2 z-10 bg-black/50 rounded-full p-1">
              <X className="h-4 w-4 text-white" />
            </DialogClose>
            {zoomImageUrl && (
              <img 
                src={zoomImageUrl} 
                alt="Zoomed review image" 
                className="w-full h-full object-contain max-h-[80vh]"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProductDetailPage;

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface PaymentMethod {
  id: number;
  cardholderName: string;
  cardType: string;
  lastFourDigits: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
  createdAt: string;
}

interface AddPaymentMethodData {
  cardholderName: string;
  cardNumber: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
  isDefault?: boolean;
  cardType?: string;
  lastFourDigits?: string;
}

export const usePaymentMethods = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: paymentMethods = [], isLoading, error } = useQuery<PaymentMethod[], Error>({
    queryKey: ['/api/payment-methods'],
    retry: false,
  });

  const addPaymentMethodMutation = useMutation({
    mutationFn: async (data: AddPaymentMethodData) => {
      const response = await apiRequest('POST', '/api/payment-methods', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['/api/payment-methods']});
      toast({
        title: 'Payment method added',
        description: 'Your payment method has been added successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error adding payment method',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updatePaymentMethodMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<AddPaymentMethodData> }) => {
      const response = await apiRequest('PUT', `/api/payment-methods/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['/api/payment-methods']});
      toast({
        title: 'Payment method updated',
        description: 'Your payment method has been updated successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error updating payment method',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deletePaymentMethodMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/payment-methods/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['/api/payment-methods']});
      toast({
        title: 'Payment method deleted',
        description: 'Your payment method has been deleted successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error deleting payment method',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const setDefaultPaymentMethodMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('POST', `/api/payment-methods/${id}/set-default`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['/api/payment-methods']});
      toast({
        title: 'Default payment method set',
        description: 'Your default payment method has been updated',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error setting default payment method',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    paymentMethods,
    isLoading,
    error,
    addPaymentMethodMutation,
    updatePaymentMethodMutation,
    deletePaymentMethodMutation,
    setDefaultPaymentMethodMutation,
  };
};
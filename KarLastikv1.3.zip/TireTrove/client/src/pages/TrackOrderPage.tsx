import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Steps, Step } from '@/components/ui/steps';
import { Loader2, Package, Truck, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';

interface OrderTrackingDetails {
  id: number;
  status: string;
  customerName: string;
  createdAt: string;
  estimatedDelivery: string;
  items: {
    name: string;
    quantity: number;
    price: string;
  }[];
  trackingNumber?: string;
  shippingAddress: string;
  totalAmount: string;
  lastUpdated: string;
  statusHistory: {
    status: string;
    timestamp: string;
    description: string;
  }[];
}

const TrackOrderPage: React.FC = () => {
  const { toast } = useToast();
  const [orderNumber, setOrderNumber] = useState('');
  const [email, setEmail] = useState('');
  
  const trackMutation = useMutation({
    mutationFn: async (data: {orderNumber: string, email: string}) => {
      const response = await apiRequest('POST', '/api/orders/track', data);
      return await response.json() as OrderTrackingDetails;
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message || 'An error occurred while tracking your order',
        variant: 'destructive',
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderNumber || !email) {
      toast({
        title: 'Missing information',
        description: 'Please enter both order number and email',
        variant: 'destructive',
      });
      return;
    }
    
    trackMutation.mutate({ orderNumber, email });
  };
  
  // Get current step from order status
  const getCurrentStep = (status: string): number => {
    switch (status) {
      case 'pending':
        return 0;
      case 'processing':
        return 1;
      case 'shipped':
        return 2;
      case 'delivered':
        return 3;
      case 'cancelled':
        return 4;
      default:
        return 0;
    }
  };
  
  const renderStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-blue-500" />;
      case 'processing':
        return <Package className="h-5 w-5 text-amber-500" />;
      case 'shipped':
        return <Truck className="h-5 w-5 text-purple-500" />;
      case 'delivered':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'cancelled':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5" />;
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-10">
      <div className="flex flex-col items-center justify-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Track Your Order</h1>
        <p className="text-muted-foreground text-center max-w-2xl">
          Enter your order number and email address to track the status of your order.
        </p>
      </div>
      
      {!trackMutation.data ? (
        <Card className="mx-auto max-w-md">
          <CardHeader>
            <CardTitle>Order Tracking</CardTitle>
            <CardDescription>
              Enter the details below to check your order status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="order-number">Order Number</Label>
                  <Input 
                    id="order-number"
                    placeholder="e.g. TH-00001"
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email"
                    type="email"
                    placeholder="Enter the email used for order"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter>
            <Button 
              onClick={handleSubmit} 
              className="w-full"
              disabled={trackMutation.isPending}
            >
              {trackMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Tracking...
                </>
              ) : (
                'Track Order'
              )}
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <div className="grid gap-8 md:grid-cols-3">
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>
                Order <span className="bg-primary/10 text-primary px-2 py-1 rounded font-mono">TH-{trackMutation.data.id.toString().padStart(5, '0')}</span>
              </CardTitle>
              <CardDescription>
                Placed on {format(new Date(trackMutation.data.createdAt), 'MMMM d, yyyy')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Status Timeline */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4">Order Status</h3>
                
                {trackMutation.data.status === 'cancelled' ? (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800 flex items-center">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    <span>This order has been cancelled</span>
                  </div>
                ) : (
                  <Steps currentStep={getCurrentStep(trackMutation.data.status)}>
                    <Step title="Order Placed" description="We've received your order" />
                    <Step title="Processing" description="Preparing your items" />
                    <Step title="Shipped" description="Your order is on the way" />
                    <Step title="Delivered" description="Delivered to your address" />
                  </Steps>
                )}
              </div>
              
              {/* Status History */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Status Updates</h3>
                <div className="space-y-4">
                  {trackMutation.data.statusHistory.map((status, idx) => (
                    <div key={idx} className="flex">
                      <div className="mr-4 mt-1">
                        {renderStatusIcon(status.status)}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium capitalize">{status.status}</h4>
                        <p className="text-sm text-muted-foreground mb-1">
                          {format(new Date(status.timestamp), 'MMMM d, yyyy • h:mm a')}
                        </p>
                        <p className="text-sm">{status.description}</p>
                        
                        {idx < trackMutation.data.statusHistory.length - 1 && (
                          <div className="border-l-2 border-muted h-6 ml-2 my-1"></div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Estimated Delivery */}
              {trackMutation.data.status !== 'delivered' && trackMutation.data.status !== 'cancelled' && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="text-blue-800 font-medium">Estimated Delivery</h3>
                  <p className="text-blue-700">
                    {format(new Date(trackMutation.data.estimatedDelivery), 'MMMM d, yyyy')}
                  </p>
                </div>
              )}
              
              {/* Tracking Number */}
              {trackMutation.data.trackingNumber && (
                <div>
                  <h3 className="text-lg font-semibold">Tracking Number</h3>
                  <p className="font-mono bg-gray-50 p-2 rounded border mt-2">
                    {trackMutation.data.trackingNumber}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Shipping Address</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-line">
                  {trackMutation.data.customerName}<br />
                  {trackMutation.data.shippingAddress}
                </p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-medium mb-2">Items</h3>
                <ul className="space-y-3">
                  {trackMutation.data.items.map((item, idx) => (
                    <li key={idx} className="flex justify-between text-sm">
                      <span>{item.name} × {item.quantity}</span>
                      <span className="font-medium">${item.price}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <Separator />
              
              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span>${trackMutation.data.totalAmount}</span>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  setEmail('');
                  setOrderNumber('');
                  trackMutation.reset();
                }}
              >
                Track Another Order
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}
    </div>
  );
};

export default TrackOrderPage;
// Order Tracking Test Script
// This script tests the order tracking endpoint by verifying that orders with different statuses
// return the expected information.

import fetch from 'node-fetch';
import readline from 'readline';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function testOrderTracking() {
    console.log('🔍 Testing Order Tracking Functionality');
    
    try {
        // Ask the user to enter order information
        const orderNumber = await new Promise(resolve => {
            rl.question('\nEnter the order number to track: ', answer => {
                resolve(answer.trim());
            });
        });
        
        // We use a fixed email for this test
        const testEmail = 'test@example.com';
        
        console.log(`\n📝 Testing tracking for order #${orderNumber} with email ${testEmail}`);
        
        // Make the tracking request
        const response = await fetch('http://localhost:5000/api/orders/track', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                orderNumber,
                email: testEmail
            })
        });
        
        if (!response.ok) {
            throw new Error(`Failed to track order. Status: ${response.status}`);
        }
        
        const trackingData = await response.json();
        
        // Display the tracking results
        console.log('\n✅ Successfully retrieved tracking information:');
        console.log(`   Order Status: ${trackingData.status}`);
        console.log(`   Order Total: $${trackingData.totalAmount}`);
        console.log(`   Tracking Number: ${trackingData.trackingNumber || 'Not available'}`);
        
        // Display status history timeline
        console.log('\n📊 Status History:');
        if (trackingData.statusHistory && trackingData.statusHistory.length > 0) {
            trackingData.statusHistory.forEach((item, index) => {
                const date = new Date(item.date).toLocaleString();
                console.log(`   ${index + 1}. ${item.status} - ${date}`);
                if (item.description) {
                    console.log(`      ${item.description}`);
                }
            });
        } else {
            console.log('   No status history available');
        }
        
        // Verify the correct status history length based on order status
        const statusHistoryExpectedCounts = {
            'pending': 1,
            'processing': 2,
            'shipped': 3,
            'delivered': 4,
            'cancelled': 2
        };
        
        const expectedHistoryLength = statusHistoryExpectedCounts[trackingData.status] || 0;
        
        if (trackingData.statusHistory.length === expectedHistoryLength) {
            console.log(`\n✅ Status history has the expected ${expectedHistoryLength} entries for a ${trackingData.status} order`);
        } else {
            console.error(`\n❌ Expected ${expectedHistoryLength} status history entries for a ${trackingData.status} order, but got ${trackingData.statusHistory.length}`);
        }
        
        // Check for tracking number if shipped or delivered
        if (trackingData.status === 'shipped' || trackingData.status === 'delivered') {
            if (trackingData.trackingNumber) {
                console.log(`\n✅ Order has tracking number as expected for ${trackingData.status} status`);
            } else {
                console.error(`\n❌ Order is ${trackingData.status} but missing tracking number`);
            }
        }
        
        console.log('\n👍 Order tracking test completed');
    } catch (error) {
        console.error('❌ Test failed with error:', error);
    } finally {
        rl.close();
    }
}

// Run the test
testOrderTracking();
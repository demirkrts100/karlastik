import { Link } from "wouter";
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Package, 
  Star, 
  Users, 
  LogOut,
  ChevronDown, 
  Settings
} from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";

type AdminHeaderProps = {
  title?: string;
};

const AdminHeader = ({ title = "TireHub Admin" }: AdminHeaderProps) => {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        toast({
          title: "Logged out",
          description: "You have been logged out successfully.",
        });
      },
    });
  };

  const menuItems = [
    { label: "Dashboard", icon: LayoutDashboard, path: "/admin" },
    { label: "Orders", icon: ShoppingBag, path: "/admin/orders" },
    { label: "Products", icon: Package, path: "/admin/products" },
    { label: "Reviews", icon: Star, path: "/admin/reviews" },
    { label: "Users", icon: Users, path: "/admin/users" },
  ];

  return (
    <header className="bg-white border-b border-neutral-200 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Title */}
          <div className="flex items-center">
            <Link href="/admin">
              <div className="flex items-center cursor-pointer">
                <span className="bg-black text-white font-bold py-1 px-2 rounded text-xl mr-2">TH</span>
                <span className="text-xl font-semibold text-neutral-800">{title}</span>
              </div>
            </Link>
          </div>

          {/* Main Navigation */}
          <nav className="hidden md:flex space-x-1">
            {menuItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <div className="inline-flex items-center px-3 py-2 rounded text-sm text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors cursor-pointer">
                  <item.icon className="h-4 w-4 mr-2" />
                  {item.label}
                </div>
              </Link>
            ))}
          </nav>

          {/* User Menu */}
          <div className="flex items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-black text-white text-xs">
                      {user?.username?.substring(0, 2).toUpperCase() || 'AD'}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Mobile Navigation Toggle */}
          <div className="md:hidden">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <span className="sr-only">Open menu</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {menuItems.map((item) => (
                  <DropdownMenuItem key={item.path} asChild>
                    <Link href={item.path}>
                      <div className="flex items-center cursor-pointer w-full">
                        <item.icon className="mr-2 h-4 w-4" />
                        <span>{item.label}</span>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;
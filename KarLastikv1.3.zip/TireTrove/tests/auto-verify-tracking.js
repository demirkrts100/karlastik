// Automated Order Tracking Test Script
// This script automatically tests the order tracking endpoint for all test orders
// that were created by the create-test-orders.js script

import fetch from 'node-fetch';

// The test orders are from IDs 4-8 based on the previous script output
const TEST_ORDER_IDS = [4, 5, 6, 7, 8];
const TEST_EMAIL = 'test@example.com';

async function testOrderTracking() {
    console.log('🔍 Testing Order Tracking Functionality');
    
    try {
        for (const orderId of TEST_ORDER_IDS) {
            console.log(`\n📝 Testing tracking for order #${orderId} with email ${TEST_EMAIL}`);
            
            // Make the tracking request
            const response = await fetch('http://localhost:5000/api/orders/track', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    orderNumber: orderId.toString(),
                    email: TEST_EMAIL
                })
            });
            
            if (!response.ok) {
                console.error(`❌ Failed to track order #${orderId}. Status: ${response.status}`);
                continue;
            }
            
            const trackingData = await response.json();
            
            // Display the tracking results
            console.log('✅ Successfully retrieved tracking information:');
            console.log(`   Order Status: ${trackingData.status}`);
            console.log(`   Order Total: $${trackingData.totalAmount}`);
            console.log(`   Tracking Number: ${trackingData.trackingNumber || 'Not available'}`);
            
            // Display status history timeline
            console.log('\n📊 Status History:');
            if (trackingData.statusHistory && trackingData.statusHistory.length > 0) {
                trackingData.statusHistory.forEach((item, index) => {
                    const date = new Date(item.date).toLocaleString();
                    console.log(`   ${index + 1}. ${item.status} - ${date}`);
                    if (item.description) {
                        console.log(`      ${item.description}`);
                    }
                });
            } else {
                console.log('   No status history available');
            }
            
            // Verify the correct status history length based on order status
            const statusHistoryExpectedCounts = {
                'pending': 1,
                'processing': 2,
                'shipped': 3,
                'delivered': 4,
                'cancelled': 2
            };
            
            const expectedHistoryLength = statusHistoryExpectedCounts[trackingData.status] || 0;
            
            if (trackingData.statusHistory.length === expectedHistoryLength) {
                console.log(`\n✅ Status history has the expected ${expectedHistoryLength} entries for a ${trackingData.status} order`);
            } else {
                console.error(`\n❌ Expected ${expectedHistoryLength} status history entries for a ${trackingData.status} order, but got ${trackingData.statusHistory.length}`);
            }
            
            // Check for tracking number if shipped or delivered
            if (trackingData.status === 'shipped' || trackingData.status === 'delivered') {
                if (trackingData.trackingNumber) {
                    console.log(`\n✅ Order has tracking number as expected for ${trackingData.status} status`);
                } else {
                    console.error(`\n❌ Order is ${trackingData.status} but missing tracking number`);
                }
            }
        }
        
        console.log('\n👍 Order tracking tests completed');
    } catch (error) {
        console.error('❌ Test failed with error:', error);
    }
}

// Run the test
testOrderTracking();
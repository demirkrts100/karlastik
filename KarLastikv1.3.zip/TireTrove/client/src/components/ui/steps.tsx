import React from 'react';
import { cn } from '@/lib/utils';

interface StepProps {
  title: string;
  description?: string;
  active?: boolean;
  completed?: boolean;
  className?: string;
}

export const Step = ({
  title,
  description,
  active,
  completed,
  className,
}: StepProps) => {
  // This is just a container component, actual rendering is handled by the Steps parent
  return null;
};

interface StepsProps {
  children: React.ReactNode;
  currentStep: number;
  className?: string;
}

export const Steps = ({ children, currentStep, className }: StepsProps) => {
  // Get all Step components from children
  const steps = React.Children.toArray(children).filter(
    (child) => React.isValidElement(child) && child.type === Step
  ) as React.ReactElement<StepProps>[];

  return (
    <div className={cn('w-full', className)}>
      <ol className="flex items-center w-full">
        {steps.map((step, index) => {
          const stepProps = step.props;
          const isActive = index === currentStep;
          const isCompleted = index < currentStep;
          const isLast = index === steps.length - 1;

          return (
            <li
              key={index}
              className={cn(
                'flex items-center',
                !isLast && 'w-full',
                isActive && 'text-primary',
                isCompleted && 'text-primary'
              )}
            >
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    'flex items-center justify-center w-8 h-8 rounded-full border-2 bg-background z-10',
                    isActive && 'border-primary',
                    isCompleted && 'border-primary bg-primary text-primary-foreground',
                    !isActive && !isCompleted && 'border-muted-foreground'
                  )}
                >
                  {isCompleted ? (
                    <svg className="w-3.5 h-3.5" viewBox="0 0 20 20" fill="currentColor">
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  ) : (
                    <span className="text-xs font-medium">{index + 1}</span>
                  )}
                </div>
                <div className="mt-2 text-center">
                  <h3
                    className={cn(
                      'text-sm font-medium',
                      isActive && 'text-foreground',
                      isCompleted && 'text-foreground',
                      !isActive && !isCompleted && 'text-muted-foreground'
                    )}
                  >
                    {stepProps.title}
                  </h3>
                  {stepProps.description && (
                    <p
                      className={cn(
                        'text-xs mt-1',
                        isActive && 'text-muted-foreground',
                        isCompleted && 'text-muted-foreground',
                        !isActive && !isCompleted && 'text-muted-foreground/60'
                      )}
                    >
                      {stepProps.description}
                    </p>
                  )}
                </div>
              </div>
              {!isLast && (
                <div
                  className={cn(
                    'flex-auto border-t-2 transition duration-500 ease-in-out',
                    isCompleted ? 'border-primary' : 'border-muted'
                  )}
                ></div>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
};
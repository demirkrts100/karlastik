import { Helmet } from 'react-helmet-async';
import HeroSection from '@/components/home/HeroSection';
import VehicleSearch from '@/components/home/VehicleSearch';
import FeaturedDeals from '@/components/home/FeaturedDeals';
import FeaturedBrands from '@/components/home/FeaturedBrands';
import SeasonalPromo from '@/components/home/SeasonalPromo';
import ProductCard from '@/components/product/ProductCard';
import CustomerReviews from '@/components/home/CustomerReviews';
import InstallationServices from '@/components/home/InstallationServices';
import VendorSpotlight from '@/components/home/VendorSpotlight';
import NewsletterSignup from '@/components/home/NewsletterSignup';
import FAQSection from '@/components/home/FAQSection';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>TireHub - Multi-Vendor Tire Marketplace</title>
        <meta name="description" content="Find the perfect tires for your vehicle from top brands at unbeatable prices. Free shipping, easy returns, and professional installation available." />
        <meta property="og:title" content="TireHub - Multi-Vendor Tire Marketplace" />
        <meta property="og:description" content="Find the perfect tires for your vehicle from top brands at unbeatable prices." />
        <meta property="og:type" content="website" />
      </Helmet>
      
      <HeroSection />
      <VehicleSearch />
      <FeaturedDeals />
      <FeaturedBrands />
      <SeasonalPromo />
      <CustomerReviews />
      <InstallationServices />
      <VendorSpotlight />
      <NewsletterSignup />
      <FAQSection />
    </>
  );
};

export default HomePage;

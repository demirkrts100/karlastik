import { Helmet } from "react-helmet-async";
import { useState, useEffect } from "react";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ShoppingBag, 
  Package, 
  Star, 
  Users, 
  TrendingUp, 
  PieChart, 
  DollarSign,
  CheckCircle2,
  Clock,
  Truck,
  TagIcon,
  XCircle,
  Loader2
} from "lucide-react";
import { fetchDashboardMetrics, DashboardMetrics } from "@/services/adminService";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface AdminDashboardPageProps {
  title?: string;
}

const AdminDashboardPage = ({ title = "Dashboard" }: AdminDashboardPageProps) => {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const data = await fetchDashboardMetrics();
        setMetrics(data);
        setError(null);
      } catch (err) {
        console.error("Error loading dashboard metrics:", err);
        setError("Failed to load dashboard data. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // Define stats based on metrics data
  const stats = [
    { 
      title: "Total Orders", 
      value: metrics?.orders.total ?? 0, 
      icon: ShoppingBag, 
      color: "bg-blue-500" 
    },
    { 
      title: "Products", 
      value: metrics?.products.total ?? 0, 
      icon: Package, 
      color: "bg-green-500" 
    },
    { 
      title: "Reviews", 
      value: metrics?.reviews.total ?? 0, 
      icon: Star, 
      color: "bg-yellow-500" 
    },
    { 
      title: "Users", 
      value: metrics?.users.total ?? 0, 
      icon: Users, 
      color: "bg-purple-500" 
    }
  ];

  // Helper function to get appropriate badge color for order status
  const getStatusBadgeClass = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case 'processing':
        return "bg-blue-100 text-blue-800 border-blue-200";
      case 'shipped':
        return "bg-indigo-100 text-indigo-800 border-indigo-200";
      case 'delivered':
        return "bg-green-100 text-green-800 border-green-200";
      case 'cancelled':
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-neutral-100 text-neutral-800 border-neutral-200";
    }
  };

  // Helper function to get appropriate icon for order status
  const getStatusIcon = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return <Clock className="h-3 w-3 mr-1" />;
      case 'processing':
        return <Loader2 className="h-3 w-3 mr-1 animate-spin" />;
      case 'shipped':
        return <Truck className="h-3 w-3 mr-1" />;
      case 'delivered':
        return <CheckCircle2 className="h-3 w-3 mr-1" />;
      case 'cancelled':
        return <XCircle className="h-3 w-3 mr-1" />;
      default:
        return null;
    }
  };

  return (
    <>
      <Helmet>
        <title>{title} | TireHub Admin</title>
        <meta name="description" content={`TireHub admin ${title.toLowerCase()} for managing the marketplace.`} />
      </Helmet>
      <AdminLayout title={title}>
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-neutral-800">{title}</h1>
          <p className="text-neutral-600">Welcome to the TireHub admin {title.toLowerCase()}.</p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md text-red-700">
            {error}
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-4 sm:p-6 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">{stat.title}</p>
                  {loading ? (
                    <Skeleton className="h-8 w-16 mt-1" />
                  ) : (
                    <p className="text-2xl font-bold mt-1">{stat.value}</p>
                  )}
                </div>
                <div className={`${stat.color} p-3 rounded-full text-white`}>
                  <stat.icon className="h-5 w-5 sm:h-6 sm:w-6" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Secondary Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-white/80 font-medium text-sm">Featured Products</h3>
                <TagIcon className="h-5 w-5 text-white/70" />
              </div>
              {loading ? (
                <Skeleton className="h-8 w-16 bg-white/20" />
              ) : (
                <p className="text-3xl font-bold">{metrics?.products.featured}</p>
              )}
              <p className="text-white/70 text-sm mt-1">
                {loading ? "" : `${((metrics?.products.featured || 0) / (metrics?.products.total || 1) * 100).toFixed(0)}% of total products`}
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-orange-500 to-red-500 text-white">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-white/80 font-medium text-sm">Revenue Today</h3>
                <DollarSign className="h-5 w-5 text-white/70" />
              </div>
              {loading ? (
                <Skeleton className="h-8 w-20 bg-white/20" />
              ) : (
                <p className="text-3xl font-bold">${metrics?.sales.today.toFixed(2)}</p>
              )}
              <p className="text-white/70 text-sm mt-1">
                {loading ? "" : `${((metrics?.sales.today || 0) / (metrics?.sales.month || 1) * 100).toFixed(1)}% of monthly revenue`}
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-white/80 font-medium text-sm">Average Rating</h3>
                <Star className="h-5 w-5 text-white/70" />
              </div>
              {loading ? (
                <Skeleton className="h-8 w-16 bg-white/20" />
              ) : (
                <p className="text-3xl font-bold">{metrics?.reviews.averageRating || 0}/5</p>
              )}
              <p className="text-white/70 text-sm mt-1">
                {loading ? "" : `From ${metrics?.reviews.total || 0} total reviews`}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Sales & Products Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-8">
          <Card>
            <CardHeader className="px-4 sm:px-6 py-4">
              <CardTitle className="text-base sm:text-lg flex items-center">
                <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-blue-500" />
                Sales Overview
              </CardTitle>
              <CardDescription>Monthly sales performance</CardDescription>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-6">
              {loading ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <p className="text-neutral-600">Today</p>
                    <p className="font-semibold">${metrics?.sales.today.toFixed(2)}</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-neutral-600">This Week</p>
                    <p className="font-semibold">${metrics?.sales.week.toFixed(2)}</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-neutral-600">This Month</p>
                    <p className="font-semibold">${metrics?.sales.month.toFixed(2)}</p>
                  </div>
                  <div className="flex justify-between items-center pt-3 border-t">
                    <p className="text-neutral-600 font-medium">Year to Date</p>
                    <p className="font-semibold text-green-600">${metrics?.sales.yearToDate.toFixed(2)}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="px-4 sm:px-6 py-4">
              <CardTitle className="text-base sm:text-lg flex items-center">
                <Package className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-green-500" />
                Top Products
              </CardTitle>
              <CardDescription>Best selling items</CardDescription>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-6">
              {loading ? (
                <div className="space-y-4">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : metrics?.topProducts && metrics.topProducts.length > 0 ? (
                <div className="space-y-4">
                  {metrics.topProducts.map((product, idx) => (
                    <div key={idx} className="flex items-center justify-between border-b pb-3 last:border-0 last:pb-0">
                      <div className="flex items-center">
                        <div className="bg-neutral-100 w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center mr-3 text-xs sm:text-sm font-semibold text-neutral-700">
                          #{idx + 1}
                        </div>
                        <div>
                          <p className="font-medium text-sm sm:text-base">{product.name}</p>
                          <p className="text-xs text-neutral-500">{product.brand}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{product.price}</p>
                        <p className="text-xs text-neutral-500">{product.sales} sold</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-32 border rounded-md bg-neutral-50">
                  <p className="text-neutral-500">No product data available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
          <Card>
            <CardHeader className="px-4 sm:px-6 py-4">
              <CardTitle className="text-base sm:text-lg flex items-center">
                <ShoppingBag className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-blue-500" />
                Recent Orders
              </CardTitle>
              <CardDescription>Latest customer purchases</CardDescription>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-6">
              {loading ? (
                <div className="space-y-4">
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                </div>
              ) : metrics?.recentOrders && metrics.recentOrders.length > 0 ? (
                <div className="space-y-4">
                  {metrics.recentOrders.map((order, idx) => (
                    <div key={idx} className="flex items-center justify-between border-b pb-3 last:border-0 last:pb-0">
                      <div className="flex items-center">
                        <div className="bg-neutral-100 w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center mr-3">
                          <span className="text-xs sm:text-sm font-semibold text-neutral-700">#{order.id}</span>
                        </div>
                        <div>
                          <p className="font-medium text-sm sm:text-base">{order.customerName}</p>
                          <p className="text-xs text-neutral-500">{order.date} • {order.total}</p>
                        </div>
                      </div>
                      <div>
                        <Badge 
                          variant="outline" 
                          className={`${getStatusBadgeClass(order.status)} flex items-center text-xs px-2 py-1`}
                        >
                          {getStatusIcon(order.status)}
                          <span className="capitalize">{order.status}</span>
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-32 border rounded-md bg-neutral-50">
                  <p className="text-neutral-500">No recent orders</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="px-4 sm:px-6 py-4">
              <CardTitle className="text-base sm:text-lg flex items-center">
                <Star className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-yellow-500" />
                Reviews Status
              </CardTitle>
              <CardDescription>Review moderation overview</CardDescription>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-6">
              {loading ? (
                <div className="space-y-4">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 rounded-md bg-yellow-50 border border-yellow-100 flex justify-between items-center">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-yellow-500 mr-3" />
                      <div>
                        <p className="font-medium">Pending Reviews</p>
                        <p className="text-sm text-yellow-700">Awaiting moderation</p>
                      </div>
                    </div>
                    <div className="text-xl font-bold text-yellow-700">{metrics?.reviews.pending || 0}</div>
                  </div>
                  
                  <div className="p-4 rounded-md bg-green-50 border border-green-100 flex justify-between items-center">
                    <div className="flex items-center">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-3" />
                      <div>
                        <p className="font-medium">Approved Reviews</p>
                        <p className="text-sm text-green-700">Visible to customers</p>
                      </div>
                    </div>
                    <div className="text-xl font-bold text-green-700">{metrics?.reviews.approved || 0}</div>
                  </div>
                  
                  <div className="p-4 rounded-md bg-red-50 border border-red-100 flex justify-between items-center">
                    <div className="flex items-center">
                      <XCircle className="h-5 w-5 text-red-500 mr-3" />
                      <div>
                        <p className="font-medium">Rejected Reviews</p>
                        <p className="text-sm text-red-700">Hidden from customers</p>
                      </div>
                    </div>
                    <div className="text-xl font-bold text-red-700">{metrics?.reviews.rejected || 0}</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    </>
  );
};

export default AdminDashboardPage;
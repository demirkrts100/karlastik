import { apiRequest } from "@/lib/queryClient";

// Types for dashboard metrics
export interface DashboardMetrics {
  sales: {
    total: number;
    today: number;
    week: number;
    month: number;
    yearToDate: number;
  };
  products: {
    total: number;
    featured: number;
    onSale: number;
    lowStock: number;
  };
  users: {
    total: number;
    active: number;
    new: number;
  };
  orders: {
    total: number;
    pending: number;
    processing: number;
    shipped: number;
    delivered: number;
    cancelled: number;
  };
  reviews: {
    total: number;
    pending: number;
    approved: number;
    rejected: number;
    averageRating: number;
  };
  topProducts: Array<{
    id: number;
    name: string;
    brand: string;
    sales: number;
    price: string;
  }>;
  recentOrders: Array<{
    id: number;
    date: string;
    customerName: string;
    total: string;
    status: string;
  }>;
}

// Fetch dashboard metrics
export const fetchDashboardMetrics = async (): Promise<DashboardMetrics> => {
  try {
    // Fetch metrics directly from the backend API
    const response = await apiRequest("GET", "/api/admin/dashboard");
    
    if (!response.ok) {
      throw new Error(`Error fetching dashboard metrics: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error fetching dashboard metrics:", error);
    throw error;
  }
};

// Fetch products with sorting, filtering, and pagination
export const fetchProducts = async (params?: {
  search?: string;
  category?: string;
  brand?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}) => {
  try {
    // In production, we'd send these params to the server API
    let tires = await apiRequest("GET", "/api/tires").then(res => res.json());
    
    // Apply search filter
    if (params?.search) {
      const searchLower = params.search.toLowerCase();
      tires = tires.filter((tire: any) => 
        tire.name.toLowerCase().includes(searchLower) || 
        tire.brand.toLowerCase().includes(searchLower) ||
        tire.description.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply category filter
    if (params?.category && params.category !== 'all') {
      tires = tires.filter((tire: any) => tire.type === params.category);
    }
    
    // Apply brand filter
    if (params?.brand && params.brand !== 'all') {
      tires = tires.filter((tire: any) => tire.brand === params.brand);
    }
    
    // Apply sorting
    if (params?.sortBy) {
      tires.sort((a: any, b: any) => {
        let aValue = a[params.sortBy as keyof typeof a];
        let bValue = b[params.sortBy as keyof typeof b];
        
        // Handle price as a special case (it's a string with a $ sign)
        if (params.sortBy === 'price') {
          aValue = parseFloat(aValue.replace(/[^0-9.-]+/g, ''));
          bValue = parseFloat(bValue.replace(/[^0-9.-]+/g, ''));
        }
        
        if (params.sortOrder === 'desc') {
          return aValue > bValue ? -1 : 1;
        }
        return aValue < bValue ? -1 : 1;
      });
    }
    
    // Apply pagination
    const page = params?.page || 1;
    const limit = params?.limit || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedTires = tires.slice(startIndex, endIndex);
    
    return {
      data: paginatedTires,
      meta: {
        total: tires.length,
        page,
        limit,
        totalPages: Math.ceil(tires.length / limit)
      }
    };
  } catch (error) {
    console.error("Error fetching products:", error);
    throw error;
  }
};

// Fetch reviews with sorting, filtering, and pagination
export const fetchReviews = async (params?: {
  search?: string;
  status?: string;
  rating?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}) => {
  try {
    // In production, we'd send these params to the server API
    let reviews = await apiRequest("GET", "/api/reviews").then(res => res.json());
    
    // Fetch additional data for reviews
    const tires = await apiRequest("GET", "/api/tires").then(res => res.json());
    
    // Enhance reviews with product information
    reviews = reviews.map((review: any) => {
      const tire = tires.find((t: any) => t.id === review.tireId);
      return {
        ...review,
        product: tire ? tire.name : 'Unknown Product',
        brand: tire ? tire.brand : 'Unknown Brand',
        status: review.isApproved ? 'approved' : review.isRejected ? 'rejected' : 'pending',
        hasImages: review.images && review.images.length > 0
      };
    });
    
    // Apply search filter
    if (params?.search) {
      const searchLower = params.search.toLowerCase();
      reviews = reviews.filter((review: any) => 
        review.userName?.toLowerCase().includes(searchLower) || 
        review.comment?.toLowerCase().includes(searchLower) ||
        review.product?.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply status filter
    if (params?.status && params.status !== 'all') {
      reviews = reviews.filter((review: any) => review.status === params.status);
    }
    
    // Apply rating filter
    if (params?.rating) {
      reviews = reviews.filter((review: any) => review.rating === params.rating);
    }
    
    // Apply sorting
    if (params?.sortBy) {
      reviews.sort((a: any, b: any) => {
        const aValue = a[params.sortBy as keyof typeof a];
        const bValue = b[params.sortBy as keyof typeof b];
        
        if (params.sortOrder === 'desc') {
          return aValue > bValue ? -1 : 1;
        }
        return aValue < bValue ? -1 : 1;
      });
    }
    
    // Apply pagination
    const page = params?.page || 1;
    const limit = params?.limit || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedReviews = reviews.slice(startIndex, endIndex);
    
    return {
      data: paginatedReviews,
      meta: {
        total: reviews.length,
        page,
        limit,
        totalPages: Math.ceil(reviews.length / limit)
      }
    };
  } catch (error) {
    console.error("Error fetching reviews:", error);
    throw error;
  }
};

// Fetch orders with sorting, filtering, and pagination
// Fetch users with sorting, filtering, and pagination
export const fetchUsers = async (params?: {
  search?: string;
  role?: string;
  status?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}) => {
  try {
    // Fetch users from the API
    let users = await apiRequest("GET", "/api/users").then(res => res.json());
    
    // Get orders to calculate ordersCount for each user
    const orders = await apiRequest("GET", "/api/orders").then(res => res.json());
    
    // Calculate real order statistics by user
    const userOrderStats: Record<number, { count: number, totalSpent: number, lastOrderDate: Date | null }> = {};
    
    // Process all orders to create user stats
    orders.forEach((order: any) => {
      const userId = order.userId;
      
      if (userId) {
        if (!userOrderStats[userId]) {
          userOrderStats[userId] = {
            count: 0,
            totalSpent: 0,
            lastOrderDate: null
          };
        }
        
        // Increment order count
        userOrderStats[userId].count += 1;
        
        // Add to total spent (convert from string if needed)
        const amount = typeof order.totalAmount === 'string' 
          ? parseFloat(order.totalAmount.replace(/[^0-9.-]+/g, ''))
          : parseFloat(order.totalAmount);
          
        if (!isNaN(amount)) {
          userOrderStats[userId].totalSpent += amount;
        }
        
        // Track most recent order
        const orderDate = order.createdAt ? new Date(order.createdAt) : null;
        if (orderDate && (!userOrderStats[userId].lastOrderDate || 
            orderDate > userOrderStats[userId].lastOrderDate)) {
          userOrderStats[userId].lastOrderDate = orderDate;
        }
      }
    });
    
    // Calculate the number of new users in the last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const newUsersCount = users.filter((user: any) => {
      const createdDate = user.createdAt ? new Date(user.createdAt) : null;
      return createdDate && createdDate >= thirtyDaysAgo;
    }).length;
    
    // Process and format users data with real order information
    users = users.map((user: any) => {
      // Get order stats for this user
      const stats = userOrderStats[user.id] || { count: 0, totalSpent: 0, lastOrderDate: null };
      
      // Format user data
      return {
        ...user,
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username,
        role: user.role || 'customer',
        location: [user.city, user.state].filter(Boolean).join(', ') || (user.address ? 'Address set' : 'No location'),
        phone: user.phone,
        // Format dates
        createdAt: user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'Unknown',
        lastLogin: user.updatedAt ? new Date(user.updatedAt).toLocaleDateString() : 'Never',
        lastOrder: stats.lastOrderDate ? stats.lastOrderDate.toLocaleDateString() : 'Never',
        // Derive status - use real active status if available
        status: user.role === 'admin' ? 'active' : (user.status || (user.createdAt ? 'active' : 'pending')),
        // Real order metrics
        ordersCount: stats.count,
        totalSpent: stats.totalSpent > 0 ? `$${stats.totalSpent.toFixed(2)}` : '$0.00'
      };
    });
    
    // Apply search filter
    if (params?.search) {
      const searchLower = params.search.toLowerCase();
      users = users.filter((user: any) => 
        user.username.toLowerCase().includes(searchLower) || 
        user.email.toLowerCase().includes(searchLower) ||
        user.fullName.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply role filter
    if (params?.role && params.role !== 'all') {
      users = users.filter((user: any) => user.role === params.role);
    }
    
    // Apply status filter
    if (params?.status && params.status !== 'all') {
      users = users.filter((user: any) => user.status === params.status);
    }
    
    // Apply sorting
    if (params?.sortBy) {
      users.sort((a: any, b: any) => {
        let aValue = a[params.sortBy as keyof typeof a];
        let bValue = b[params.sortBy as keyof typeof b];
        
        // Handle dates
        if (params.sortBy === 'createdAt' || params.sortBy === 'lastLogin' || params.sortBy === 'lastOrder') {
          aValue = aValue !== 'Never' && aValue !== 'Unknown' ? new Date(aValue).getTime() : 0;
          bValue = bValue !== 'Never' && bValue !== 'Unknown' ? new Date(bValue).getTime() : 0;
        }
        
        // Handle numeric fields
        if (params.sortBy === 'ordersCount') {
          aValue = parseInt(aValue) || 0;
          bValue = parseInt(bValue) || 0;
        }
        
        // Handle monetary values
        if (params.sortBy === 'totalSpent') {
          aValue = parseFloat(aValue.replace(/[^0-9.-]+/g, '')) || 0;
          bValue = parseFloat(bValue.replace(/[^0-9.-]+/g, '')) || 0;
        }
        
        if (params.sortOrder === 'desc') {
          return aValue > bValue ? -1 : 1;
        }
        return aValue < bValue ? -1 : 1;
      });
    } else {
      // Default sort by date (newest first)
      users.sort((a: any, b: any) => {
        const aTime = a.createdAt !== 'Unknown' ? new Date(a.createdAt).getTime() : 0;
        const bTime = b.createdAt !== 'Unknown' ? new Date(b.createdAt).getTime() : 0;
        return bTime - aTime;
      });
    }
    
    // Apply pagination
    const page = params?.page || 1;
    const limit = params?.limit || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedUsers = users.slice(startIndex, endIndex);
    
    return {
      data: paginatedUsers,
      meta: {
        total: users.length,
        page,
        limit,
        totalPages: Math.ceil(users.length / limit),
        // Include additional overall statistics
        newUsersCount
      }
    };
  } catch (error) {
    console.error("Error fetching users:", error);
    throw error;
  }
};

// User management functions
export const suspendUser = async (userId: number): Promise<{ success: boolean; message: string }> => {
  try {
    const response = await apiRequest("PUT", `/api/admin/users/${userId}/suspend`);
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to suspend user account");
    }
    
    const data = await response.json();
    return { 
      success: true, 
      message: data.message || "User account suspended successfully" 
    };
  } catch (error: any) {
    console.error("Error suspending user:", error);
    return { 
      success: false, 
      message: error.message || "An error occurred while suspending the user account" 
    };
  }
};

export const activateUser = async (userId: number): Promise<{ success: boolean; message: string }> => {
  try {
    const response = await apiRequest("PUT", `/api/admin/users/${userId}/activate`);
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to activate user account");
    }
    
    const data = await response.json();
    return { 
      success: true, 
      message: data.message || "User account activated successfully" 
    };
  } catch (error: any) {
    console.error("Error activating user:", error);
    return { 
      success: false, 
      message: error.message || "An error occurred while activating the user account" 
    };
  }
};

export const deleteUser = async (userId: number): Promise<{ success: boolean; message: string }> => {
  try {
    const response = await apiRequest("DELETE", `/api/admin/users/${userId}`);
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to delete user account");
    }
    
    const data = await response.json();
    return { 
      success: true, 
      message: data.message || "User account deleted successfully" 
    };
  } catch (error: any) {
    console.error("Error deleting user:", error);
    return { 
      success: false, 
      message: error.message || "An error occurred while deleting the user account" 
    };
  }
};

export const fetchOrders = async (params?: {
  search?: string;
  status?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}) => {
  try {
    // Get orders from the API
    let orders = await apiRequest("GET", "/api/orders").then(res => res.json());
    
    // Add user information by fetching users as well
    const users = await apiRequest("GET", "/api/users").then(res => res.json());
    
    // Apply search filter
    if (params?.search) {
      const searchLower = params.search.toLowerCase();
      orders = orders.filter((order: any) => 
        order.customerName?.toLowerCase().includes(searchLower) || 
        order.customerEmail?.toLowerCase().includes(searchLower) ||
        order.id.toString().includes(searchLower)
      );
    }
    
    // Apply status filter
    if (params?.status && params.status !== 'all') {
      orders = orders.filter((order: any) => order.status === params.status);
    }
    
    // Apply date range filter
    if (params?.dateFrom) {
      const fromDate = new Date(params.dateFrom);
      orders = orders.filter((order: any) => new Date(order.createdAt) >= fromDate);
    }
    
    if (params?.dateTo) {
      const toDate = new Date(params.dateTo);
      toDate.setHours(23, 59, 59, 999); // End of the day
      orders = orders.filter((order: any) => new Date(order.createdAt) <= toDate);
    }
    
    // Apply sorting
    if (params?.sortBy) {
      orders.sort((a: any, b: any) => {
        let aValue = a[params.sortBy as keyof typeof a];
        let bValue = b[params.sortBy as keyof typeof b];
        
        // Handle dates
        if (params.sortBy === 'createdAt') {
          aValue = new Date(aValue).getTime();
          bValue = new Date(bValue).getTime();
        }
        
        // Handle amount as a special case
        if (params.sortBy === 'totalAmount') {
          aValue = parseFloat(aValue.toString().replace(/[^0-9.-]+/g, ''));
          bValue = parseFloat(bValue.toString().replace(/[^0-9.-]+/g, ''));
        }
        
        if (params.sortOrder === 'desc') {
          return aValue > bValue ? -1 : 1;
        }
        return aValue < bValue ? -1 : 1;
      });
    } else {
      // Default sort by date (newest first)
      orders.sort((a: any, b: any) => 
        new Date(b.createdAt || Date.now()).getTime() - new Date(a.createdAt || Date.now()).getTime()
      );
    }
    
    // Map orders to the expected format for the AdminOrdersPage
    orders = orders.map((order: any) => {
      // Find associated user if userId exists
      let customerName = order.customerName || 'Guest Customer';
      if (order.userId) {
        const user = users.find((u: any) => u.id === order.userId);
        if (user) {
          customerName = `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username;
        }
      }
      
      return {
        id: order.id,
        date: order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Unknown',
        customerName: customerName,
        amount: typeof order.totalAmount === 'string' ? order.totalAmount : `$${order.totalAmount}`,
        status: order.status || 'pending',
        // Count items if they exist, otherwise use 0 or estimate from amount
        items: 1, // Default to 1 if no items data available
        paymentMethod: order.paymentMethod || 'Credit Card'
      };
    });
    
    // Apply pagination
    const page = params?.page || 1;
    const limit = params?.limit || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedOrders = orders.slice(startIndex, endIndex);
    
    return {
      data: paginatedOrders,
      meta: {
        total: orders.length,
        page,
        limit,
        totalPages: Math.ceil(orders.length / limit)
      }
    };
  } catch (error) {
    console.error("Error fetching orders:", error);
    throw error;
  }
};
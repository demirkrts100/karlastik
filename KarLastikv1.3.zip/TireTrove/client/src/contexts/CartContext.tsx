import { createContext, useState, useEffect, ReactNode } from 'react';
import { apiRequest, queryClient } from '@/lib/queryClient';

// Define the context type with enhanced cart item structure
interface CartItem {
  id: number;
  tireId?: number;
  quantity: number;
}

interface CartContextType {
  cart: CartItem[];
  addItem: (tireId: number, quantity: number) => Promise<void>;
  updateQuantity: (id: number, quantity: number) => Promise<void>;
  removeItem: (id: number) => Promise<void>;
  clearCart: () => Promise<void>;
  isCartLoading: boolean;
  openCart: () => void;
  addToCart: (item: { tireId: number, quantity: number }) => Promise<void>;
  isAddingToCart: boolean;
}

// Create the context with default values
const CartContext = createContext<CartContextType>({
  cart: [],
  addItem: async () => {},
  updateQuantity: async () => {},
  removeItem: async () => {},
  clearCart: async () => {},
  isCartLoading: false,
  openCart: () => {},
  addToCart: async () => {},
  isAddingToCart: false,
});

interface CartProviderProps {
  children: ReactNode;
}

const CartProvider = ({ children }: CartProviderProps) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartLoading, setIsCartLoading] = useState(true);
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  
  // Initialize cart
  useEffect(() => {
    const fetchCart = async () => {
      try {
        const response = await fetch('/api/cart');
        if (!response.ok) throw new Error('Failed to fetch cart');
        
        const cartItems = await response.json();
        setCart(cartItems.map((item: any) => ({ 
          id: item.id, 
          tireId: item.tireId, 
          quantity: item.quantity 
        })));
      } catch (error) {
        console.error('Error fetching cart:', error);
      } finally {
        setIsCartLoading(false);
      }
    };
    
    fetchCart();
  }, []);
  
  // Function to open the cart
  const openCart = () => {
    const event = new CustomEvent('toggleCart');
    window.dispatchEvent(event);
  };

  // Add item to cart (optimized with optimistic updates)
  const addItem = async (tireId: number, quantity: number) => {
    // Create a temporary ID for the optimistic update
    const tempId = Date.now();
    
    // Check if item already exists in cart
    const existingItemIndex = cart.findIndex(item => 
      // Check item.id against tempId or look in the original array
      item.id !== tempId && 
      // Need to get the tireId from the API, this is just the cart item ID
      // In a real implementation you'd need to track tireId in the local cart state
      item.tireId === tireId
    );
    
    try {
      // Optimistically update the UI first for a snappier experience
      if (existingItemIndex >= 0) {
        // If item exists, update its quantity optimistically
        setCart(prev => 
          prev.map((item, index) => 
            index === existingItemIndex
              ? { ...item, quantity: item.quantity + quantity }
              : item
          )
        );
      } else {
        // Add new item optimistically with a temporary ID
        setCart(prev => [...prev, { id: tempId, tireId, quantity }]);
      }
      
      // Make the API request in the background
      const response = await apiRequest('POST', '/api/cart/add', {
        tireId,
        quantity
      });
      
      if (!response.ok) throw new Error('Failed to add item to cart');
      
      // Get the actual data from the server
      const newItem = await response.json();
      
      // Update the cart with the server response (fixing any discrepancies)
      setCart(prev => {
        if (existingItemIndex >= 0) {
          // Replace the existing item with server data
          return prev.map((item, index) => 
            index === existingItemIndex 
              ? { id: newItem.id, tireId, quantity: newItem.quantity }
              : item
          );
        } else {
          // Replace our temporary item with the real one from server
          return prev.map(item => 
            item.id === tempId
              ? { id: newItem.id, tireId, quantity: newItem.quantity }
              : item
          );
        }
      });
      
      // Quietly refresh the data in the background
      // Use lower priority to not block UI
      queryClient.invalidateQueries({ 
        queryKey: ['/api/cart'],
        type: 'all',
        exact: false 
      });
      
      // Show cart
      openCart();
    } catch (error) {
      console.error('Error adding item to cart:', error);
      
      // Revert the optimistic update on error
      if (existingItemIndex >= 0) {
        // Revert quantity change
        setCart(prev => 
          prev.map((item, index) => 
            index === existingItemIndex
              ? { ...item, quantity: item.quantity - quantity }
              : item
          )
        );
      } else {
        // Remove the temporary item
        setCart(prev => prev.filter(item => item.id !== tempId));
      }
      
      throw error;
    }
  };
  
  // Update item quantity
  const updateQuantity = async (id: number, quantity: number) => {
    try {
      setIsCartLoading(true);
      
      const response = await apiRequest('PUT', `/api/cart/${id}`, { quantity });
      
      if (!response.ok) throw new Error('Failed to update cart item');
      
      const updatedItem = await response.json();
      
      setCart(prev => 
        prev.map(item => 
          item.id === id ? { ...item, quantity: updatedItem.quantity } : item
        )
      );
      
      // Invalidate the cart query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      
    } catch (error) {
      console.error('Error updating cart item:', error);
      throw error;
    } finally {
      setIsCartLoading(false);
    }
  };
  
  // Remove item from cart
  const removeItem = async (id: number) => {
    try {
      setIsCartLoading(true);
      
      const response = await apiRequest('DELETE', `/api/cart/${id}`);
      
      if (!response.ok) throw new Error('Failed to remove cart item');
      
      setCart(prev => prev.filter(item => item.id !== id));
      
      // Invalidate the cart query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      
    } catch (error) {
      console.error('Error removing cart item:', error);
      throw error;
    } finally {
      setIsCartLoading(false);
    }
  };
  
  // Clear cart
  const clearCart = async () => {
    try {
      setIsCartLoading(true);
      
      const response = await apiRequest('DELETE', '/api/cart');
      
      if (!response.ok) throw new Error('Failed to clear cart');
      
      setCart([]);
      
      // Invalidate the cart query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      
    } catch (error) {
      console.error('Error clearing cart:', error);
      throw error;
    } finally {
      setIsCartLoading(false);
    }
  };
  
  // Add to cart - simplified interface for external components
  const addToCart = async (item: { tireId: number, quantity: number }) => {
    setIsAddingToCart(true);
    try {
      await addItem(item.tireId, item.quantity);
    } catch (error) {
      console.error('Error adding item to cart:', error);
      throw error;
    } finally {
      setIsAddingToCart(false);
    }
  };
  
  return (
    <CartContext.Provider
      value={{
        cart,
        addItem,
        updateQuantity,
        removeItem,
        clearCart,
        isCartLoading,
        openCart,
        addToCart,
        isAddingToCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export { CartContext, CartProvider };

import { useEffect, useState } from 'react';
import { useAuth } from '@/components/auth/AuthProvider';
import { Loader2, Package, Search, X } from 'lucide-react';
import { useOrders } from '@/hooks/useOrders';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const OrdersTab = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  
  // Fetch user orders using our custom hook
  const { orders, isLoading } = useOrders();
  
  // Filter orders based on search query
  const filteredOrders = orders.filter((order: any) => {
    if (!searchQuery) return true;
    
    const lowercaseQuery = searchQuery.toLowerCase();
    return (
      order.id.toString().includes(lowercaseQuery) ||
      order.status.toLowerCase().includes(lowercaseQuery) ||
      order.totalAmount.toString().includes(lowercaseQuery) ||
      (order.createdAt && new Date(order.createdAt).toLocaleDateString().includes(lowercaseQuery))
    );
  });
  
  // Format date helper
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };
  
  // Get status color based on order status
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'shipped':
        return 'bg-purple-100 text-purple-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!orders.length) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Package className="h-12 w-12 text-neutral-300 mb-4" />
        <h3 className="text-xl font-medium mb-2">No Orders Yet</h3>
        <p className="text-neutral-500 mb-6 max-w-md">
          You haven't placed any orders yet. Browse our tire collection and place your first order!
        </p>
        <Button onClick={() => window.location.href = '/'}>
          Shop Now
        </Button>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <h2 className="text-2xl font-bold">Your Orders</h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
          <Input
            placeholder="Search orders..."
            className="pl-10 w-full sm:w-[300px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <X
              className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500 cursor-pointer hover:text-neutral-800"
              onClick={() => setSearchQuery('')}
            />
          )}
        </div>
      </div>
      
      <Card>
        <CardContent className="p-0 overflow-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.map((order: any) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">
                  <span className="bg-primary/10 text-primary px-2 py-1 rounded font-mono">
                    TH-{order.id.toString().padStart(5, '0')}
                  </span>
                </TableCell>
                  <TableCell>{formatDate(order.createdAt)}</TableCell>
                  <TableCell>${parseFloat(order.totalAmount).toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge className={`${getStatusColor(order.status)}`}>
                      {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedOrder(order)}
                    >
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle>
                Order <span className="bg-primary/10 text-primary px-2 py-1 rounded font-mono">TH-{selectedOrder.id.toString().padStart(5, '0')}</span>
              </DialogTitle>
              <DialogDescription>
                Placed on {formatDate(selectedOrder.createdAt)}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6 py-4">
              {/* Order Status */}
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Status</h3>
                <Badge className={`${getStatusColor(selectedOrder.status)}`}>
                  {selectedOrder.status}
                </Badge>
              </div>
              
              {/* Customer Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium mb-2">Shipping Information</h3>
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <p className="font-medium">{selectedOrder.customerName}</p>
                    <p>{selectedOrder.shippingAddress}</p>
                    <p>{selectedOrder.customerEmail}</p>
                  </div>
                </div>
                <div>
                  <h3 className="font-medium mb-2">Payment Information</h3>
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <p>Payment Intent: {selectedOrder.paymentIntentId.substring(0, 20)}...</p>
                    <p>Total Amount: ${parseFloat(selectedOrder.totalAmount).toFixed(2)}</p>
                  </div>
                </div>
              </div>
              
              {/* Order Items */}
              {selectedOrder.items && selectedOrder.items.length > 0 ? (
                <div>
                  <h3 className="font-medium mb-2">Order Items</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead className="text-right">Price</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedOrder.items.map((item: any) => (
                        <TableRow key={item.id}>
                          <TableCell>
                            <div className="flex items-center">
                              {item.imageUrl && (
                                <img 
                                  src={item.imageUrl} 
                                  alt={item.name} 
                                  className="w-12 h-12 object-cover mr-3 rounded"
                                />
                              )}
                              <div>
                                <p className="font-medium">{item.name}</p>
                                <p className="text-sm text-neutral-500">{item.size} • {item.type}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell className="text-right">${parseFloat(item.price).toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="bg-neutral-50 p-4 rounded-lg text-neutral-500 text-center">
                  No detailed item information available for this order.
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedOrder(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default OrdersTab;
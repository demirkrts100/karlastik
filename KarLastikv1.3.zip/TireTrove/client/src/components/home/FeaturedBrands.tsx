import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { Skeleton } from '@/components/ui/skeleton';
import { Brand } from '@shared/schema';

const FeaturedBrands = () => {
  // Fetch featured brands
  const { data: brands, isLoading, error } = useQuery<Brand[]>({
    queryKey: ['/api/brands/featured'],
  });
  
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">Shop Top Tire Brands</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div key={item} className="flex flex-col items-center">
                <Skeleton className="h-32 w-full rounded-lg" />
                <Skeleton className="h-4 w-20 mt-2" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center p-8">
            <p className="text-red-500">Error loading brands. Please try again later.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {brands?.map((brand) => (
              <Link key={brand.id} href={`/products?brand=${brand.name}`} className="group">
                <div className="bg-neutral-100 rounded-lg p-6 flex items-center justify-center h-32 hover:shadow-md transition-shadow">
                  <img src={brand.logoUrl} alt={brand.name} className="max-h-16 max-w-full" />
                </div>
                <p className="text-center mt-2 font-medium text-neutral-700 group-hover:text-primary">{brand.name}</p>
              </Link>
            ))}
          </div>
        )}
        
        <div className="mt-10 text-center">
          <Button asChild variant="outline" className="inline-block bg-white border border-primary text-primary hover:bg-primary hover:text-white font-medium py-2 px-6 rounded-lg">
            <Link href="/products">View All Brands</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedBrands;

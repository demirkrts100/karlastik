import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Service } from '@shared/schema';

const InstallationServices = () => {
  const [zipCode, setZipCode] = useState('');
  const { toast } = useToast();
  
  // Fetch installation services
  const { data: services, isLoading, error } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });
  
  const handleFindLocations = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!zipCode || zipCode.length < 5) {
      toast({
        title: "Invalid Zip Code",
        description: "Please enter a valid zip code",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Location Search",
      description: `Found 5 installation locations near ${zipCode}`,
    });
  };
  
  return (
    <section className="py-12 bg-neutral-100">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-4">Professional Installation Services</h2>
        <p className="text-neutral-600 text-center max-w-2xl mx-auto mb-10">Get your tires professionally installed at one of our certified partner locations nationwide.</p>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item) => (
              <Card key={item} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-1/2 mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-24" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <div className="text-center p-8">
            <p className="text-red-500">Error loading services. Please try again later.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services?.map((service) => (
              <Card key={service.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                <img src={service.imageUrl} alt={service.name} className="w-full h-48 object-cover" />
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg mb-2">{service.name}</h3>
                  <p className="text-neutral-600 text-sm mb-2">{service.description}</p>
                  <span className="text-primary font-medium">From ${service.price} per tire</span>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        
        <div className="mt-10 bg-white rounded-lg shadow-sm p-6">
          <h3 className="font-bold text-xl mb-4 text-center">Find Installation Services Near You</h3>
          <form onSubmit={handleFindLocations} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row">
              <Input
                type="text"
                placeholder="Enter your zip code"
                className="w-full sm:flex-1 p-3 sm:rounded-r-none mb-2 sm:mb-0"
                value={zipCode}
                onChange={(e) => setZipCode(e.target.value)}
              />
              <Button 
                type="submit"
                className="bg-primary hover:bg-primary/90 text-white font-medium py-3 px-6 sm:rounded-l-none"
              >
                Find Locations
              </Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default InstallationServices;

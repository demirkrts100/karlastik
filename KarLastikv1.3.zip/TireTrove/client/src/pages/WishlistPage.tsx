import { useWishlist } from '@/hooks/useWishlist';
import { useAuth } from '@/components/auth/AuthProvider';
import { Redirect } from 'wouter';
import { Helmet } from 'react-helmet-async';
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Trash, 
  Loader2, 
  ShoppingCart, 
  HeartOff, 
  Heart 
} from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { formatPrice } from '@/lib/utils';

export default function WishlistPage() {
  const { user, isLoading: isLoadingAuth } = useAuth();
  const { 
    wishlistItems, 
    isLoading, 
    removeFromWishlist, 
    clearWishlist,
    isClearingWishlist
  } = useWishlist();
  const { addToCart, isAddingToCart } = useCart();

  // Redirect to auth page if not logged in
  if (!isLoadingAuth && !user) {
    return <Redirect to="/auth" />;
  }

  const handleAddToCart = (tireId: number) => {
    addToCart({ tireId, quantity: 1 });
  };

  const handleRemoveFromWishlist = (wishlistItemId: number) => {
    removeFromWishlist(wishlistItemId);
  };

  const handleClearWishlist = () => {
    clearWishlist();
  };

  return (
    <div className="container mx-auto py-8 px-4 md:px-6 min-h-[calc(100vh-4rem)]">
      <Helmet>
        <title>My Wishlist - TireHub</title>
        <meta name="description" content="View and manage your saved tire products in your wishlist" />
      </Helmet>

      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center gap-2">
          <Heart className="h-6 w-6" />
          My Wishlist
        </h1>
        
        {wishlistItems.length > 0 && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <Trash className="h-4 w-4" />
                Clear Wishlist
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Clear your wishlist?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently remove all items from your wishlist.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleClearWishlist}
                  disabled={isClearingWishlist}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  {isClearingWishlist && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Clear
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center min-h-[300px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : wishlistItems.length === 0 ? (
        <div className="text-center py-16 space-y-4">
          <HeartOff className="mx-auto h-16 w-16 text-muted-foreground" />
          <h2 className="text-2xl font-semibold">Your wishlist is empty</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            When you find products you like, save them to your wishlist for future reference.
          </p>
          <Button asChild className="mt-4">
            <a href="/">Browse Tires</a>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {wishlistItems.map((item) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="overflow-hidden h-full flex flex-col">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{item.tire.name}</CardTitle>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive"
                      onClick={() => handleRemoveFromWishlist(item.id)}
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>

                <CardContent className="pb-0 flex-grow flex flex-col">
                  <div className="aspect-video relative mb-4">
                    <img
                      src={item.tire.imageUrl}
                      alt={item.tire.name}
                      className="object-cover rounded-md w-full h-full"
                    />
                    <Badge className="absolute top-2 right-2">
                      {item.tire.type}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between mb-2">
                    <div className="font-semibold">{item.tire.brand}</div>
                    <div className="text-primary font-bold">
                      {item.tire.discountedPrice ? (
                        <div className="flex flex-col items-end">
                          <span className="text-muted-foreground line-through text-sm">
                            {formatPrice(item.tire.price)}
                          </span>
                          <span className="text-primary">
                            {formatPrice(item.tire.discountedPrice)}
                          </span>
                        </div>
                      ) : (
                        formatPrice(item.tire.price)
                      )}
                    </div>
                  </div>
                  
                  <div className="text-sm text-muted-foreground mb-4">
                    {item.tire.description.substring(0, 100)}
                    {item.tire.description.length > 100 ? "..." : ""}
                  </div>
                  
                  <div className="text-sm mb-2">
                    <span className="font-medium">Size:</span> {item.tire.size}
                  </div>
                </CardContent>

                <CardFooter className="pt-4">
                  <Button 
                    className="w-full" 
                    onClick={() => handleAddToCart(item.tire.id)}
                    disabled={isAddingToCart}
                  >
                    {isAddingToCart && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Add to Cart
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
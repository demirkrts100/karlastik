import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, StarHalf } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { WishlistButton } from '@/components/wishlist/WishlistButton';
import { Tire } from '@shared/schema';

interface ProductCardProps {
  tire: Tire;
  showActions?: boolean;
}

const ProductCard = ({ tire, showActions = true }: ProductCardProps) => {
  const { addItem } = useCart();
  
  // Function to render star ratings
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-accent fill-accent" size={14} />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-accent fill-accent" size={14} />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-accent" size={14} />);
    }
    
    return stars;
  };
  
  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Use a more optimistic UI update approach
    try {
      // Show immediate feedback
      const button = e.currentTarget as HTMLButtonElement;
      const originalText = button.innerHTML;
      button.innerHTML = '<svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';
      
      // Add to cart in the background
      await addItem(tire.id, 1);
      
      // Restore the button after a minimum time for better UX
      setTimeout(() => {
        button.innerHTML = originalText;
      }, 300);
    } catch (error) {
      console.error('Failed to add to cart:', error);
    }
  };
  
  // We don't need toggleWishlist function anymore as we're using the WishlistButton component
  
  return (
    <Card className="bg-white rounded-lg shadow-sm overflow-hidden group hover:shadow-md transition-shadow w-full h-full flex flex-col">
      <div className="relative">
        <img 
          src={tire.imageUrl} 
          alt={tire.name} 
          className="w-full h-40 object-contain p-2"
        />
        {tire.hasPromo && (
          <div className="absolute top-0 left-0 bg-accent text-white px-2 py-1 text-xs font-medium">
            {tire.promoText || 'SAVE'}
          </div>
        )}
        {tire.isBestSeller && !tire.hasPromo && (
          <div className="absolute top-0 left-0 bg-accent text-white px-2 py-1 text-xs font-medium">
            BEST SELLER
          </div>
        )}
        {tire.isNewArrival && !tire.hasPromo && !tire.isBestSeller && (
          <div className="absolute top-0 left-0 bg-accent text-white px-2 py-1 text-xs font-medium">
            NEW ARRIVAL
          </div>
        )}
        <div className="absolute top-2 right-2">
          <WishlistButton
            tireId={tire.id}
            size="icon"
            variant="ghost"
            className="bg-white hover:bg-white p-1.5 h-7 w-7 rounded-full"
          />
        </div>
      </div>
      <CardContent className="p-3 flex-grow flex flex-col">
        <div className="mb-1">
          <Link href={`/product/${tire.id}`}>
            <h3 className="font-medium text-sm hover:text-primary cursor-pointer truncate">{tire.name}</h3>
          </Link>
          <div className="flex items-center mt-1">
            <div className="flex">
              {renderStars(Number(tire.rating))}
            </div>
            <span className="text-xs text-neutral-500 ml-1">({tire.reviewCount || 0})</span>
          </div>
        </div>
        <p className="text-neutral-600 text-xs mb-2 line-clamp-2">{tire.description}</p>
        <div className="text-xs text-neutral-500 mb-1">Size: {tire.size}</div>
        <div className="mt-auto">
          <div className="flex justify-between items-end mb-2">
            <div>
              {tire.discountedPrice ? (
                <>
                  <div className="flex flex-col">
                    <span className="text-neutral-500 line-through text-xs">${tire.price}</span>
                    <span className="font-bold text-secondary text-base">${tire.discountedPrice}</span>
                  </div>
                </>
              ) : (
                <span className="font-bold text-base">${tire.price}</span>
              )}
            </div>
            <span className="text-xs text-success font-medium">Free Shipping</span>
          </div>
          
          {showActions && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              <Button 
                className="bg-primary hover:bg-primary/90 text-white text-xs font-medium h-10 sm:h-8 flex items-center justify-center transition-all"
                onClick={handleAddToCart}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                Add to Cart
              </Button>
              <Button asChild variant="outline" className="bg-white border border-primary text-primary hover:bg-primary/5 text-xs font-medium h-10 sm:h-8 flex items-center justify-center transition-all">
                <Link href={`/product/${tire.id}`}>View Details</Link>
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;

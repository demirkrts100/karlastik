import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Package, 
  Search,
  PlusCircle,
  Pencil,
  Trash2,
  Filter,
  ArrowUpDown,
  ChevronDown,
  TagIcon,
  DollarSign,
  Eye,
  BarChart2,
  Truck,
  MoreHorizontal,
  Loader2,
  ImagePlus,
  Save,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { fetchProducts } from "@/services/adminService";

interface AdminProductsPageProps {
  title?: string;
}

interface Product {
  id: number;
  name: string;
  brand: string;
  description?: string;
  type?: string; // category/type
  price: string;
  discountedPrice?: string | null;
  stock?: number;
  isFeatured?: boolean;
  featured?: boolean;
  imageUrl?: string;
  images?: string[] | null;
}

const AdminProductsPage = ({ title = "Products" }: AdminProductsPageProps) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [selectedProducts, setSelectedProducts] = useState<number[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    featured: 0,
    onSale: 0,
    lowStock: 0
  });
  
  // Add/Edit product state
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState({
    name: "",
    brand: "",
    type: "",
    description: "",
    price: "",
    discountedPrice: "",
    stock: "0",
    isFeatured: false,
    imageUrl: ""
  });
  
  // Fetch products data
  useEffect(() => {
    const loadProducts = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        const result = await fetchProducts();
        if (result && result.data) {
          // Transform the product data to match our interface
          const formattedProducts = result.data.map((product: any) => ({
            id: product.id,
            name: product.name,
            brand: product.brand,
            description: product.description,
            type: product.type,
            price: `$${parseFloat(product.price).toFixed(2)}`,
            discountedPrice: product.discountedPrice ? `$${parseFloat(product.discountedPrice).toFixed(2)}` : null,
            stock: product.stock || 0,
            isFeatured: product.isFeatured,
            featured: product.isFeatured,
            imageUrl: product.images && product.images.length > 0 ? product.images[0] : undefined,
            images: product.images
          }));
          
          setProducts(formattedProducts);
          
          // Calculate stats
          setStats({
            total: formattedProducts.length,
            featured: formattedProducts.filter(p => p.isFeatured || p.featured).length,
            onSale: formattedProducts.filter(p => p.discountedPrice).length,
            lowStock: formattedProducts.filter(p => (p.stock || 0) < 10).length
          });
        }
      } catch (err) {
        console.error("Error loading products:", err);
        setError("Failed to load products. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };
    
    loadProducts();
  }, []);
  
  const brands = [...new Set(products.map(product => product.brand))];
  const categories = [...new Set(products.map(product => product.type || 'Unknown'))];
  
  const filteredProducts = products.filter(product => {
    const matchesSearch = 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === "all" || product.type === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(filteredProducts.map(product => product.id));
    }
    setSelectAll(!selectAll);
  };

  const handleSelectProduct = (id: number) => {
    if (selectedProducts.includes(id)) {
      setSelectedProducts(selectedProducts.filter(productId => productId !== id));
    } else {
      setSelectedProducts([...selectedProducts, id]);
    }
  };

  const getStockStatus = (stock: number) => {
    if (stock === 0) {
      return { text: "Out of Stock", color: "bg-red-100 text-red-800 border-red-200" };
    } else if (stock < 10) {
      return { text: "Low Stock", color: "bg-yellow-100 text-yellow-800 border-yellow-200" };
    } else {
      return { text: "In Stock", color: "bg-green-100 text-green-800 border-green-200" };
    }
  };
  
  // Product CRUD functions
  const handleAddProduct = () => {
    setProductForm({
      name: "",
      brand: "",
      type: "",
      description: "",
      price: "",
      discountedPrice: "",
      stock: "0",
      isFeatured: false,
      imageUrl: ""
    });
    setIsAddDialogOpen(true);
  };
  
  const handleEditProduct = (product: Product) => {
    setCurrentProduct(product);
    setProductForm({
      name: product.name,
      brand: product.brand,
      type: product.type || "",
      description: product.description || "",
      price: product.price.replace('$', ''),
      discountedPrice: product.discountedPrice ? product.discountedPrice.replace('$', '') : "",
      stock: (product.stock || 0).toString(),
      isFeatured: product.isFeatured || product.featured || false,
      imageUrl: product.imageUrl || ""
    });
    setIsEditDialogOpen(true);
  };
  
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProductForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleCheckboxChange = (checked: boolean) => {
    setProductForm(prev => ({
      ...prev,
      isFeatured: checked
    }));
  };
  
  const handleSubmitProduct = async (isEdit: boolean = false) => {
    try {
      // Validate form
      if (!productForm.name || !productForm.brand || !productForm.price) {
        toast({
          title: "Missing required fields",
          description: "Please fill in all required fields (name, brand, price).",
          variant: "destructive"
        });
        return;
      }
      
      setIsSubmitting(true);
      
      // Prepare data for API
      const productData = {
        name: productForm.name,
        brand: productForm.brand,
        type: productForm.type,
        description: productForm.description,
        price: parseFloat(productForm.price),
        discountedPrice: productForm.discountedPrice ? parseFloat(productForm.discountedPrice) : null,
        stock: parseInt(productForm.stock),
        isFeatured: productForm.isFeatured,
        images: productForm.imageUrl ? [productForm.imageUrl] : []
      };
      
      let response;
      
      if (isEdit && currentProduct) {
        // Update existing product
        response = await apiRequest("PUT", `/api/tires/${currentProduct.id}`, productData);
      } else {
        // Create new product
        response = await apiRequest("POST", "/api/tires", productData);
      }
      
      if (response.ok) {
        const updatedProduct = await response.json();
        
        toast({
          title: isEdit ? "Product updated" : "Product created",
          description: `${productForm.name} has been ${isEdit ? "updated" : "created"} successfully.`
        });
        
        // Update the products list
        if (isEdit && currentProduct) {
          setProducts(prevProducts => 
            prevProducts.map(p => 
              p.id === currentProduct.id 
                ? {
                    ...p,
                    name: productForm.name,
                    brand: productForm.brand,
                    type: productForm.type,
                    description: productForm.description,
                    price: `$${parseFloat(productForm.price).toFixed(2)}`,
                    discountedPrice: productForm.discountedPrice 
                      ? `$${parseFloat(productForm.discountedPrice).toFixed(2)}` 
                      : null,
                    stock: parseInt(productForm.stock),
                    isFeatured: productForm.isFeatured,
                    featured: productForm.isFeatured,
                    imageUrl: productForm.imageUrl
                  }
                : p
            )
          );
        } else {
          // Add the new product to the list
          const newProduct = {
            ...updatedProduct,
            price: `$${parseFloat(productForm.price).toFixed(2)}`,
            discountedPrice: productForm.discountedPrice 
              ? `$${parseFloat(productForm.discountedPrice).toFixed(2)}` 
              : null,
            isFeatured: productForm.isFeatured,
            featured: productForm.isFeatured,
            imageUrl: productForm.imageUrl
          };
          
          setProducts(prevProducts => [...prevProducts, newProduct]);
          
          // Update stats
          setStats(prev => ({
            ...prev,
            total: prev.total + 1,
            featured: productForm.isFeatured ? prev.featured + 1 : prev.featured,
            onSale: productForm.discountedPrice ? prev.onSale + 1 : prev.onSale,
            lowStock: parseInt(productForm.stock) < 10 ? prev.lowStock + 1 : prev.lowStock
          }));
        }
        
        // Close the dialog
        isEdit ? setIsEditDialogOpen(false) : setIsAddDialogOpen(false);
      } else {
        const error = await response.json();
        throw new Error(error.message || "Something went wrong");
      }
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message || "An error occurred. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDeleteProduct = async (productId: number) => {
    if (!confirm("Are you sure you want to delete this product? This action cannot be undone.")) {
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      const response = await apiRequest("DELETE", `/api/tires/${productId}`);
      
      if (response.ok) {
        toast({
          title: "Product deleted",
          description: "The product has been successfully deleted."
        });
        
        // Remove the product from the list
        setProducts(prevProducts => prevProducts.filter(p => p.id !== productId));
        
        // Update selected products
        setSelectedProducts(prev => prev.filter(id => id !== productId));
        
        // Update stats
        const deletedProduct = products.find(p => p.id === productId);
        if (deletedProduct) {
          setStats(prev => ({
            ...prev,
            total: prev.total - 1,
            featured: (deletedProduct.isFeatured || deletedProduct.featured) ? prev.featured - 1 : prev.featured,
            onSale: deletedProduct.discountedPrice ? prev.onSale - 1 : prev.onSale,
            lowStock: (deletedProduct.stock || 0) < 10 ? prev.lowStock - 1 : prev.lowStock
          }));
        }
      } else {
        const error = await response.json();
        throw new Error(error.message || "Failed to delete product");
      }
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message || "Failed to delete product. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleBulkDelete = async () => {
    if (!confirm(`Are you sure you want to delete ${selectedProducts.length} products? This action cannot be undone.`)) {
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // In a real app, you might have a bulk delete endpoint
      // For now, we'll delete one by one
      const promises = selectedProducts.map(id => 
        apiRequest("DELETE", `/api/tires/${id}`)
      );
      
      await Promise.all(promises);
      
      toast({
        title: "Products deleted",
        description: `Successfully deleted ${selectedProducts.length} products.`
      });
      
      // Remove the products from the list
      setProducts(prevProducts => 
        prevProducts.filter(p => !selectedProducts.includes(p.id))
      );
      
      // Update stats (recalculate from remaining products)
      const remainingProducts = products.filter(p => !selectedProducts.includes(p.id));
      setStats({
        total: remainingProducts.length,
        featured: remainingProducts.filter(p => p.isFeatured || p.featured).length,
        onSale: remainingProducts.filter(p => p.discountedPrice).length,
        lowStock: remainingProducts.filter(p => (p.stock || 0) < 10).length
      });
      
      // Clear selected products
      setSelectedProducts([]);
      setSelectAll(false);
    } catch (err: any) {
      toast({
        title: "Error",
        description: "Failed to delete some products. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleBulkFeaturedUpdate = async (setFeatured: boolean) => {
    try {
      setIsSubmitting(true);
      
      // In a real app, you might have a bulk update endpoint
      // For now, we'll update one by one
      const promises = selectedProducts.map(id => 
        apiRequest("PUT", `/api/tires/${id}`, { isFeatured: setFeatured })
      );
      
      await Promise.all(promises);
      
      toast({
        title: "Products updated",
        description: `Successfully ${setFeatured ? 'featured' : 'unfeatured'} ${selectedProducts.length} products.`
      });
      
      // Update the products list
      setProducts(prevProducts => 
        prevProducts.map(p => 
          selectedProducts.includes(p.id) 
            ? { ...p, isFeatured: setFeatured, featured: setFeatured }
            : p
        )
      );
      
      // Update featured stat
      const beforeCount = products.filter(p => 
        (p.isFeatured || p.featured) && selectedProducts.includes(p.id)
      ).length;
      
      const change = setFeatured 
        ? selectedProducts.length - beforeCount  // Adding featured status
        : -beforeCount;                         // Removing featured status
      
      setStats(prev => ({
        ...prev,
        featured: prev.featured + change
      }));
      
      // Clear selected products
      setSelectedProducts([]);
      setSelectAll(false);
    } catch (err: any) {
      toast({
        title: "Error",
        description: "Failed to update some products. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>{title} | TireHub Admin</title>
        <meta name="description" content={`TireHub admin ${title.toLowerCase()} management interface.`} />
      </Helmet>
      <AdminLayout title={title}>
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-neutral-800">{title}</h1>
          <p className="text-neutral-600">Manage your product inventory</p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md flex items-center text-red-700">
            <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Actions Row */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <Input 
              placeholder="Search products..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="w-full sm:w-48">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" size="icon" className="w-10 h-10 shrink-0">
            <Filter className="h-4 w-4" />
            <span className="sr-only">More filters</span>
          </Button>
          <Button className="shrink-0" onClick={handleAddProduct}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Product
          </Button>
        </div>

        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Total Products</p>
                {isLoading ? (
                  <Skeleton className="h-6 w-12 mt-1" />
                ) : (
                  <p className="text-xl font-bold">{stats.total}</p>
                )}
              </div>
              <Package className="h-5 w-5 text-neutral-400" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Featured</p>
                {isLoading ? (
                  <Skeleton className="h-6 w-12 mt-1" />
                ) : (
                  <p className="text-xl font-bold">{stats.featured}</p>
                )}
              </div>
              <TagIcon className="h-5 w-5 text-blue-500" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">On Sale</p>
                {isLoading ? (
                  <Skeleton className="h-6 w-12 mt-1" />
                ) : (
                  <p className="text-xl font-bold">{stats.onSale}</p>
                )}
              </div>
              <DollarSign className="h-5 w-5 text-green-500" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-neutral-500">Low/Out of Stock</p>
                {isLoading ? (
                  <Skeleton className="h-6 w-12 mt-1" />
                ) : (
                  <p className="text-xl font-bold">{stats.lowStock}</p>
                )}
              </div>
              <Truck className="h-5 w-5 text-red-500" />
            </CardContent>
          </Card>
        </div>

        {/* Products Table */}
        <Card>
          <CardHeader className="px-6 py-4">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg flex items-center">
                Products
                {isLoading && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              </CardTitle>
              {selectedProducts.length > 0 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      Bulk Actions
                      <ChevronDown className="ml-2 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuLabel>Actions for {selectedProducts.length} items</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => handleBulkFeaturedUpdate(true)}>
                      <TagIcon className="mr-2 h-4 w-4" />
                      <span>Set as Featured</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleBulkFeaturedUpdate(false)}>
                      <TagIcon className="mr-2 h-4 w-4" />
                      <span>Remove Featured</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-red-600" onClick={handleBulkDelete}>
                      <Trash2 className="mr-2 h-4 w-4" />
                      <span>Delete Selected</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <Skeleton className="h-12 w-12 rounded" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-48" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]">
                      <Checkbox
                        checked={selectAll}
                        onCheckedChange={handleSelectAll}
                        aria-label="Select all products"
                        disabled={isSubmitting}
                      />
                    </TableHead>
                    <TableHead className="w-[80px]">Image</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Brand</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-right">Price</TableHead>
                    <TableHead className="text-center">Stock</TableHead>
                    <TableHead className="text-center">Featured</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => {
                    const stockStatus = getStockStatus(product.stock || 0);
                    
                    return (
                      <TableRow key={product.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedProducts.includes(product.id)}
                            onCheckedChange={() => handleSelectProduct(product.id)}
                            aria-label={`Select ${product.name}`}
                            disabled={isSubmitting}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="w-12 h-12 rounded overflow-hidden border bg-neutral-50">
                            {product.imageUrl ? (
                              <img
                                src={product.imageUrl}
                                alt={product.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-neutral-100">
                                <Package className="h-6 w-6 text-neutral-400" />
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell>{product.brand}</TableCell>
                        <TableCell>{product.type || 'Uncategorized'}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex flex-col items-end">
                            {product.discountedPrice && (
                              <span className="text-sm text-gray-500 line-through">{product.price}</span>
                            )}
                            <span className={product.discountedPrice ? "text-red-600 font-medium" : ""}>
                              {product.discountedPrice || product.price}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge variant="outline" className={`${stockStatus.color} flex w-fit mx-auto items-center gap-1`}>
                            {stockStatus.text}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center">
                          {(product.isFeatured || product.featured) ? (
                            <Badge className="bg-blue-100 text-blue-800 border-blue-200">Featured</Badge>
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8" disabled={isSubmitting}>
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                <span>View</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleEditProduct(product)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                <span>Edit</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <BarChart2 className="mr-2 h-4 w-4" />
                                <span>Analytics</span>
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                className="text-red-600"
                                onClick={() => handleDeleteProduct(product.id)}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                <span>Delete</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            ) : (
              <div className="p-8 text-center text-neutral-500">
                No products found matching your criteria.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add Product Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Product</DialogTitle>
              <DialogDescription>
                Add a new tire product to your inventory.
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 gap-4 py-4">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="mb-4">
                  <TabsTrigger value="basic">Basic Information</TabsTrigger>
                  <TabsTrigger value="pricing">Pricing & Inventory</TabsTrigger>
                  <TabsTrigger value="media">Media</TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label htmlFor="name">Product Name*</Label>
                      <Input 
                        id="name"
                        name="name"
                        placeholder="e.g. Michelin Defender T+H" 
                        value={productForm.name}
                        onChange={handleFormChange}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="brand">Brand*</Label>
                        <Input 
                          id="brand"
                          name="brand"
                          placeholder="e.g. Michelin" 
                          value={productForm.brand}
                          onChange={handleFormChange}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="type">Category/Type</Label>
                        <Input 
                          id="type"
                          name="type"
                          placeholder="e.g. All-Season" 
                          value={productForm.type}
                          onChange={handleFormChange}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea 
                        id="description"
                        name="description"
                        placeholder="Enter product description..." 
                        className="min-h-32"
                        value={productForm.description}
                        onChange={handleFormChange}
                      />
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="pricing" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="price">Base Price*</Label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">$</span>
                        <Input 
                          id="price"
                          name="price"
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0.00" 
                          className="pl-7"
                          value={productForm.price}
                          onChange={handleFormChange}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="discountedPrice">Sale Price</Label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">$</span>
                        <Input 
                          id="discountedPrice"
                          name="discountedPrice"
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0.00" 
                          className="pl-7"
                          value={productForm.discountedPrice}
                          onChange={handleFormChange}
                        />
                      </div>
                      <p className="text-xs text-neutral-500 mt-1">Leave empty if not on sale</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="stock">Stock Quantity*</Label>
                      <Input 
                        id="stock"
                        name="stock"
                        type="number"
                        min="0"
                        placeholder="0" 
                        value={productForm.stock}
                        onChange={handleFormChange}
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2 pt-6">
                      <Checkbox 
                        id="isFeatured" 
                        checked={productForm.isFeatured}
                        onCheckedChange={handleCheckboxChange}
                      />
                      <Label htmlFor="isFeatured" className="cursor-pointer">Mark as Featured Product</Label>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="media" className="space-y-4">
                  <div>
                    <Label htmlFor="imageUrl">Image URL</Label>
                    <Input 
                      id="imageUrl"
                      name="imageUrl"
                      placeholder="https://example.com/image.jpg" 
                      value={productForm.imageUrl}
                      onChange={handleFormChange}
                    />
                    <p className="text-xs text-neutral-500 mt-1">Enter a direct URL to the product image</p>
                  </div>
                  
                  {productForm.imageUrl && (
                    <div className="mt-4">
                      <p className="text-sm font-medium mb-2">Image Preview</p>
                      <div className="border rounded-md w-full max-w-xs h-auto aspect-square flex items-center justify-center overflow-hidden bg-neutral-50">
                        <img 
                          src={productForm.imageUrl} 
                          alt="Product preview" 
                          className="max-w-full max-h-full object-contain"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://placehold.co/400x400?text=Invalid+Image+URL';
                          }}
                        />
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              <Button onClick={() => handleSubmitProduct(false)} disabled={isSubmitting}>
                {isSubmitting ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Add Product
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Product Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Product</DialogTitle>
              <DialogDescription>
                Update the details for {currentProduct?.name}.
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 gap-4 py-4">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="mb-4">
                  <TabsTrigger value="basic">Basic Information</TabsTrigger>
                  <TabsTrigger value="pricing">Pricing & Inventory</TabsTrigger>
                  <TabsTrigger value="media">Media</TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label htmlFor="edit-name">Product Name*</Label>
                      <Input 
                        id="edit-name"
                        name="name"
                        placeholder="e.g. Michelin Defender T+H" 
                        value={productForm.name}
                        onChange={handleFormChange}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="edit-brand">Brand*</Label>
                        <Input 
                          id="edit-brand"
                          name="brand"
                          placeholder="e.g. Michelin" 
                          value={productForm.brand}
                          onChange={handleFormChange}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="edit-type">Category/Type</Label>
                        <Input 
                          id="edit-type"
                          name="type"
                          placeholder="e.g. All-Season" 
                          value={productForm.type}
                          onChange={handleFormChange}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="edit-description">Description</Label>
                      <Textarea 
                        id="edit-description"
                        name="description"
                        placeholder="Enter product description..." 
                        className="min-h-32"
                        value={productForm.description}
                        onChange={handleFormChange}
                      />
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="pricing" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="edit-price">Base Price*</Label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">$</span>
                        <Input 
                          id="edit-price"
                          name="price"
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0.00" 
                          className="pl-7"
                          value={productForm.price}
                          onChange={handleFormChange}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="edit-discountedPrice">Sale Price</Label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">$</span>
                        <Input 
                          id="edit-discountedPrice"
                          name="discountedPrice"
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0.00" 
                          className="pl-7"
                          value={productForm.discountedPrice}
                          onChange={handleFormChange}
                        />
                      </div>
                      <p className="text-xs text-neutral-500 mt-1">Leave empty if not on sale</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="edit-stock">Stock Quantity*</Label>
                      <Input 
                        id="edit-stock"
                        name="stock"
                        type="number"
                        min="0"
                        placeholder="0" 
                        value={productForm.stock}
                        onChange={handleFormChange}
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2 pt-6">
                      <Checkbox 
                        id="edit-isFeatured" 
                        checked={productForm.isFeatured}
                        onCheckedChange={handleCheckboxChange}
                      />
                      <Label htmlFor="edit-isFeatured" className="cursor-pointer">Mark as Featured Product</Label>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="media" className="space-y-4">
                  <div>
                    <Label htmlFor="edit-imageUrl">Image URL</Label>
                    <Input 
                      id="edit-imageUrl"
                      name="imageUrl"
                      placeholder="https://example.com/image.jpg" 
                      value={productForm.imageUrl}
                      onChange={handleFormChange}
                    />
                    <p className="text-xs text-neutral-500 mt-1">Enter a direct URL to the product image</p>
                  </div>
                  
                  {productForm.imageUrl && (
                    <div className="mt-4">
                      <p className="text-sm font-medium mb-2">Image Preview</p>
                      <div className="border rounded-md w-full max-w-xs h-auto aspect-square flex items-center justify-center overflow-hidden bg-neutral-50">
                        <img 
                          src={productForm.imageUrl} 
                          alt="Product preview" 
                          className="max-w-full max-h-full object-contain"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://placehold.co/400x400?text=Invalid+Image+URL';
                          }}
                        />
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
              <Button onClick={() => handleSubmitProduct(true)} disabled={isSubmitting}>
                {isSubmitting ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
};

export default AdminProductsPage;
import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useSearch } from '@/contexts/SearchContext';
import { PhotoSearchModal } from '@/components/search/PhotoSearchModal';

const VehicleSearch = () => {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const { setVehicleParams } = useSearch();
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  
  const [vehicleParams, setVehicleParamsState] = useState({
    year: '',
    make: '',
    model: '',
    trim: '',
    tireSize: ''
  });
  
  // Sample data for dropdowns
  const years = Array.from({ length: 10 }, (_, i) => (2023 - i).toString());
  const makes = ['Toyota', 'Honda', 'Ford', 'Chevrolet', 'BMW', 'Mercedes', 'Audi', 'Nissan'];
  
  // Models would typically depend on make selection
  const models = {
    Toyota: ['Camry', 'Corolla', 'RAV4', 'Highlander'],
    Honda: ['Accord', 'Civic', 'CR-V', 'Pilot'],
    Ford: ['F-150', 'Escape', 'Explorer', 'Mustang'],
    Chevrolet: ['Silverado', 'Equinox', 'Malibu', 'Tahoe'],
    BMW: ['3 Series', '5 Series', 'X3', 'X5'],
    Mercedes: ['C-Class', 'E-Class', 'GLC', 'GLE'],
    Audi: ['A4', 'A6', 'Q5', 'Q7'],
    Nissan: ['Altima', 'Sentra', 'Rogue', 'Pathfinder']
  };
  
  const handleChange = (field: string, value: string) => {
    setVehicleParamsState(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate essential fields
    if (!vehicleParams.year || !vehicleParams.make || !vehicleParams.model) {
      toast({
        title: "Missing Information",
        description: "Please select your vehicle's year, make, and model",
        variant: "destructive",
      });
      return;
    }
    
    // Set search context and navigate to products
    setVehicleParams(vehicleParams);
    setLocation('/products');
  };
  
  return (
    <section id="shop-by-vehicle" className="bg-white py-10">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-6">Find Your Perfect Tire Match</h2>
          
          <form onSubmit={handleSubmit} className="bg-neutral-100 rounded-lg p-6 shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <Label className="block text-sm font-medium mb-1">Vehicle Year</Label>
                <Select 
                  value={vehicleParams.year} 
                  onValueChange={(val) => handleChange('year', val)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Year" />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map(year => (
                      <SelectItem key={year} value={year}>{year}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="block text-sm font-medium mb-1">Make</Label>
                <Select 
                  value={vehicleParams.make} 
                  onValueChange={(val) => handleChange('make', val)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Make" />
                  </SelectTrigger>
                  <SelectContent>
                    {makes.map(make => (
                      <SelectItem key={make} value={make}>{make}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="block text-sm font-medium mb-1">Model</Label>
                <Select 
                  value={vehicleParams.model} 
                  onValueChange={(val) => handleChange('model', val)}
                  disabled={!vehicleParams.make}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Model" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicleParams.make && models[vehicleParams.make as keyof typeof models]?.map(model => (
                      <SelectItem key={model} value={model}>{model}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <Label className="block text-sm font-medium mb-1">Trim (Optional)</Label>
                <Select 
                  value={vehicleParams.trim} 
                  onValueChange={(val) => handleChange('trim', val)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Trim" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LE">LE</SelectItem>
                    <SelectItem value="SE">SE</SelectItem>
                    <SelectItem value="XLE">XLE</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="block text-sm font-medium mb-1">Tire Size (Optional)</Label>
                <Select 
                  value={vehicleParams.tireSize} 
                  onValueChange={(val) => handleChange('tireSize', val)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="215/55R17">215/55R17</SelectItem>
                    <SelectItem value="225/45R18">225/45R18</SelectItem>
                  </SelectContent>
                </Select>
              </div>

            </div>
            
            <div className="flex justify-center">
              <Button type="submit" className="bg-primary hover:bg-primary/90 text-white font-medium py-3 px-8 rounded-lg">
                Find My Tires
              </Button>
            </div>
          </form>
          
          {/* Alternative Search Methods removed as requested */}
        </div>
      </div>
      
      {/* Photo Search Modal */}
      <PhotoSearchModal 
        isOpen={showPhotoModal} 
        onClose={() => setShowPhotoModal(false)} 
      />
    </section>
  );
};

export default VehicleSearch;

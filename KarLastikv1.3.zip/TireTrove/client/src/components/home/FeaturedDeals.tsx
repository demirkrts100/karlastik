import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { useCart } from '@/hooks/useCart';
import { Skeleton } from '@/components/ui/skeleton';
import { Tire } from '@shared/schema';
import { ChevronLeft, ChevronRight, ShoppingCart, Heart, Check } from 'lucide-react';
import { WishlistButton } from '@/components/wishlist/WishlistButton';

const FeaturedDeals = () => {
  const { addItem } = useCart();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  
  // Fetch featured tires with promo
  const { data: tires, isLoading, error } = useQuery<Tire[]>({
    queryKey: ['/api/tires/featured'],
  });
  
  const handleAddToCart = async (e: React.MouseEvent, tire: Tire) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      const button = e.currentTarget as HTMLButtonElement;
      const originalText = button.innerHTML;
      button.innerHTML = '<svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';
      
      await addItem(tire.id, 1);
      
      setTimeout(() => {
        button.innerHTML = originalText;
      }, 300);
    } catch (error) {
      console.error('Failed to add to cart:', error);
    }
  };

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };

  const checkScrollability = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 10);
    }
  };

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      checkScrollability();
      container.addEventListener('scroll', checkScrollability);
      window.addEventListener('resize', checkScrollability);
      
      return () => {
        container.removeEventListener('scroll', checkScrollability);
        window.removeEventListener('resize', checkScrollability);
      };
    }
  }, [tires]);
  
  return (
    <section className="py-8 bg-white">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">New on TireHub</h2>
          <Link href="/products" className="text-black hover:underline font-medium flex items-center">
            All products <ChevronRight className="ml-1 h-5 w-5" />
          </Link>
        </div>
        
        <div className="relative">
          {/* Navigation Arrows */}
          <div className={`absolute left-0 top-1/2 transform -translate-y-1/2 z-10 -ml-4 ${!canScrollLeft ? 'hidden' : ''}`}>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-10 w-10 rounded-full bg-white shadow-md hover:bg-neutral-100"
              onClick={scrollLeft}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
          </div>
          
          <div className={`absolute right-0 top-1/2 transform -translate-y-1/2 z-10 -mr-4 ${!canScrollRight ? 'hidden' : ''}`}>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-10 w-10 rounded-full bg-white shadow-md hover:bg-neutral-100"
              onClick={scrollRight}
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((item) => (
                <Card key={item} className="overflow-hidden">
                  <Skeleton className="h-36 w-full" />
                  <CardContent className="p-3">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-3 w-full mb-3" />
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : error ? (
            <div className="text-center p-8">
              <p className="text-red-500">Error loading featured deals. Please try again later.</p>
            </div>
          ) : (
            <div 
              ref={scrollContainerRef}
              className="flex overflow-x-auto hide-scrollbar gap-3 pb-4 snap-x scroll-px-4"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {tires?.map((tire) => (
                <div 
                  key={tire.id} 
                  className="flex-none w-1/2 sm:w-1/3 md:w-1/4 lg:w-1/5 px-0 snap-start"
                  style={{ minWidth: 'min(50%, 220px)' }}
                >
                  <Card className="bg-white rounded-lg shadow-sm overflow-hidden group hover:shadow-md transition-shadow h-full flex flex-col relative border border-gray-100">
                    <Link href={`/product/${tire.id}`}>
                      <div className="relative">
                        <img src={tire.imageUrl} alt={tire.name} className="w-full h-36 object-contain p-2" />
                        {tire.hasPromo && (
                          <div className="absolute bottom-0 left-0 right-0 bg-accent/90 text-white px-2 py-1 text-xs font-medium text-center">
                            Flash sale {Math.floor(Math.random() * 6)}:0{Math.floor(Math.random() * 10)}
                          </div>
                        )}
                      </div>
                    </Link>
                    
                    <div className="absolute top-2 right-2">
                      <WishlistButton
                        tireId={tire.id}
                        size="icon"
                        variant="ghost"
                        className="bg-white hover:bg-white p-1.5 h-7 w-7 rounded-full shadow-sm"
                      />
                    </div>
                    
                    <CardContent className="p-3 flex-grow flex flex-col">
                      <div className="text-lg font-bold">
                        ${tire.discountedPrice || tire.price}
                      </div>
                      
                      <Link href={`/product/${tire.id}`}>
                        <h3 className="text-sm text-neutral-800 line-clamp-2 my-1 hover:text-primary cursor-pointer min-h-[40px]">
                          {tire.name} - {tire.size}
                        </h3>
                      </Link>
                      
                      <div className="flex items-center mt-2 justify-between">
                        <div className="flex items-center">
                          <div className="flex items-center text-xs font-medium">
                            <svg width="22" height="22" viewBox="0 0 22 22" className="mr-1.5">
                              <path d="M11 2C6.03 2 2 6.03 2 11C2 15.97 6.03 20 11 20C15.97 20 20 15.97 20 11C20 6.03 15.97 2 11 2Z" fill="#1E8FFF"/>
                              <path d="M11 2C10.22 2 9.45 2.12 8.73 2.34C9.89 2.12 11.11 2.12 12.27 2.34C13.43 2.56 14.53 2.99 15.5 3.6C16.47 4.21 17.29 5.01 17.9 5.98C18.51 6.95 18.94 8.05 19.16 9.21C19.38 10.37 19.38 11.59 19.16 12.75C18.94 13.91 18.51 15.01 17.9 15.98C17.29 16.95 16.49 17.77 15.52 18.38C14.55 18.99 13.45 19.42 12.29 19.64C11.13 19.86 9.91 19.86 8.75 19.64C7.59 19.42 6.49 18.99 5.52 18.38C4.55 17.77 3.73 16.97 3.12 16C2.51 15.03 2.08 13.93 1.86 12.77C1.64 11.61 1.64 10.39 1.86 9.23C2.08 8.07 2.51 6.97 3.12 6C3.73 5.03 4.51 4.21 5.48 3.6C6.45 2.99 7.55 2.56 8.71 2.34C9.45 2.12 10.22 2 11 2Z" fill="#2196F3"/>
                              <path d="M11 2.5C6.31 2.5 2.5 6.31 2.5 11C2.5 15.69 6.31 19.5 11 19.5C15.69 19.5 19.5 15.69 19.5 11C19.5 6.31 15.69 2.5 11 2.5ZM15.81 8.63L10.38 14.06C10.19 14.25 9.92 14.35 9.65 14.35C9.38 14.35 9.11 14.25 8.92 14.06L6.19 11.34C5.8 10.95 5.8 10.31 6.19 9.92C6.58 9.53 7.22 9.53 7.61 9.92L9.65 11.96L14.39 7.22C14.78 6.83 15.42 6.83 15.81 7.22C16.2 7.61 16.2 8.24 15.81 8.63Z" fill="#0F8EFF"/>
                              <path d="M15.81 7.22C15.42 6.83 14.78 6.83 14.39 7.22L9.65 11.96L7.61 9.92C7.22 9.53 6.58 9.53 6.19 9.92C5.8 10.31 5.8 10.95 6.19 11.34L8.92 14.06C9.11 14.25 9.38 14.35 9.65 14.35C9.92 14.35 10.19 14.25 10.38 14.06L15.81 8.63C16.2 8.24 16.2 7.61 15.81 7.22Z" fill="white"/>
                            </svg>
                            <span className="text-black font-medium">KarLastik</span>
                          </div>
                        </div>
                        
                        <Button
                          size="icon"
                          variant="default"
                          className="rounded-full h-9 w-9 bg-primary hover:bg-primary/90"
                          onClick={(e) => handleAddToCart(e, tire)}
                        >
                          <ShoppingCart className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default FeaturedDeals;

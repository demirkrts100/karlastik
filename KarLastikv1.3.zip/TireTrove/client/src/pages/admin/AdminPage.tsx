import { useLocation } from "wouter";
import AdminDashboardPage from "./DashboardPage";
import OrdersPage from "./OrdersPage";
import ReviewsPage from "./ReviewsPage";
import ProductsPage from "./ProductsPage";
import UsersPage from "./UsersPage";
import { useEffect } from "react";

const AdminPage = () => {
  const [location] = useLocation();
  const path = location.split("/")[2] || ""; // Extract the section from URL

  // Routes to specific admin sections
  const renderSection = () => {
    switch (path) {
      case "":  // Default dashboard
        return <AdminDashboardPage />;
      case "orders":
        return <OrdersPage />;  
      case "products":
        return <ProductsPage />;
      case "reviews":
        return <ReviewsPage />;
      case "users":
        return <UsersPage />;
      default:
        return <AdminDashboardPage />;
    }
  };

  return renderSection();
};

export default AdminPage;
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useLocation, Link } from 'wouter';
import { useAuth } from '@/components/auth/AuthProvider';
import { Loader2, User, ShoppingBag, CreditCard, MapPin, LogOut, Settings, Eye, EyeOff, Lock, Star } from 'lucide-react';
import PaymentMethodsTab from '@/components/account/PaymentMethodsTab';
import OrdersTab from '@/components/account/OrdersTab';
import ReviewsTab from '@/components/account/ReviewsTab';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger
} from '@/components/ui/alert-dialog';

const AccountPage = () => {
  const { user, isLoading, logoutMutation, updateProfileMutation, changePasswordMutation } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const [activeTab, setActiveTab] = useState('profile');
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [passwords, setPasswords] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  useEffect(() => {
    // Check for URL parameters to set active tab
    const searchParams = new URLSearchParams(window.location.search);
    const tabParam = searchParams.get('tab');
    
    if (tabParam) {
      // Only set if the tab is valid
      const validTabs = ['profile', 'orders', 'payment', 'addresses', 'reviews', 'settings'];
      if (validTabs.includes(tabParam)) {
        setActiveTab(tabParam);
      }
    }
  }, [location]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        toast({
          title: "Logged out successfully",
          description: "You have been logged out of your account",
        });
      },
      onError: (error) => {
        toast({
          title: "Logout failed",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <div className="w-full md:w-1/4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="mr-2 h-6 w-6 text-primary" />
                <span>{user?.username}</span>
              </CardTitle>
              <CardDescription>{user?.email}</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="border-t border-gray-200">
                <Tabs
                  value={activeTab}
                  onValueChange={setActiveTab}
                  orientation="vertical"
                  className="w-full"
                >
                  <TabsList className="flex flex-col items-start h-auto p-0 bg-transparent">
                    <TabsTrigger
                      value="profile"
                      className="w-full justify-start px-4 py-3 data-[state=active]:bg-neutral-100 data-[state=active]:shadow-none border-b border-gray-200"
                    >
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </TabsTrigger>
                    <TabsTrigger
                      value="orders"
                      className="w-full justify-start px-4 py-3 data-[state=active]:bg-neutral-100 data-[state=active]:shadow-none border-b border-gray-200"
                    >
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      Order History
                    </TabsTrigger>
                    <TabsTrigger
                      value="payment"
                      className="w-full justify-start px-4 py-3 data-[state=active]:bg-neutral-100 data-[state=active]:shadow-none border-b border-gray-200"
                    >
                      <CreditCard className="mr-2 h-4 w-4" />
                      Payment Methods
                    </TabsTrigger>
                    <TabsTrigger
                      value="addresses"
                      className="w-full justify-start px-4 py-3 data-[state=active]:bg-neutral-100 data-[state=active]:shadow-none border-b border-gray-200"
                    >
                      <MapPin className="mr-2 h-4 w-4" />
                      Saved Addresses
                    </TabsTrigger>
                    <TabsTrigger
                      value="reviews"
                      className="w-full justify-start px-4 py-3 data-[state=active]:bg-neutral-100 data-[state=active]:shadow-none border-b border-gray-200"
                    >
                      <Star className="mr-2 h-4 w-4" />
                      My Reviews
                    </TabsTrigger>
                    <TabsTrigger
                      value="settings"
                      className="w-full justify-start px-4 py-3 data-[state=active]:bg-neutral-100 data-[state=active]:shadow-none border-b border-gray-200"
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      Account Settings
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center p-4">
              <Button
                variant="outline"
                className="w-full"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                {logoutMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <LogOut className="mr-2 h-4 w-4" />
                )}
                Sign Out
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Content Area */}
        <div className="w-full md:w-3/4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsContent value="profile" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>
                    Manage your personal information
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    const profileData = {
                      firstName: formData.get('firstName') as string,
                      lastName: formData.get('lastName') as string,
                      phone: formData.get('phone') as string,
                      address: formData.get('address') as string,
                      city: formData.get('city') as string,
                      state: formData.get('state') as string,
                      zipCode: formData.get('zipCode') as string,
                    };
                    
                    updateProfileMutation.mutate(profileData);
                  }}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="username">Username</Label>
                        <Input id="username" value={user?.username || ''} readOnly />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" value={user?.email || ''} readOnly />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input 
                          id="firstName" 
                          name="firstName"
                          placeholder="Enter your first name" 
                          defaultValue={user?.firstName || ''} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input 
                          id="lastName" 
                          name="lastName"
                          placeholder="Enter your last name" 
                          defaultValue={user?.lastName || ''} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input 
                          id="phone" 
                          name="phone"
                          placeholder="Enter your phone number" 
                          defaultValue={user?.phone || ''} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Input 
                          id="address" 
                          name="address"
                          placeholder="Enter your address" 
                          defaultValue={user?.address || ''} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="city">City</Label>
                        <Input 
                          id="city" 
                          name="city"
                          placeholder="Enter your city" 
                          defaultValue={user?.city || ''} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="state">State</Label>
                        <Input 
                          id="state" 
                          name="state"
                          placeholder="Enter your state" 
                          defaultValue={user?.state || ''} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="zipCode">ZIP Code</Label>
                        <Input 
                          id="zipCode" 
                          name="zipCode"
                          placeholder="Enter your ZIP code" 
                          defaultValue={user?.zipCode || ''} 
                        />
                      </div>
                    </div>
                    <div className="mt-6">
                      <Button 
                        type="submit" 
                        disabled={updateProfileMutation.isPending}
                        className="mr-2"
                      >
                        {updateProfileMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          'Save Changes'
                        )}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="orders" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Order History</CardTitle>
                  <CardDescription>
                    View and track your previous orders
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <OrdersTab />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payment" className="mt-0">
              <PaymentMethodsTab />
            </TabsContent>

            <TabsContent value="addresses" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Saved Addresses</CardTitle>
                  <CardDescription>
                    Manage your shipping and billing addresses
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <MapPin className="h-12 w-12 mx-auto text-neutral-300 mb-2" />
                    <h3 className="text-lg font-medium">No addresses saved</h3>
                    <p className="text-neutral-500 mt-1">Add an address for faster checkout</p>
                    <Button className="mt-4" variant="outline">
                      Add Address
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews" className="mt-0">
              <ReviewsTab />
            </TabsContent>

            <TabsContent value="settings" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>
                    Manage your account settings and preferences
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Security Settings</h3>
                      <p className="text-neutral-500 text-sm mb-4">
                        Manage your account password and security preferences
                      </p>
                      <div className="space-y-4 mt-4">
                        <div className="p-4 border rounded-md">
                          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2 mb-2">
                            <div>
                              <h4 className="font-medium">Password</h4>
                              <p className="text-sm text-neutral-500">Last changed: Never</p>
                            </div>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="w-full sm:w-auto"
                              onClick={() => setChangePasswordOpen(true)}
                            >
                              Change
                            </Button>
                            
                            <Dialog open={changePasswordOpen} onOpenChange={setChangePasswordOpen}>
                              <DialogContent className="sm:max-w-[425px]">
                                <DialogHeader>
                                  <DialogTitle className="flex items-center">
                                    <Lock className="mr-2 h-5 w-5 text-primary" />
                                    Change Password
                                  </DialogTitle>
                                  <DialogDescription>
                                    Enter your current password and a new password below.
                                  </DialogDescription>
                                </DialogHeader>
                                
                                <div className="space-y-4 py-2">
                                  <div className="space-y-2">
                                    <Label htmlFor="currentPassword">Current Password</Label>
                                    <div className="relative">
                                      <Input 
                                        id="currentPassword"
                                        type={passwordVisible ? "text" : "password"}
                                        placeholder="Enter your current password"
                                        value={passwords.currentPassword}
                                        onChange={(e) => setPasswords({...passwords, currentPassword: e.target.value})}
                                      />
                                      <button 
                                        type="button"
                                        onClick={() => setPasswordVisible(!passwordVisible)}
                                        className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                                      >
                                        {passwordVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                      </button>
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-2">
                                    <Label htmlFor="newPassword">New Password</Label>
                                    <div className="relative">
                                      <Input 
                                        id="newPassword"
                                        type={passwordVisible ? "text" : "password"}
                                        placeholder="Enter your new password"
                                        value={passwords.newPassword}
                                        onChange={(e) => setPasswords({...passwords, newPassword: e.target.value})}
                                      />
                                      <button 
                                        type="button"
                                        onClick={() => setPasswordVisible(!passwordVisible)}
                                        className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                                      >
                                        {passwordVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                      </button>
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-2">
                                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                                    <div className="relative">
                                      <Input 
                                        id="confirmPassword"
                                        type={passwordVisible ? "text" : "password"}
                                        placeholder="Confirm your new password"
                                        value={passwords.confirmPassword}
                                        onChange={(e) => setPasswords({...passwords, confirmPassword: e.target.value})}
                                      />
                                      <button 
                                        type="button"
                                        onClick={() => setPasswordVisible(!passwordVisible)}
                                        className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                                      >
                                        {passwordVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                      </button>
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-2 pt-2">
                                    <p className="text-sm font-medium">Password Tips for Memorable Security</p>
                                    <ul className="text-xs text-neutral-500 space-y-1 list-disc pl-4">
                                      <li>Use a phrase you can easily remember, like "TiresRollingDown2Hill!"</li>
                                      <li>Include a mix of uppercase, lowercase, numbers, and symbols</li>
                                      <li>Avoid using obvious personal information like your birthday</li>
                                      <li>Consider using the first letter of each word in a sentence or song lyric</li>
                                    </ul>
                                  </div>
                                  
                                  {passwords.newPassword && (
                                    <div className="space-y-1 pt-2">
                                      <p className="text-sm font-medium">Password Strength</p>
                                      <div className="w-full bg-neutral-100 h-2 rounded-full">
                                        <div className={`h-2 rounded-full ${
                                          passwords.newPassword.length < 6 
                                            ? 'w-1/4 bg-red-500' 
                                            : passwords.newPassword.length < 8 
                                            ? 'w-1/2 bg-yellow-500' 
                                            : /[A-Z]/.test(passwords.newPassword) && /[0-9]/.test(passwords.newPassword) && passwords.newPassword.length >= 10
                                            ? 'w-full bg-green-500'
                                            : /[A-Z]/.test(passwords.newPassword) && /[0-9]/.test(passwords.newPassword)
                                            ? 'w-3/4 bg-blue-500'
                                            : 'w-1/2 bg-yellow-500'
                                        }`}></div>
                                      </div>
                                      <p className="text-xs text-neutral-500">
                                        {passwords.newPassword.length < 6 
                                          ? 'Weak: Use at least 6 characters' 
                                          : passwords.newPassword.length < 8 
                                          ? 'Medium: Use at least 8 characters' 
                                          : /[A-Z]/.test(passwords.newPassword) && /[0-9]/.test(passwords.newPassword) && passwords.newPassword.length >= 10
                                          ? 'Strong: Great password! Secure and memorable'
                                          : /[A-Z]/.test(passwords.newPassword) && /[0-9]/.test(passwords.newPassword)
                                          ? 'Good: Try making it a bit longer (10+ chars)'
                                          : 'Medium: Add uppercase letters and numbers'}
                                      </p>
                                    </div>
                                  )}
                                </div>
                                
                                <DialogFooter className="gap-2 sm:gap-0">
                                  <Button 
                                    variant="outline" 
                                    className="w-full sm:w-auto mt-2 sm:mt-0"
                                    onClick={() => {
                                      setChangePasswordOpen(false);
                                      setPasswords({
                                        currentPassword: '',
                                        newPassword: '',
                                        confirmPassword: '',
                                      });
                                    }}
                                  >
                                    Cancel
                                  </Button>
                                  
                                  <Button 
                                    type="submit" 
                                    className="w-full sm:w-auto"
                                    disabled={changePasswordMutation.isPending}
                                    onClick={() => {
                                      // Validate passwords
                                      if (!passwords.currentPassword) {
                                        toast({
                                          title: "Current password required",
                                          description: "Please enter your current password",
                                          variant: "destructive",
                                        });
                                        return;
                                      }
                                      
                                      if (!passwords.newPassword) {
                                        toast({
                                          title: "New password required",
                                          description: "Please enter a new password",
                                          variant: "destructive",
                                        });
                                        return;
                                      }
                                      
                                      if (passwords.newPassword.length < 6) {
                                        toast({
                                          title: "Password too short",
                                          description: "Password must be at least 6 characters long",
                                          variant: "destructive",
                                        });
                                        return;
                                      }
                                      
                                      if (passwords.newPassword !== passwords.confirmPassword) {
                                        toast({
                                          title: "Passwords don't match",
                                          description: "New password and confirmation must match",
                                          variant: "destructive",
                                        });
                                        return;
                                      }

                                      if (passwords.currentPassword === passwords.newPassword) {
                                        toast({
                                          title: "Invalid new password",
                                          description: "New password must be different from your current password",
                                          variant: "destructive",
                                        });
                                        return;
                                      }
                                      
                                      // Handle password change with mutation
                                      changePasswordMutation.mutate(
                                        {
                                          currentPassword: passwords.currentPassword,
                                          newPassword: passwords.newPassword,
                                        },
                                        {
                                          onSuccess: () => {
                                            setChangePasswordOpen(false);
                                            setPasswords({
                                              currentPassword: '',
                                              newPassword: '',
                                              confirmPassword: '',
                                            });
                                          },
                                        }
                                      );
                                    }}
                                  >
                                    {changePasswordMutation.isPending ? (
                                      <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Updating...
                                      </>
                                    ) : (
                                      "Update Password"
                                    )}
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          </div>
                          <div className="w-full bg-neutral-100 h-2 rounded-full mt-2">
                            <div className="bg-yellow-500 h-2 rounded-full w-1/2"></div>
                          </div>
                          <p className="text-xs text-neutral-500 mt-1">Medium strength</p>
                        </div>
                        
                        <div className="p-4 border rounded-md">
                          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2 mb-2">
                            <div>
                              <h4 className="font-medium">Two-Factor Authentication</h4>
                              <p className="text-sm text-neutral-500">Status: Not enabled</p>
                            </div>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="w-full sm:w-auto"
                              onClick={() => {
                                toast({
                                  title: "Coming soon",
                                  description: "Two-factor authentication will be available soon",
                                });
                              }}
                            >
                              Enable
                            </Button>
                          </div>
                          <p className="text-xs text-neutral-500 mt-3">Add an extra layer of security to your account by enabling two-factor authentication.</p>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Email Preferences</h3>
                      <p className="text-neutral-500 text-sm mb-4">
                        Manage your email notification settings
                      </p>
                      <div className="space-y-4 mt-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <input type="checkbox" id="orderUpdates" className="h-4 w-4 text-primary rounded" />
                            <div>
                              <label htmlFor="orderUpdates" className="font-medium">Order Updates</label>
                              <p className="text-sm text-neutral-500">Receive updates about your order status</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <input type="checkbox" id="promotions" className="h-4 w-4 text-primary rounded" />
                            <div>
                              <label htmlFor="promotions" className="font-medium">Promotions and Deals</label>
                              <p className="text-sm text-neutral-500">Receive special offers and discounts</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <input type="checkbox" id="newsletter" className="h-4 w-4 text-primary rounded" />
                            <div>
                              <label htmlFor="newsletter" className="font-medium">Newsletter</label>
                              <p className="text-sm text-neutral-500">Receive our weekly newsletter with tire tips and news</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <input type="checkbox" id="accountAlerts" className="h-4 w-4 text-primary rounded" />
                            <div>
                              <label htmlFor="accountAlerts" className="font-medium">Account Alerts</label>
                              <p className="text-sm text-neutral-500">Important notifications about your account</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="mt-6 w-full sm:w-auto inline-block">
                        <Button className="w-full sm:w-auto">Save Preferences</Button>
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <h3 className="text-lg font-medium text-red-600">Delete Account</h3>
                      <p className="text-neutral-500 text-sm mb-4">
                        Permanently delete your account and all associated data
                      </p>
                      <div className="w-full sm:w-auto inline-block">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" className="w-full sm:w-auto">Delete Account</Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="max-w-md">
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete your
                                account and remove all your data from our servers.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter className="flex-col sm:flex-row gap-2 sm:gap-0">
                              <AlertDialogCancel className="w-full sm:w-auto mt-2 sm:mt-0">Cancel</AlertDialogCancel>
                              <AlertDialogAction 
                                className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white"
                                onClick={() => {
                                  toast({
                                    title: "Account deletion requested",
                                    description: "Your account will be deleted shortly",
                                  });
                                }}
                              >
                                Delete Account
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default AccountPage;
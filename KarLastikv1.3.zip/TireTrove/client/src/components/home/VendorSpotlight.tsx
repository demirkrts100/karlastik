import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Skeleton } from '@/components/ui/skeleton';
import { Star, StarHalf } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Vendor } from '@shared/schema';

const VendorSpotlight = () => {
  // Fetch featured vendors
  const { data: vendors, isLoading, error } = useQuery<Vendor[]>({
    queryKey: ['/api/vendors/featured'],
  });
  
  // Function to render star ratings
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-accent fill-accent" size={16} />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-accent fill-accent" size={16} />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-accent" size={16} />);
    }
    
    return stars;
  };
  
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">Featured Vendors</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((item) => (
              <div key={item} className="rounded-lg overflow-hidden">
                <Skeleton className="h-60 w-full" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center p-8">
            <p className="text-red-500">Error loading vendors. Please try again later.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vendors?.map((vendor) => (
              <div key={vendor.id} className="relative rounded-lg overflow-hidden vendor-card group">
                <img 
                  src={vendor.imageUrl} 
                  alt={vendor.name} 
                  className="w-full h-60 object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
                  <h3 className="font-bold text-lg text-white mb-1">{vendor.name}</h3>
                  <p className="text-white text-sm mb-2 opacity-90">{vendor.description}</p>
                  <div className="flex items-center text-white">
                    <div className="flex mr-2">
                      {renderStars(Number(vendor.rating))}
                    </div>
                    <span className="text-sm">
                      {Number(vendor.rating).toFixed(1)} ({vendor.reviewCount} reviews)
                    </span>
                  </div>
                </div>
                <Link href={`/vendors/${vendor.id}`} className="absolute inset-0" aria-label={`View ${vendor.name}`}></Link>
              </div>
            ))}
          </div>
        )}
        
        <div className="mt-10 text-center">
          <Button asChild variant="outline" className="inline-block bg-white border border-primary text-primary hover:bg-primary hover:text-white font-medium py-2 px-6 rounded-lg">
            <Link href="/vendors">Browse All Vendors</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default VendorSpotlight;

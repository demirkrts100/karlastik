import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, CheckCircle, AlertCircle, CreditCard } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/auth/AuthProvider';
import { usePaymentMethods } from '@/hooks/usePaymentMethods';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const formSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Phone number must be at least 10 digits"),
  address: z.string().min(5, "Address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  zipCode: z.string().min(5, "ZIP code is required"),
  paymentMethodId: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const CheckoutPage = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isLoading: isUserLoading } = useAuth();
  const { paymentMethods, isLoading: isPaymentMethodsLoading } = usePaymentMethods();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [orderComplete, setOrderComplete] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('');
  const [useShippingAsBilling, setUseShippingAsBilling] = useState(true);

  // Get cart items
  const { data: cartItems = [], isLoading: isCartLoading } = useQuery<any[]>({
    queryKey: ['/api/cart'],
  });

  // Calculate order summary
  const subtotal = cartItems.reduce((sum: number, item: any) => {
    const price = parseFloat(item.tire?.discountedPrice || item.tire?.price || 0);
    return sum + price * item.quantity;
  }, 0);
  
  const shipping = 15.99;
  const tax = subtotal * 0.085; // 8.5% tax rate
  const total = subtotal + shipping + tax;

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: user?.firstName || '',
      lastName: user?.lastName || '',
      email: user?.email || '',
      phone: user?.phone || '',
      address: user?.address || '',
      city: user?.city || '',
      state: user?.state || '',
      zipCode: user?.zipCode || '',
      paymentMethodId: '',
    },
  });

  // Update form values when user data is loaded
  useEffect(() => {
    if (user) {
      // Only update form values with user data if the fields exist
      if (user.firstName) form.setValue('firstName', user.firstName);
      if (user.lastName) form.setValue('lastName', user.lastName);
      if (user.email) form.setValue('email', user.email);
      if (user.phone) form.setValue('phone', user.phone);
      if (user.address) form.setValue('address', user.address);
      if (user.city) form.setValue('city', user.city);
      if (user.state) form.setValue('state', user.state);
      if (user.zipCode) form.setValue('zipCode', user.zipCode);
    }
  }, [user, form]);

  // Select default payment method if available
  useEffect(() => {
    if (paymentMethods?.length > 0) {
      const defaultMethod = paymentMethods.find(method => method.isDefault);
      if (defaultMethod) {
        setSelectedPaymentMethod(defaultMethod.id.toString());
        form.setValue('paymentMethodId', defaultMethod.id.toString());
      }
    }
  }, [paymentMethods, form]);

  const onSubmit = async (data: FormValues) => {
    if (cartItems.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add items to your cart before checking out",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    setPaymentStatus('processing');
    
    try {
      // Process payment with Stripe
      const paymentResponse = await apiRequest('POST', '/api/create-payment-intent', {
        amount: total,
        paymentMethodId: selectedPaymentMethod,
      });
      
      const paymentData = await paymentResponse.json();
      
      if (paymentData.error) {
        throw new Error(paymentData.error.message);
      }
      
      // Handle mock payment (when Stripe is not configured)
      if (paymentData.isMock) {
        console.log('Using mock payment flow (Stripe not configured)');
        // In a real app, we would use Stripe Elements to confirm the payment
        // For now, we'll just simulate a successful payment
      } else {
        // In a real implementation with Stripe keys, we would use the client secret
        // to confirm the payment with Stripe.js
        console.log('Payment intent created with client secret:', paymentData.clientSecret);
      }
      
      // Create the order with the payment intent ID
      await apiRequest('POST', '/api/order', {
        totalAmount: total.toFixed(2),
        customerEmail: data.email,
        customerName: `${data.firstName} ${data.lastName}`,
        shippingAddress: `${data.address}, ${data.city}, ${data.state} ${data.zipCode}`,
        paymentIntentId: paymentData.paymentIntentId || paymentData.clientSecret,
      });
      
      // Success
      setPaymentStatus('success');
      setOrderComplete(true);
      
      // Clear form
      form.reset();
      
      toast({
        title: "Order placed successfully!",
        description: "Thank you for your purchase",
      });
    } catch (error: any) {
      console.error("Checkout error:", error);
      setPaymentStatus('error');
      toast({
        title: "Checkout failed",
        description: error.message || "An error occurred during checkout",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const isLoading = isUserLoading || isPaymentMethodsLoading || isCartLoading;
  
  // Show loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (cartItems.length === 0 && !orderComplete) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto text-center py-12">
          <AlertCircle className="h-12 w-12 mx-auto text-neutral-300 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-neutral-500 mb-6">Add items to your cart to proceed with checkout</p>
          <Button onClick={() => navigate("/products")}>
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }
  
  if (orderComplete) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto text-center py-12">
          <CheckCircle className="h-16 w-16 mx-auto text-green-500 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Thank you for your order!</h2>
          <p className="text-neutral-500 mb-6">Your order has been placed successfully</p>
          <p className="text-neutral-600 mb-8">
            A confirmation email has been sent to your email address. You can track your order in the order history section of your account.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={() => navigate("/account?tab=orders")}>
              View Order
            </Button>
            <Button variant="outline" onClick={() => navigate("/products")}>
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column - Customer information and shipping */}
        <div className="lg:col-span-2 space-y-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Contact Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                  <CardDescription>
                    We'll use this information to contact you about your order
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your first name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your last name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your phone number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
              
              {/* Shipping Address */}
              <Card>
                <CardHeader>
                  <CardTitle>Shipping Address</CardTitle>
                  <CardDescription>
                    Where should we deliver your order?
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your street address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your city" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>State</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your state" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="zipCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ZIP Code</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your ZIP code" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
              
              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                  <CardDescription>
                    Select how you'd like to pay
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {user ? (
                    // For logged in users, show saved payment methods
                    paymentMethods.length > 0 ? (
                      <div className="space-y-3">
                        {paymentMethods.map((method) => (
                          <div 
                            key={method.id} 
                            className={`p-4 border rounded-lg flex items-center cursor-pointer transition-colors
                                        ${selectedPaymentMethod === method.id.toString() 
                                          ? 'border-primary bg-primary/5' 
                                          : 'hover:bg-neutral-50'}`}
                            onClick={() => {
                              setSelectedPaymentMethod(method.id.toString());
                              form.setValue('paymentMethodId', method.id.toString());
                            }}
                          >
                            <div className="flex-1 flex items-center gap-3">
                              <CreditCard className="h-6 w-6 text-neutral-600" />
                              <div>
                                <p className="font-medium">•••• •••• •••• {method.lastFourDigits}</p>
                                <p className="text-sm text-neutral-500">
                                  {method.cardholderName} • Expires {method.expiryMonth}/{method.expiryYear}
                                  {method.isDefault && ' • Default'}
                                </p>
                              </div>
                            </div>
                            <div className={`w-5 h-5 rounded-full border flex items-center justify-center
                                            ${selectedPaymentMethod === method.id.toString() 
                                              ? 'bg-primary border-primary' 
                                              : 'border-neutral-300'}`}>
                              {selectedPaymentMethod === method.id.toString() && (
                                <div className="w-2.5 h-2.5 rounded-full bg-white"></div>
                              )}
                            </div>
                          </div>
                        ))}
                        <Button 
                          variant="outline" 
                          type="button" 
                          className="mt-2 w-full"
                          onClick={() => navigate("/account?tab=payment")}
                        >
                          <CreditCard className="mr-2 h-4 w-4" />
                          Manage Payment Methods
                        </Button>
                      </div>
                    ) : (
                      <div className="text-center py-6">
                        <CreditCard className="h-12 w-12 mx-auto text-neutral-300 mb-2" />
                        <h3 className="font-medium mb-1">No payment methods saved</h3>
                        <p className="text-neutral-500 text-sm mb-4">
                          Add a payment method to complete your purchase
                        </p>
                        <Button 
                          variant="outline" 
                          type="button"
                          onClick={() => navigate("/account?tab=payment")}
                        >
                          Add Payment Method
                        </Button>
                      </div>
                    )
                  ) : (
                    // For guest checkout, show message to log in or continue as guest
                    <div className="text-center py-6">
                      <CreditCard className="h-12 w-12 mx-auto text-neutral-300 mb-2" />
                      <h3 className="font-medium mb-1">Guest Checkout</h3>
                      <p className="text-neutral-500 text-sm mb-4">
                        You are checking out as a guest. Login to use saved payment methods.
                      </p>
                      <div className="flex flex-col sm:flex-row gap-2 justify-center">
                        <Button 
                          variant="outline" 
                          type="button"
                          onClick={() => navigate("/auth")}
                        >
                          Login
                        </Button>
                        <Button 
                          type="button"
                          onClick={() => {
                            setSelectedPaymentMethod('guest_checkout');
                            form.setValue('paymentMethodId', 'guest_checkout');
                          }}
                        >
                          Continue as Guest
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {/* Submit Order Button (Mobile) */}
              <div className="lg:hidden">
                <Button 
                  className="w-full"
                  type="submit"
                  disabled={isSubmitting || selectedPaymentMethod === ''}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    `Place Order • $${total.toFixed(2)}`
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>
        
        {/* Right column - Order summary */}
        <div>
          <div className="sticky top-4">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>
                  {cartItems.reduce((sum: number, item: any) => sum + item.quantity, 0)} items
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="max-h-80 overflow-y-auto pr-2">
                  {cartItems.map((item: any) => (
                    <div key={item.id} className="flex items-center gap-4 py-3 border-b">
                      <div className="w-16 h-16 bg-neutral-100 rounded-md overflow-hidden flex-shrink-0">
                        {item.tire?.imageUrl && (
                          <img 
                            src={item.tire.imageUrl} 
                            alt={item.tire.name} 
                            className="w-full h-full object-cover"
                          />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm truncate">
                          {item.tire?.name || 'Product'}
                        </h4>
                        <p className="text-neutral-500 text-xs">
                          {item.tire?.size || ''} • {item.tire?.type || ''}
                        </p>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-sm font-medium">
                            ${parseFloat(item.tire?.discountedPrice || item.tire?.price || 0).toFixed(2)}
                          </span>
                          <span className="text-xs text-neutral-500">
                            Qty: {item.quantity}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-2 py-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-neutral-600">Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-neutral-600">Shipping</span>
                    <span>${shipping.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-neutral-600">Tax</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between font-medium">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full"
                  type="button"
                  disabled={isSubmitting || selectedPaymentMethod === ''}
                  onClick={form.handleSubmit(onSubmit)}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Place Order'
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
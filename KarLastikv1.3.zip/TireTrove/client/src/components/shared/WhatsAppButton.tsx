import { FaWhatsapp } from 'react-icons/fa';
import { useState } from 'react';

interface WhatsAppButtonProps {
  phoneNumber?: string;
  message?: string;
}

const WhatsAppButton = ({ 
  phoneNumber = "1234567890", // Replace with your actual WhatsApp number
  message = "Hello! I'm interested in your tire products." 
}: WhatsAppButtonProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  // Format phone number for WhatsApp API - remove any non-numeric characters
  const formattedNumber = phoneNumber.replace(/\D/g, '');
  
  // Create WhatsApp URL with phone number and optional pre-filled message
  const whatsappUrl = `https://wa.me/${formattedNumber}?text=${encodeURIComponent(message)}`;
  
  return (
    <a 
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 flex items-center bg-green-600 hover:bg-green-700 text-white rounded-full shadow-xl z-50 transition-all duration-300 hover:scale-105"
      aria-label="Chat on WhatsApp"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-center px-4 py-3">
        <FaWhatsapp className="h-6 w-6 mr-2" />
        <span className={`font-medium transition-all duration-300 ${isHovered ? 'max-w-[150px] opacity-100' : 'max-w-0 opacity-0 -ml-2'} whitespace-nowrap overflow-hidden`}>
          Chat with us
        </span>
      </div>
    </a>
  );
};

export default WhatsAppButton;
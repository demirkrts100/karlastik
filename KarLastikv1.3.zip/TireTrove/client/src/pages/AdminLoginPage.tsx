import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/components/auth/AuthProvider";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, AlertTriangle, ShieldCheck } from "lucide-react";
import { Helmet } from "react-helmet-async";
import { Checkbox } from "@/components/ui/checkbox";

const adminLoginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  rememberMe: z.boolean().default(false)
});

type AdminLoginValues = z.infer<typeof adminLoginSchema>;

const AdminLoginPage = () => {
  const [, setLocation] = useLocation();
  const { user, loginMutation, logoutMutation } = useAuth();
  const [loginError, setLoginError] = useState<string | null>(null);

  // Redirect if already logged in as an admin
  if (user && user.role === "admin") {
    setLocation("/admin");
    return null;
  }

  const form = useForm<AdminLoginValues>({
    resolver: zodResolver(adminLoginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  const onSubmit = async (data: AdminLoginValues) => {
    setLoginError(null);
    try {
      const result = await loginMutation.mutateAsync(data);
      
      if (result && result.role === "admin") {
        setLocation("/admin");
      } else {
        setLoginError("You don't have admin privileges");
        // If a regular user logs in, log them out
        if (result) {
          // This is a non-admin user, log them out
          await logout();
        }
      }
    } catch (error: any) {
      setLoginError(error.message || "Login failed");
    }
  };

  const logout = async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  return (
    <>
      <Helmet>
        <title>Admin Login | TireHub</title>
        <meta name="description" content="Admin access only. Login to manage TireHub marketplace." />
      </Helmet>
      {/* Admin Header */}
      <div className="bg-neutral-800 text-white py-4 shadow-md">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="h-6 w-6" />
            <span className="text-xl font-bold">TireHub Admin</span>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="text-white border-white hover:bg-white/10" 
            onClick={() => setLocation("/")}
          >
            Return to Store
          </Button>
        </div>
      </div>
      
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] bg-neutral-100">
        <div className="w-full max-w-md px-4">
          <Card className="shadow-lg border-neutral-200">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-center">Admin Login</CardTitle>
              <CardDescription className="text-center text-neutral-600">
                Administrator access only
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loginError && (
                <Alert variant="destructive" className="mb-4">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  <AlertDescription>{loginError}</AlertDescription>
                </Alert>
              )}
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Admin Username" 
                            {...field} 
                            className="h-10"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="Password" 
                            {...field} 
                            className="h-10"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="rememberMe"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                        <FormControl>
                          <Checkbox 
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="leading-none">
                          <FormLabel className="text-sm cursor-pointer">
                            Remember me
                          </FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <Button 
                    type="submit" 
                    className="w-full h-10 bg-neutral-800 hover:bg-neutral-700"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Logging in...
                      </>
                    ) : (
                      "Log In"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default AdminLoginPage;
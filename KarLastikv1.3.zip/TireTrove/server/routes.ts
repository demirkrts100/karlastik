import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { User, vehicleSearchSchema, insertCartItemSchema, photoSearchSchema, insertPaymentMethodSchema, paymentMethodSchema, insertWishlistItemSchema } from "@shared/schema";
import Stripe from "stripe";
import { v4 as uuidv4 } from "uuid";
import { setupAuth } from "./auth";

// Check for Stripe secret key
if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Missing STRIPE_SECRET_KEY environment variable. Checkout functionality will be limited.');
}

// Initialize Stripe with the secret key if available
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" as any })
  : null;

// Admin middleware to check if user has admin privileges
const isAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: "Forbidden: Admin access required" });
  }
  
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // Middleware to handle session IDs
  app.use((req: Request, res: Response, next: NextFunction) => {
    // Check if the client has a session ID in the cookie
    const cookieHeader = req.headers.cookie;
    if (cookieHeader) {
      const cookies = cookieHeader.split(';').map(cookie => cookie.trim());
      const sessionCookie = cookies.find(cookie => cookie.startsWith('sessionId='));
      if (sessionCookie) {
        (req as any).sessionId = sessionCookie.split('=')[1];
        return next();
      }
    }
    
    // If no session ID found, create a new one
    const sessionId = uuidv4();
    (req as any).sessionId = sessionId;
    
    // Set the session cookie
    res.setHeader('Set-Cookie', `sessionId=${sessionId}; Path=/; HttpOnly; SameSite=Strict`);
    next();
  });
  
  // Helper to get the session ID from the request
  const getSessionId = (req: Request): string => {
    return (req as any).sessionId;
  };
  
  // Get all tires
  app.get("/api/tires", async (req: Request, res: Response) => {
    try {
      const tires = await storage.getTires();
      res.json(tires);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get featured tires
  app.get("/api/tires/featured", async (req: Request, res: Response) => {
    try {
      const tires = await storage.getFeaturedTires();
      // Always return an array, even if empty
      res.json(tires || []);
    } catch (error: any) {
      console.error("Error fetching featured tires:", error);
      // Return empty array instead of error for better frontend handling
      res.json([]);
    }
  });
  
  // Get tires by type (all-season, winter, etc.)
  app.get("/api/tires/type/:type", async (req: Request, res: Response) => {
    try {
      const tires = await storage.getTiresByType(req.params.type);
      res.json(tires);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get tires by brand
  app.get("/api/tires/brand/:brand", async (req: Request, res: Response) => {
    try {
      const tires = await storage.getTiresByBrand(req.params.brand);
      res.json(tires);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Search tires
  app.get("/api/tires/search/:query", async (req: Request, res: Response) => {
    try {
      // Get available brands for exact match checking
      const brands = await storage.getBrands();
      const query = req.params.query.toLowerCase().trim();
      
      // Check if query exactly matches a brand name
      const exactBrandMatch = brands.find(brand => 
        brand.name.toLowerCase() === query
      );
      
      // If it's an exact brand match, redirect to brand-specific endpoint
      if (exactBrandMatch) {
        const tires = await storage.getTiresByBrand(exactBrandMatch.name);
        return res.json(tires);
      } 
      
      // Otherwise process as a regular search
      const tires = await storage.searchTires(req.params.query);
      res.json(tires);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get a single tire by ID
  app.get("/api/tires/:id", async (req: Request, res: Response) => {
    try {
      const tire = await storage.getTireById(Number(req.params.id));
      if (!tire) {
        return res.status(404).json({ message: "Tire not found" });
      }
      res.json(tire);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get all brands
  app.get("/api/brands", async (req: Request, res: Response) => {
    try {
      const brands = await storage.getBrands();
      res.json(brands);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get featured brands
  app.get("/api/brands/featured", async (req: Request, res: Response) => {
    try {
      const brands = await storage.getFeaturedBrands();
      res.json(brands);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get all vendors
  app.get("/api/vendors", async (req: Request, res: Response) => {
    try {
      const vendors = await storage.getVendors();
      res.json(vendors);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get featured vendors
  app.get("/api/vendors/featured", async (req: Request, res: Response) => {
    try {
      const vendors = await storage.getFeaturedVendors();
      res.json(vendors);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get all promotions
  app.get("/api/promotions", async (req: Request, res: Response) => {
    try {
      const promotions = await storage.getActivePromotions();
      res.json(promotions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get all services
  app.get("/api/services", async (req: Request, res: Response) => {
    try {
      const services = await storage.getServices();
      res.json(services);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get all reviews
  app.get("/api/reviews", async (req: Request, res: Response) => {
    try {
      const reviews = await storage.getReviews();
      res.json(reviews);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Create a new review
  app.post("/api/reviews", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { tireId, rating, comment, userVehicle, images } = req.body;
      
      // Validate required fields
      if (!tireId || !rating || !comment) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Validate rating
      if (rating < 1 || rating > 5) {
        return res.status(400).json({ message: "Rating must be between 1 and 5" });
      }
      
      // Check if the tire exists
      const tire = await storage.getTireById(Number(tireId));
      if (!tire) {
        return res.status(404).json({ message: "Tire not found" });
      }
      
      // Create the review
      const newReview = await storage.createReview({
        userId: req.user.id,
        tireId: Number(tireId),
        rating: Number(rating),
        comment,
        userName: req.user.username,
        userVehicle: userVehicle || null,
        images: images || null
      });
      
      res.status(201).json(newReview);
    } catch (error: any) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get reviews by tire ID
  app.get("/api/reviews/tire/:id", async (req: Request, res: Response) => {
    try {
      const reviews = await storage.getReviewsByTireId(Number(req.params.id));
      res.json(reviews);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get reviews by logged-in user
  app.get("/api/reviews/user", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const reviews = await storage.getReviewsByUserId(req.user.id);
      
      // For each review, add the tire information
      const reviewsWithTires = await Promise.all(
        reviews.map(async (review) => {
          const tire = await storage.getTireById(review.tireId);
          return { ...review, tire };
        })
      );
      
      res.json(reviewsWithTires);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Check if a user has purchased a specific tire
  app.get("/api/user/purchased/:tireId", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const tireId = parseInt(req.params.tireId, 10);
      
      if (isNaN(tireId)) {
        return res.status(400).json({ message: "Invalid tire ID" });
      }
      
      const hasPurchased = await storage.hasUserPurchasedTire(req.user.id, tireId);
      
      // Check if user has already reviewed this tire
      const userReviews = await storage.getReviewsByUserId(req.user.id);
      const hasReviewed = userReviews.some(review => review.tireId === tireId);
      
      res.json({ 
        hasPurchased,
        hasReviewed,
        canReview: hasPurchased && !hasReviewed
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Update a review
  app.put("/api/reviews/:id", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const id = parseInt(req.params.id);
      const review = await storage.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      // Ensure the user owns this review
      if (review.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden: You don't have permission to update this review" });
      }
      
      const { rating, comment } = req.body;
      
      // Validate the rating
      if (rating < 1 || rating > 5) {
        return res.status(400).json({ message: "Rating must be between 1 and 5" });
      }
      
      // Update the review
      const updatedReview = await storage.updateReview(id, { rating, comment });
      
      res.json(updatedReview);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Delete a review
  app.delete("/api/reviews/:id", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const id = parseInt(req.params.id);
      const review = await storage.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      // Ensure the user owns this review
      if (review.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden: You don't have permission to delete this review" });
      }
      
      // Delete the review
      const success = await storage.deleteReview(id);
      
      if (success) {
        res.json({ message: "Review deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete review" });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Search vehicles by year, make, model
  app.post("/api/vehicles/search", async (req: Request, res: Response) => {
    try {
      const result = vehicleSearchSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid search parameters" });
      }
      
      const { year, make, model } = result.data;
      const vehicles = await storage.getVehiclesByParams(year, make, model);
      res.json(vehicles);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get cart items for a session
  app.get("/api/cart", async (req: Request, res: Response) => {
    try {
      const sessionId = getSessionId(req);
      const cartItems = await storage.getCartItems(sessionId);
      
      // For each cart item, get the tire details
      const enrichedCartItems = await Promise.all(
        cartItems.map(async (item) => {
          const tire = await storage.getTireById(item.tireId);
          return {
            ...item,
            tire
          };
        })
      );
      
      res.json(enrichedCartItems);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Add item to cart
  app.post("/api/cart/add", async (req: Request, res: Response) => {
    try {
      const sessionId = getSessionId(req);
      const result = insertCartItemSchema.safeParse({
        ...req.body,
        sessionId
      });
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid cart item data" });
      }
      
      // Check if the item already exists in the cart
      const existingItems = await storage.getCartItems(sessionId);
      const existingItem = existingItems.find(item => item.tireId === result.data.tireId);
      
      if (existingItem) {
        // Update the quantity instead of adding a new item
        const updatedItem = await storage.updateCartItemQuantity(
          existingItem.id,
          existingItem.quantity + (result.data.quantity || 1)
        );
        return res.json(updatedItem);
      }
      
      const newCartItem = await storage.addCartItem(result.data);
      res.json(newCartItem);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Update cart item quantity
  app.put("/api/cart/:id", async (req: Request, res: Response) => {
    try {
      const { quantity } = req.body;
      if (typeof quantity !== 'number' || quantity < 1) {
        return res.status(400).json({ message: "Invalid quantity" });
      }
      
      const updatedItem = await storage.updateCartItemQuantity(Number(req.params.id), quantity);
      if (!updatedItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      res.json(updatedItem);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Remove item from cart
  app.delete("/api/cart/:id", async (req: Request, res: Response) => {
    try {
      const success = await storage.removeCartItem(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Clear cart
  app.delete("/api/cart", async (req: Request, res: Response) => {
    try {
      const sessionId = getSessionId(req);
      await storage.clearCart(sessionId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Create Stripe payment intent
  app.post("/api/create-payment-intent", async (req: Request, res: Response) => {
    if (!stripe) {
      // Return a mock payment intent if Stripe is not configured
      return res.json({ 
        clientSecret: "mock_client_secret_" + Date.now(),
        isMock: true 
      });
    }
    
    try {
      const { amount, paymentMethodId } = req.body;
      
      if (!amount || isNaN(amount)) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      const paymentIntentParams: Stripe.PaymentIntentCreateParams = {
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
      };
      
      // If the request is from an authenticated user with a saved payment method
      if (req.isAuthenticated() && paymentMethodId) {
        // Get the payment method from the database
        const paymentMethod = await storage.getPaymentMethodById(Number(paymentMethodId));
        
        if (paymentMethod) {
          // In a real implementation, we would use a Stripe Customer ID and a stored Stripe PaymentMethod
          // For this demo, we'll just add some metadata to the payment intent
          paymentIntentParams.metadata = {
            paymentMethodId: paymentMethod.id.toString(),
            lastFourDigits: paymentMethod.lastFourDigits,
            cardholderName: paymentMethod.cardholderName
          };
        }
      }
      
      const paymentIntent = await stripe.paymentIntents.create(paymentIntentParams);
      
      res.json({ 
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });
  
  // Payment Methods API
  
  // Get user's payment methods
  app.get("/api/payment-methods", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.user.id;
      const paymentMethods = await storage.getPaymentMethods(userId);
      
      // Remove sensitive data before sending to client
      const sanitizedPaymentMethods = paymentMethods.map(pm => ({
        id: pm.id,
        cardholderName: pm.cardholderName,
        cardType: pm.cardType,
        lastFourDigits: pm.lastFourDigits,
        expiryMonth: pm.expiryMonth,
        expiryYear: pm.expiryYear,
        isDefault: pm.isDefault,
        createdAt: pm.createdAt
      }));
      
      res.json(sanitizedPaymentMethods);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Add new payment method
  app.post("/api/payment-methods", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Validate with the payment method schema
      const validationResult = paymentMethodSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid payment method data",
          errors: validationResult.error.format()
        });
      }
      
      const { cardholderName, cardNumber, expiryMonth, expiryYear, cvv } = req.body;
      
      // Determine card type based on first digits
      let cardType = "unknown";
      if (/^4/.test(cardNumber)) {
        cardType = "visa";
      } else if (/^5[1-5]/.test(cardNumber)) {
        cardType = "mastercard";
      } else if (/^3[47]/.test(cardNumber)) {
        cardType = "amex";
      } else if (/^6(?:011|5)/.test(cardNumber)) {
        cardType = "discover";
      }
      
      // Only store the last 4 digits of the card number
      const lastFourDigits = cardNumber.slice(-4);
      
      // Create payment method
      const newPaymentMethod = await storage.addPaymentMethod({
        userId: req.user.id,
        cardholderName,
        cardType,
        lastFourDigits,
        expiryMonth,
        expiryYear,
        isDefault: req.body.isDefault || false
      });
      
      // Remove sensitive data before sending response
      const { userId, ...paymentMethodResponse } = newPaymentMethod;
      
      res.status(201).json(paymentMethodResponse);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Update payment method
  app.put("/api/payment-methods/:id", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const paymentMethodId = Number(req.params.id);
      const userId = req.user.id;
      
      // Verify the payment method belongs to this user
      const existingPaymentMethod = await storage.getPaymentMethodById(paymentMethodId);
      if (!existingPaymentMethod) {
        return res.status(404).json({ message: "Payment method not found" });
      }
      
      if (existingPaymentMethod.userId !== userId) {
        return res.status(403).json({ message: "You do not have permission to update this payment method" });
      }
      
      // Update the payment method
      const updatedPaymentMethod = await storage.updatePaymentMethod(paymentMethodId, req.body);
      
      // Remove sensitive data before sending response
      const { userId: _, ...paymentMethodResponse } = updatedPaymentMethod;
      
      res.json(paymentMethodResponse);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Delete payment method
  app.delete("/api/payment-methods/:id", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const paymentMethodId = Number(req.params.id);
      const userId = req.user.id;
      
      // Verify the payment method belongs to this user
      const existingPaymentMethod = await storage.getPaymentMethodById(paymentMethodId);
      if (!existingPaymentMethod) {
        return res.status(404).json({ message: "Payment method not found" });
      }
      
      if (existingPaymentMethod.userId !== userId) {
        return res.status(403).json({ message: "You do not have permission to delete this payment method" });
      }
      
      // Delete the payment method
      const success = await storage.deletePaymentMethod(paymentMethodId);
      if (!success) {
        return res.status(500).json({ message: "Failed to delete payment method" });
      }
      
      res.json({ success: true, message: "Payment method deleted" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Set a payment method as default
  app.post("/api/payment-methods/:id/set-default", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const paymentMethodId = Number(req.params.id);
      const userId = req.user.id;
      
      // Verify the payment method belongs to this user
      const existingPaymentMethod = await storage.getPaymentMethodById(paymentMethodId);
      if (!existingPaymentMethod) {
        return res.status(404).json({ message: "Payment method not found" });
      }
      
      if (existingPaymentMethod.userId !== userId) {
        return res.status(403).json({ message: "You do not have permission to update this payment method" });
      }
      
      // Set as default
      const success = await storage.setDefaultPaymentMethod(paymentMethodId, userId);
      if (!success) {
        return res.status(500).json({ message: "Failed to set payment method as default" });
      }
      
      res.json({ success: true, message: "Payment method set as default" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create an order
  app.post("/api/order", async (req: Request, res: Response) => {
    try {
      const sessionId = getSessionId(req);
      const { totalAmount, customerEmail, customerName, shippingAddress, paymentIntentId, status } = req.body;
      
      if (!totalAmount || !customerEmail || !customerName || !shippingAddress) {
        return res.status(400).json({ message: "Missing required order fields" });
      }
      
      // Add userId to order if user is authenticated
      const userId = req.isAuthenticated() ? (req.user as User).id : null;
      
      const order = await storage.createOrder({
        sessionId,
        totalAmount,
        customerEmail,
        customerName,
        shippingAddress,
        paymentIntentId,
        status: status || "pending", // Use the provided status or default to pending
        userId
      });
      
      // Clear the cart after creating the order
      await storage.clearCart(sessionId);
      
      res.json(order);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get orders for the current authenticated user
  app.get("/api/orders", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = (req.user as User).id;
      const orders = await storage.getOrdersByUserId(userId);
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get order details by ID
  app.get("/api/orders/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const orderId = parseInt(req.params.id);
      const userId = (req.user as User).id;
      
      const order = await storage.getOrderById(orderId);
      
      // Ensure users can only access their own orders
      if (!order || (order.userId && order.userId !== userId)) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Track order endpoint - public, doesn't require authentication
  app.post("/api/orders/track", async (req: Request, res: Response) => {
    try {
      const { orderNumber, email } = req.body;
      
      if (!orderNumber || !email) {
        return res.status(400).json({ message: "Order number and email are required" });
      }
      
      // For the prototype, we'll use the order ID as the order number
      // Extract the numeric part from TH-00001 format
      const orderId = parseInt(orderNumber.replace(/^TH-0*/, '').replace(/\D/g, ''));
      
      // Check if order exists
      const order = await storage.getOrderById(orderId);
      
      if (!order || (order.customerEmail && order.customerEmail !== email)) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Enhance order data with tracking details
      const trackingDetails = {
        id: order.id,
        status: order.status || "pending",
        customerName: order.customerName || "Guest User",
        createdAt: order.createdAt?.toISOString() || new Date().toISOString(),
        estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        items: [
          {
            name: "Michelin Defender LTX",
            quantity: 4,
            price: (parseInt(order.totalAmount) / 4).toFixed(2),
          }
        ],
        trackingNumber: (order.status === "shipped" || order.status === "delivered") ? "TRK" + Math.floor(1000000 + Math.random() * 9000000) : undefined,
        shippingAddress: order.shippingAddress || "123 Main St, Anytown, CA 12345",
        totalAmount: order.totalAmount,
        lastUpdated: new Date().toISOString(),
        statusHistory: [
          {
            status: "pending",
            timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
            description: "Order received and is being prepared for processing."
          }
        ]
      };
      
      // Add status history based on current status
      if (order.status === "processing" || order.status === "shipped" || order.status === "delivered") {
        trackingDetails.statusHistory.push({
          status: "processing",
          timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          description: "Your order is being processed and prepared for shipment."
        });
      }
      
      if (order.status === "shipped" || order.status === "delivered") {
        trackingDetails.statusHistory.push({
          status: "shipped",
          timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
          description: "Your order has been shipped and is on its way to you."
        });
      }
      
      if (order.status === "delivered") {
        trackingDetails.statusHistory.push({
          status: "delivered",
          timestamp: new Date().toISOString(),
          description: "Your order has been delivered. Thank you for shopping with us!"
        });
      }
      
      if (order.status === "cancelled") {
        trackingDetails.statusHistory.push({
          status: "cancelled",
          timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
          description: "Your order has been cancelled. Please contact customer support for more information."
        });
      }
      
      res.json(trackingDetails);
    } catch (error) {
      console.error("Error tracking order:", error);
      res.status(500).json({ message: "An error occurred while tracking the order" });
    }
  });
  
  // Set tracking number for an order
  app.post("/api/orders/:id/tracking", async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      const { trackingNumber } = req.body;
      
      if (!trackingNumber) {
        return res.status(400).json({ message: "Tracking number is required" });
      }
      
      // Get the order
      const order = await storage.getOrderById(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Update the order with the tracking number
      // Since we don't have a specific field for tracking number in our schema yet,
      // we'll just acknowledge the request for now
      // In a real implementation, we would store this in the database
      
      res.sendStatus(200);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Upload image for search by photo
  app.post("/api/search/photo", async (req: Request, res: Response) => {
    // In a real implementation, this would process the image and extract tire information
    // For this MVP, we'll return a subset of tires as search results
    try {
      const tires = await storage.getTires();
      const searchResults = tires.slice(0, 3); // Just return the first 3 tires
      res.json(searchResults);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Wishlist Routes

  // Get all wishlist items for a user
  app.get("/api/wishlist", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.user.id;
      const wishlistItems = await storage.getWishlistItems(userId);
      
      res.json(wishlistItems);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Add item to wishlist
  app.post("/api/wishlist/add", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.user.id;
      const result = insertWishlistItemSchema.safeParse({
        ...req.body,
        userId
      });
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid wishlist item data",
          errors: result.error.format()
        });
      }
      
      // Check if the tire exists
      const tire = await storage.getTireById(result.data.tireId);
      if (!tire) {
        return res.status(404).json({ message: "Tire not found" });
      }
      
      // Check if already in wishlist
      const existingItem = await storage.getWishlistItemByUserAndTire(userId, result.data.tireId);
      if (existingItem) {
        return res.status(200).json({ 
          message: "Item already in wishlist",
          wishlistItem: {
            ...existingItem,
            tire
          }
        });
      }
      
      // Add to wishlist
      const newWishlistItem = await storage.addWishlistItem(result.data);
      
      res.status(201).json({
        ...newWishlistItem,
        tire
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Remove item from wishlist
  app.delete("/api/wishlist/:id", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.user.id;
      const wishlistItemId = Number(req.params.id);
      
      // Verify the wishlist item belongs to this user
      const wishlistItem = await storage.getWishlistItemById(wishlistItemId);
      if (!wishlistItem) {
        return res.status(404).json({ message: "Wishlist item not found" });
      }
      
      if (wishlistItem.userId !== userId) {
        return res.status(403).json({ message: "You do not have permission to remove this item" });
      }
      
      const success = await storage.removeWishlistItem(wishlistItemId);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to remove item from wishlist" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Clear wishlist
  app.delete("/api/wishlist", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.user.id;
      const success = await storage.clearWishlist(userId);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to clear wishlist" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // ===== ADMIN ROUTES =====
  
  // Get all pending reviews (for moderation)
  app.get("/api/admin/reviews/pending", isAdmin, async (req: Request, res: Response) => {
    try {
      const pendingReviews = await storage.getPendingReviews();
      
      // Enhance reviews with tire names where applicable
      const enhancedReviews = await Promise.all(pendingReviews.map(async (review) => {
        if (review.tireId) {
          const tire = await storage.getTireById(review.tireId);
          if (tire) {
            return {
              ...review,
              tireName: tire.name
            };
          }
        }
        return review;
      }));
      
      res.json(enhancedReviews);
    } catch (error: any) {
      console.error("Error retrieving pending reviews:", error);
      res.status(500).json({ message: error.message || "Error retrieving pending reviews" });
    }
  });
  
  // Approve or reject a review
  app.put("/api/admin/reviews/:id/moderate", isAdmin, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { status, moderationNotes } = req.body;
      
      if (!status || !['approved', 'rejected', 'pending'].includes(status)) {
        return res.status(400).json({ message: "Status must be one of: approved, rejected, pending" });
      }
      
      const review = await storage.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      // Update the review with new status format
      const isApproved = status === 'approved';
      const isRejected = status === 'rejected';
      
      const updatedReview = await storage.updateReviewModeration(id, { 
        isApproved, 
        isRejected,
        moderationNotes: moderationNotes || null 
      });
      
      res.json(updatedReview);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Admin: Suspend user account
  app.put("/api/admin/users/:id/suspend", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get the user to ensure they exist
      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't allow admins to suspend other admins
      if (user.role === 'admin' && req.user.id !== userId) {
        return res.status(403).json({ message: "Cannot suspend admin accounts" });
      }
      
      // Update the user's status to suspended
      const updatedUser = await storage.updateUser(userId, { status: 'suspended' });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to suspend user account" });
      }
      
      return res.status(200).json({ 
        message: "User account suspended successfully", 
        user: { id: updatedUser.id, username: updatedUser.username, status: updatedUser.status }
      });
    } catch (error: any) {
      console.error("Error suspending user:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Admin: Activate user account
  app.put("/api/admin/users/:id/activate", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get the user to ensure they exist
      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update the user's status to active
      const updatedUser = await storage.updateUser(userId, { status: 'active' });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to activate user account" });
      }
      
      return res.status(200).json({ 
        message: "User account activated successfully", 
        user: { id: updatedUser.id, username: updatedUser.username, status: updatedUser.status }
      });
    } catch (error: any) {
      console.error("Error activating user:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Admin: Delete user account
  app.delete("/api/admin/users/:id", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get the user to ensure they exist
      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't allow admins to delete other admins
      if (user.role === 'admin' && req.user.id !== userId) {
        return res.status(403).json({ message: "Cannot delete admin accounts" });
      }
      
      // Delete the user
      const success = await storage.deleteUser(userId);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to delete user account" });
      }
      
      return res.status(200).json({ message: "User account deleted successfully" });
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // Get all orders with detailed information for admin
  app.get("/api/admin/orders", isAdmin, async (req: Request, res: Response) => {
    try {
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Update order status and shipping information
  app.put("/api/admin/orders/:id", isAdmin, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { 
        status, 
        trackingNumber, 
        carrier, 
        estimatedDeliveryDate,
        shippingNotes 
      } = req.body;
      
      const order = await storage.getOrderById(id);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Validate the status
      const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
      if (status && !validStatuses.includes(status)) {
        return res.status(400).json({ 
          message: `Invalid status. Must be one of: ${validStatuses.join(', ')}` 
        });
      }
      
      // Update the order
      const updatedOrder = await storage.updateOrderShipping(id, {
        status: status || order.status,
        trackingNumber: trackingNumber || order.trackingNumber,
        carrier: carrier || order.carrier,
        estimatedDeliveryDate: estimatedDeliveryDate 
          ? new Date(estimatedDeliveryDate) 
          : order.estimatedDeliveryDate,
        shippingNotes: shippingNotes || order.shippingNotes,
        lastUpdated: new Date()
      });
      
      res.json(updatedOrder);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Admin - Get all users
  app.get("/api/users", isAdmin, async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsers();
      // Remove sensitive information
      const safeUsers = users.map(user => {
        const { password, resetToken, resetTokenExpiry, ...safeUser } = user;
        return safeUser;
      });
      res.json(safeUsers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Admin - Get dashboard metrics
  app.get("/api/admin/dashboard", isAdmin, async (req: Request, res: Response) => {
    try {
      // Get counts from various collections
      const [tires, users, orders, reviews] = await Promise.all([
        storage.getTires(),
        storage.getUsers(),
        storage.getOrders(),
        storage.getReviews()
      ]);
      
      // Calculate metrics
      const totalTires = tires.length;
      const featuredTires = tires.filter(tire => tire.isFeatured).length;
      const onSaleTires = tires.filter(tire => tire.discountedPrice).length;
      const lowStockTires = tires.filter(tire => tire.stock < 10).length;
      
      const totalUsers = users.length;
      const activeUsers = users.filter(user => user.status === 'active').length;
      const newUsers = users.filter(user => {
        const createdAt = new Date(user.createdAt);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        return createdAt > thirtyDaysAgo;
      }).length;
      
      const totalOrders = orders.length;
      const pendingOrders = orders.filter(order => order.status === 'pending').length;
      const processingOrders = orders.filter(order => order.status === 'processing').length;
      const shippedOrders = orders.filter(order => order.status === 'shipped').length;
      const deliveredOrders = orders.filter(order => order.status === 'delivered').length;
      const cancelledOrders = orders.filter(order => order.status === 'cancelled').length;
      
      const totalReviews = reviews.length;
      const pendingReviews = reviews.filter(review => !review.isApproved && !review.isRejected).length;
      const approvedReviews = reviews.filter(review => review.isApproved).length;
      const rejectedReviews = reviews.filter(review => review.isRejected).length;
      
      // Calculate average rating
      let averageRating = 0;
      if (reviews.length > 0) {
        const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
        averageRating = sum / reviews.length;
      }
      
      // Calculate total sales
      let totalSales = 0;
      let todaySales = 0;
      let weeklySales = 0;
      let monthlySales = 0;
      let ytdSales = 0;
      
      // Set up date references
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
      
      const startOfYear = new Date(today.getFullYear(), 0, 1);
      
      // Calculate the sales totals
      orders.forEach(order => {
        const orderAmount = parseFloat(order.totalAmount);
        if (!isNaN(orderAmount)) {
          totalSales += orderAmount;
          
          const orderDate = new Date(order.createdAt);
          
          if (orderDate >= today) {
            todaySales += orderAmount;
          }
          
          if (orderDate >= oneWeekAgo) {
            weeklySales += orderAmount;
          }
          
          if (orderDate >= oneMonthAgo) {
            monthlySales += orderAmount;
          }
          
          if (orderDate >= startOfYear) {
            ytdSales += orderAmount;
          }
        }
      });
      
      // Get top selling products
      const productSales = new Map();
      orders.forEach(order => {
        if (order.items && Array.isArray(order.items)) {
          order.items.forEach(item => {
            if (item.tireId) {
              const productId = item.tireId;
              const quantity = item.quantity || 1;
              
              if (productSales.has(productId)) {
                productSales.set(productId, productSales.get(productId) + quantity);
              } else {
                productSales.set(productId, quantity);
              }
            }
          });
        }
      });
      
      // Sort products by sales and get the top 5
      const topProductIds = Array.from(productSales.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(entry => entry[0]);
      
      // Get product details for the top products
      const topProducts = await Promise.all(
        topProductIds.map(async (id) => {
          const tire = await storage.getTireById(id);
          return {
            id,
            name: tire?.name || 'Unknown Product',
            brand: tire?.brand || 'Unknown Brand',
            sales: productSales.get(id),
            price: tire?.price || '$0.00'
          };
        })
      );
      
      // Get recent orders
      const recentOrders = orders
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5)
        .map(order => ({
          id: order.id,
          date: new Date(order.createdAt).toLocaleDateString(),
          customerName: order.customerName || 'Guest Customer',
          total: order.totalAmount,
          status: order.status
        }));
      
      // Compile all metrics
      const metrics = {
        sales: {
          total: parseFloat(totalSales.toFixed(2)),
          today: parseFloat(todaySales.toFixed(2)),
          week: parseFloat(weeklySales.toFixed(2)),
          month: parseFloat(monthlySales.toFixed(2)),
          yearToDate: parseFloat(ytdSales.toFixed(2))
        },
        products: {
          total: totalTires,
          featured: featuredTires,
          onSale: onSaleTires,
          lowStock: lowStockTires
        },
        users: {
          total: totalUsers,
          active: activeUsers,
          new: newUsers
        },
        orders: {
          total: totalOrders,
          pending: pendingOrders,
          processing: processingOrders,
          shipped: shippedOrders,
          delivered: deliveredOrders,
          cancelled: cancelledOrders
        },
        reviews: {
          total: totalReviews,
          pending: pendingReviews,
          approved: approvedReviews,
          rejected: rejectedReviews,
          averageRating: parseFloat(averageRating.toFixed(1))
        },
        topProducts,
        recentOrders
      };
      
      res.json(metrics);
    } catch (error: any) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

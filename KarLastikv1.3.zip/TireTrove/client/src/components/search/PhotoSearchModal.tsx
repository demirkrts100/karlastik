import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Upload, X } from 'lucide-react';
import { useLocation } from 'wouter';
import { useSearch } from '@/contexts/SearchContext';
import { apiRequest } from '@/lib/queryClient';

interface PhotoSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PhotoSearchModal = ({ isOpen, onClose }: PhotoSearchModalProps) => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { setSearchResults } = useSearch();
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const uploadedFile = e.dataTransfer.files[0];
      if (uploadedFile.type.startsWith('image/')) {
        setFile(uploadedFile);
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please upload an image file",
          variant: "destructive",
        });
      }
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };
  
  const handleSearch = async () => {
    if (!file) {
      toast({
        title: "No Image Selected",
        description: "Please upload an image of your tire",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    
    try {
      // Create form data to send the image
      const formData = new FormData();
      formData.append('image', file);
      
      // In a real application, this would upload the image and analyze it
      // For this implementation, we'll just fetch some sample tire results
      const response = await fetch('/api/search/photo', {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error('Failed to process image');
      }
      
      const results = await response.json();
      
      // Store results in search context
      setSearchResults(results);
      
      // Close modal and navigate to results
      onClose();
      setLocation('/products');
      
      toast({
        title: "Image Processed Successfully",
        description: `Found ${results.length} matching tires`,
      });
    } catch (error) {
      toast({
        title: "Search Failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  const resetFile = () => {
    setFile(null);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Search by Tire Photo</DialogTitle>
          <DialogDescription>
            Take a clear photo of your tire sidewall where the size is printed. Our system will identify the tire details.
          </DialogDescription>
        </DialogHeader>
        
        {file ? (
          <div className="mb-4">
            <div className="relative">
              <img 
                src={URL.createObjectURL(file)} 
                alt="Uploaded tire" 
                className="w-full h-48 object-contain border rounded-lg"
              />
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute top-2 right-2 bg-white/80 hover:bg-white text-neutral-500"
                onClick={resetFile}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-neutral-500 mt-2 truncate">
              {file.name} ({(file.size / 1024).toFixed(0)} KB)
            </p>
          </div>
        ) : (
          <div 
            className={`search-by-photo-drop rounded-lg p-8 mb-4 text-center cursor-pointer ${isDragging ? 'border-primary bg-primary/5' : ''}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => document.getElementById('file-upload')?.click()}
          >
            <Upload className="h-10 w-10 text-neutral-400 mx-auto mb-3" />
            <p className="text-neutral-600 mb-1">Drag and drop your photo here</p>
            <p className="text-neutral-500 text-sm">or</p>
            <Button 
              type="button" 
              className="mt-3 bg-primary hover:bg-primary/90 text-white font-medium"
            >
              Browse Files
            </Button>
            <input 
              id="file-upload" 
              type="file" 
              className="hidden" 
              accept="image/*"
              onChange={handleFileChange}
            />
          </div>
        )}
        
        <DialogFooter className="flex justify-end space-x-2">
          <Button 
            variant="outline" 
            onClick={onClose} 
            className="text-neutral-700 font-medium border-neutral-300 hover:bg-neutral-50"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSearch} 
            className="bg-primary hover:bg-primary/90 text-white font-medium"
            disabled={!file || isUploading}
          >
            {isUploading ? "Processing..." : "Search"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

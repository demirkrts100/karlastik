import {
  Tire,
  InsertTire,
  Vendor,
  InsertVendor,
  Brand,
  InsertBrand,
  Review,
  InsertReview,
  CartItem,
  InsertCartItem,
  Service,
  InsertService,
  Promotion,
  InsertPromotion,
  Order,
  InsertOrder,
  Vehicle,
  InsertVehicle,
  User,
  InsertUser,
  PaymentMethod,
  InsertPaymentMethod,
  WishlistItem,
  InsertWishlistItem,
} from "@shared/schema";
import { hashPassword } from "./auth";

// Modify the interface with any CRUD methods needed
export interface IStorage {
  // Tires
  getTires(): Promise<Tire[]>;
  getTireById(id: number): Promise<Tire | undefined>;
  getTiresByType(type: string): Promise<Tire[]>;
  getTiresByBrand(brand: string): Promise<Tire[]>;
  getTiresByVendor(vendorId: number): Promise<Tire[]>;
  getFeaturedTires(): Promise<Tire[]>;
  searchTires(query: string): Promise<Tire[]>;
  createTire(tire: InsertTire): Promise<Tire>;
  
  // Vendors
  getVendors(): Promise<Vendor[]>;
  getVendorById(id: number): Promise<Vendor | undefined>;
  getFeaturedVendors(): Promise<Vendor[]>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;
  
  // Brands
  getBrands(): Promise<Brand[]>;
  getBrandById(id: number): Promise<Brand | undefined>;
  getFeaturedBrands(): Promise<Brand[]>;
  createBrand(brand: InsertBrand): Promise<Brand>;
  
  // Reviews
  getReviews(): Promise<Review[]>;
  getReviewById(id: number): Promise<Review | undefined>;
  getReviewsByTireId(tireId: number): Promise<Review[]>;
  getReviewsByVendorId(vendorId: number): Promise<Review[]>;
  getReviewsByUserId(userId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: number, reviewData: Partial<InsertReview>): Promise<Review | undefined>;
  deleteReview(id: number): Promise<boolean>;
  
  // Cart Items
  getCartItems(sessionId: string): Promise<CartItem[]>;
  addCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;
  
  // Services
  getServices(): Promise<Service[]>;
  getServiceById(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  
  // Promotions
  getPromotions(): Promise<Promotion[]>;
  getActivePromotions(): Promise<Promotion[]>;
  createPromotion(promotion: InsertPromotion): Promise<Promotion>;
  
  // Orders
  getOrders(): Promise<Order[]>;
  getOrderById(id: number): Promise<Order | undefined>;
  getOrdersBySessionId(sessionId: string): Promise<Order[]>;
  getOrdersByUserId(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Vehicles
  getVehicles(): Promise<Vehicle[]>;
  getVehiclesByParams(year: string, make: string, model: string): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  
  // Users
  getUsers(): Promise<User[]>;
  getUserById(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  setResetToken(email: string, token: string, expiryHours: number): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // Payment Methods
  getPaymentMethods(userId: number): Promise<PaymentMethod[]>;
  getPaymentMethodById(id: number): Promise<PaymentMethod | undefined>;
  addPaymentMethod(paymentMethod: InsertPaymentMethod): Promise<PaymentMethod>;
  updatePaymentMethod(id: number, paymentMethod: Partial<InsertPaymentMethod>): Promise<PaymentMethod | undefined>;
  deletePaymentMethod(id: number): Promise<boolean>;
  setDefaultPaymentMethod(id: number, userId: number): Promise<boolean>;
  
  // Wishlist Items
  getWishlistItems(userId: number): Promise<(WishlistItem & { tire: Tire })[]>;
  getWishlistItemById(id: number): Promise<WishlistItem | undefined>;
  getWishlistItemByUserAndTire(userId: number, tireId: number): Promise<WishlistItem | undefined>;
  addWishlistItem(wishlistItem: InsertWishlistItem): Promise<WishlistItem>;
  removeWishlistItem(id: number): Promise<boolean>;
  clearWishlist(userId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private tires: Map<number, Tire>;
  private vendors: Map<number, Vendor>;
  private brands: Map<number, Brand>;
  private reviews: Map<number, Review>;
  private cartItems: Map<number, CartItem>;
  private services: Map<number, Service>;
  private promotions: Map<number, Promotion>;
  private orders: Map<number, Order>;
  private vehicles: Map<number, Vehicle>;
  private users: Map<number, User>;
  private paymentMethods: Map<number, PaymentMethod>;
  private wishlistItems: Map<number, WishlistItem>;
  
  private tireId: number;
  private vendorId: number;
  private brandId: number;
  private reviewId: number;
  private cartItemId: number;
  private serviceId: number;
  private promotionId: number;
  private orderId: number;
  private vehicleId: number;
  private userId: number;
  private paymentMethodId: number;
  private wishlistItemId: number;

  constructor() {
    this.tires = new Map();
    this.vendors = new Map();
    this.brands = new Map();
    this.reviews = new Map();
    this.cartItems = new Map();
    this.services = new Map();
    this.promotions = new Map();
    this.orders = new Map();
    this.vehicles = new Map();
    this.users = new Map();
    this.paymentMethods = new Map();
    this.wishlistItems = new Map();
    
    this.tireId = 1;
    this.vendorId = 1;
    this.brandId = 1;
    this.reviewId = 1;
    this.cartItemId = 1;
    this.serviceId = 1;
    this.promotionId = 1;
    this.orderId = 1;
    this.vehicleId = 1;
    this.userId = 1;
    this.paymentMethodId = 1;
    this.wishlistItemId = 1;
    
    // We call seedData but we can't await it in the constructor
    // so we handle any errors that might occur
    this.seedData().catch(err => {
      console.error("Error seeding data:", err);
    });
  }

  // Seed initial data
  private async seedData() {
    // Seed admin user
    const adminPassword = await hashPassword("Admin@123");
    const adminUser = {
      username: "admin",
      email: "admin@tirehub.com",
      password: adminPassword,
      firstName: "Admin",
      lastName: "User",
      role: "admin"
    };
    
    // Check if admin already exists
    const existingAdmin = await this.getUserByUsername("admin");
    if (!existingAdmin) {
      await this.createUser(adminUser);
      console.log("Admin user created");
    }
    
    // Seed vendors
    const vendors = [
      {
        name: "Michelin Authorized Dealer",
        description: "Premium tires for every vehicle type",
        imageUrl: "https://pixabay.com/get/g066dfaf4f30a07a22896f08ac135a4180ccd59a95dfa97c06407649e102d55eb0ae6dc0031c626e99df5c4974569e6476961a50017ccaf2449f51feb1eb958c2_1280.jpg",
        rating: 5.0,
        reviewCount: 246,
        isFeatured: true
      },
      {
        name: "Off-Road Specialists",
        description: "Rugged tires for adventure vehicles",
        imageUrl: "https://pixabay.com/get/gc4e3e3d6451e134852509a4a57a6fee5db78de08188f9fbfa4fdfcc8fdad60db574f12c9cf41c4ae62d34421f248f783e201de8f9b49576b2f387579fe981265_1280.jpg",
        rating: 4.5,
        reviewCount: 182,
        isFeatured: true
      },
      {
        name: "Performance Tire Center",
        description: "High-performance tires for sport vehicles",
        imageUrl: "https://pixabay.com/get/g74cc0bd34db8a89fd77d67cf9ecae5c7e3de051bfacc41b647ab9e53e68be08c7ec62e0ad98c0eeb8b20a13a73a87e8eb5bdd2a1c4aafc49d9bb389e7f52a4a0_1280.jpg",
        rating: 4.0,
        reviewCount: 128,
        isFeatured: true
      }
    ];
    
    vendors.forEach(vendor => this.createVendor(vendor));

    // Seed brands
    const brands = [
      {
        name: "Michelin",
        logoUrl: "https://pixabay.com/get/g7805861bd0d65b2a02c07b3c7b063fc491b59639edc910ea4ec6b9606c15d78d9beeeba194272c3dba3818262cbc23da8cb97456c7ecbe911cc88322d2b48563_1280.jpg",
        isFeatured: true
      },
      {
        name: "Goodyear",
        logoUrl: "https://pixabay.com/get/g952975c95d3b46b6030660fd1dfccdd1330efb5702e82969c251696f176b831da1e2a3b751e692b77e9c23c99abc7cc80fe2c3eb5ae1ba7fd348fc0f00a1bdd3_1280.jpg",
        isFeatured: true
      },
      {
        name: "Bridgestone",
        logoUrl: "https://pixabay.com/get/gd68cf48b4ffbad0c9c4a3b1abb03bc29cef85c09e9b2ae8bd4e54c20b2f91c08fdd4aed02d7c38d071fe14bb96e1ca407f85b5d0aa5a3a02c5f4ae2c52bafb85_1280.jpg",
        isFeatured: true
      },
      {
        name: "Continental",
        logoUrl: "https://pixabay.com/get/gac90c79f471eee8e01ec3b2f708a6ee805c24f97e9cbd5738ff13840935728327e1f5c8d607af55a57adc0688c0c9aeedc1894985ccc459b20909d9443917bb7_1280.jpg",
        isFeatured: true
      },
      {
        name: "Pirelli",
        logoUrl: "https://pixabay.com/get/gb145672322d4b3f1b701677ee46dc3ef2cd310e5a10c66eb8e98f821581d457b5e3ff3f26e226ebbaac89e1d3903047fe353995babd86f76cd1ebf689fd5face_1280.jpg",
        isFeatured: true
      },
      {
        name: "Dunlop",
        logoUrl: "https://pixabay.com/get/gd6ac14b2e2c0c07ef5f19c1c0c49d1cae4d78f64d2d97b4e9fef7db5a05a5bb9dd7fb6ed78f9c9b49ab9d0a9a43ea9ad22fa60e9a7a7e2d9cfdf8e1a75f74452_1280.jpg",
        isFeatured: true
      }
    ];
    
    brands.forEach(brand => this.createBrand(brand));

    // Seed tires
    const tires = [
      {
        name: "Michelin Defender LTX",
        description: "All-Season Highway Truck/SUV Tire",
        price: "174.99",
        imageUrl: "https://pixabay.com/get/gf9e3a6edf72356a4cd9f987ac98a2426c63ef7138ed562c4bfe869f6a25a89207ae2ea6a340387c54cc27670a4830003ce569eb4c5a25351a3c0c0eb99d05e41_1280.jpg",
        size: "265/70R17",
        type: "all-season",
        brand: "Michelin",
        vendorId: 1,
        isFeatured: true,
        stock: 50,
        rating: 4.5,
        reviewCount: 246,
        isBestSeller: true,
        tags: ["truck", "suv", "highway"]
      },
      {
        name: "Bridgestone Blizzak WS90",
        description: "Winter Performance Passenger Tire",
        price: "159.99",
        discountedPrice: "135.99",
        imageUrl: "https://pixabay.com/get/g59aef71a667c005041c557b8692e58c4d17c9e1a16269bf6eb0b15e708a8c2cc460b577242ba73d21e5e384674beaf91fca48e4b325b5e01e4800bd3e8da56fb_1280.jpg",
        size: "215/55R17",
        type: "winter",
        brand: "Bridgestone",
        vendorId: 2,
        isFeatured: true,
        stock: 35,
        rating: 5.0,
        reviewCount: 182,
        hasPromo: true,
        promoText: "SAVE 15%",
        tags: ["winter", "snow", "passenger"]
      },
      {
        name: "Pirelli P Zero",
        description: "Ultra High Performance Summer Tire",
        price: "249.99",
        imageUrl: "https://pixabay.com/get/ga97a3f37cdc2a3fa39a44eb9bea44bddf5b9e9d4e49e6ddf9f46c09bbef85acfaf31b6c1dee88c35aabaa32f5be1f59d7dbbcf0fb56e99edcad254e40c9a79c9_1280.jpg",
        size: "245/40R19",
        type: "performance",
        brand: "Pirelli",
        vendorId: 3,
        isFeatured: true,
        stock: 20,
        rating: 4.0,
        reviewCount: 128,
        isNewArrival: true,
        tags: ["performance", "summer", "sports"]
      },
      {
        name: "BF Goodrich All-Terrain T/A KO2",
        description: "All-Terrain Off-Road Truck Tire",
        price: "199.99",
        imageUrl: "https://pixabay.com/get/gad44f5cd2a6a3cc2ee7d32505b1c4dabb52fa9d4a32bb599a33b31cdcad841f95b498e9c456ee6cd5e4afed86a793e2a2bd666b02eed4eb7c39c360e36403088_1280.jpg",
        size: "275/70R17",
        type: "all-terrain",
        brand: "BF Goodrich",
        vendorId: 2,
        isFeatured: true,
        stock: 15,
        rating: 4.5,
        reviewCount: 312,
        hasPromo: true,
        promoText: "LIMITED STOCK",
        tags: ["off-road", "truck", "all-terrain"]
      },
      {
        name: "Goodyear Assurance All-Season",
        description: "All-Season Passenger Tire",
        price: "89.99",
        imageUrl: "https://pixabay.com/get/g3e2f24d09b9e167fb9e19d55e5cae28cd56b4085e0c6e742ce99152cef0ab2d09669132c7301032359d1a1a7bb4f11b36399be517b64099d30a5b257ec9166c9_1280.jpg",
        size: "205/65R16",
        type: "all-season",
        brand: "Goodyear",
        vendorId: 1,
        isFeatured: true,
        stock: 60,
        rating: 4.0,
        reviewCount: 174,
        hasPromo: true,
        promoText: "VALUE PICK",
        tags: ["budget", "all-season", "passenger"]
      },
      {
        name: "Continental PureContact LS",
        description: "Grand Touring All-Season Tire",
        price: "149.99",
        discountedPrice: "134.99",
        imageUrl: "https://pixabay.com/get/g5c665efaae85be0c6a923938242ee387dfcd1dafbdd214a1615508d783ba2123ece831811f87bd8affcdef5d9c46da7639dd239be148770544dc582ab0c91a5d_1280.jpg",
        size: "225/50R17",
        type: "all-season",
        brand: "Continental",
        vendorId: 3,
        isFeatured: true,
        stock: 45,
        rating: 4.5,
        reviewCount: 156,
        hasPromo: true,
        promoText: "SAVE 10%",
        tags: ["touring", "all-season", "passenger"]
      }
    ];
    
    // Add more tire products
    const additionalTires = [
      {
        name: "Michelin CrossClimate 2",
        description: "All-Weather Passenger Tire",
        price: "189.99",
        imageUrl: "https://pixabay.com/get/gfc71c9eeab43fe0fc2d889f08b63db5db43df5de4ca9f9cec6d45444b45c35d85f2cc5ea41ae272aca1452f70c8bea0b2f54ac3cb31adb98a1fe6d67c2b5ec4e_1280.jpg",
        size: "215/60R16",
        type: "all-season",
        brand: "Michelin",
        vendorId: 1,
        isFeatured: true,
        stock: 42,
        rating: 4.8,
        reviewCount: 215,
        isNewArrival: true,
        tags: ["all-weather", "passenger", "rain"]
      },
      {
        name: "Continental ExtremeContact DWS06 Plus",
        description: "Ultra High Performance All-Season Tire",
        price: "189.99",
        discountedPrice: "169.99",
        imageUrl: "https://pixabay.com/get/ge13e1bf75e0a5095ea17e2057e32a65c86b17b63ecdcced9b23cd3a48d46aa5f0cf5a5d14ac8ed2b1a17dca0e3e22d6d8693b38c4673a2cd574aca825f47e89b_1280.jpg",
        size: "235/45R18",
        type: "performance",
        brand: "Continental",
        vendorId: 3,
        isFeatured: true,
        stock: 30,
        rating: 4.7,
        reviewCount: 178,
        hasPromo: true,
        promoText: "SAVE $20",
        tags: ["performance", "all-season", "ultra-high-performance"]
      },
      {
        name: "Goodyear Wrangler TrailRunner AT",
        description: "All-Terrain Light Truck/SUV Tire",
        price: "169.99",
        imageUrl: "https://pixabay.com/get/g8e5b3d5eb89c8546c5a17e8fb7ad72d5ec9a7dba82df90f0af1254f48d9cba2b36d626b5cdecf0e8b91a2d60bac6d9d6a37e72e4c3c9a59fe90cd18cd9dff22a_1280.jpg",
        size: "265/70R17",
        type: "all-terrain",
        brand: "Goodyear",
        vendorId: 2,
        isFeatured: true,
        stock: 25,
        rating: 4.3,
        reviewCount: 142,
        tags: ["all-terrain", "truck", "suv", "off-road"]
      },
      {
        name: "Bridgestone Potenza RE980AS",
        description: "Ultra High Performance All-Season Tire",
        price: "209.99",
        imageUrl: "https://pixabay.com/get/g9b2b88ab44e78ae55fd97fc4b7f12e85a9fdf0cfcc5a348cbb1ecb7fee89e74d3f6c2ba18e00b18a4e3fafb9ff68d0e4d2a9bda2fb0a5aa5de4b8bf61c2f5d95_1280.jpg",
        size: "245/40R19",
        type: "performance",
        brand: "Bridgestone",
        vendorId: 3,
        isFeatured: true,
        stock: 20,
        rating: 4.6,
        reviewCount: 125,
        tags: ["performance", "all-season", "sporty"]
      },
      {
        name: "Falken Wildpeak A/T Trail",
        description: "All-Terrain CUV Tire",
        price: "159.99",
        discountedPrice: "139.99",
        imageUrl: "https://pixabay.com/get/g3ef7f8eb51c5cc0bff11e87d74b1cfe7f8dfc7fde03c99a151e9bbed5e97a5b61fd3c4eeb91577c0f2adf9b45ae35ad38cad44d2c67c1ea2abac8ad9beea3cbe_1280.jpg",
        size: "235/65R17",
        type: "all-terrain",
        brand: "Falken",
        vendorId: 2,
        isFeatured: true,
        stock: 35,
        rating: 4.4,
        reviewCount: 98,
        hasPromo: true,
        promoText: "BEST VALUE",
        tags: ["cuv", "crossover", "all-terrain", "light-off-road"]
      },
      {
        name: "Yokohama Geolandar X-AT",
        description: "Extreme All-Terrain Tire",
        price: "249.99",
        imageUrl: "https://pixabay.com/get/g9c5a07c63a8c5fbffa76d6fc43b4702c40bb2b4de0c0ca3a19bffc89a5a9e6fe1bfc8fa03d3c45c4e7fe3c5dbee3c8af7cd3f73580cc3c2df7e60d8d12c953f4_1280.jpg",
        size: "285/70R17",
        type: "all-terrain",
        brand: "Yokohama",
        vendorId: 2,
        isFeatured: true,
        stock: 15,
        rating: 4.7,
        reviewCount: 85,
        isNewArrival: true,
        tags: ["extreme-terrain", "off-road", "truck", "mud"]
      },
      {
        name: "Pirelli Scorpion All Terrain Plus",
        description: "All-Terrain SUV/Light Truck Tire",
        price: "219.99",
        discountedPrice: "199.99",
        imageUrl: "https://pixabay.com/get/g53ed0b4b05a3eb9da39e4ca4bba6eb9a0bb12ec2c41c5cb4a5b3473c53a16ae53a0be1e72c72e09f30efbbd1ce5c1b65da8c64eb7654f4a1ada2bb0fbc9c38dd_1280.jpg",
        size: "265/65R18",
        type: "all-terrain",
        brand: "Pirelli",
        vendorId: 2,
        isFeatured: true,
        stock: 28,
        rating: 4.5,
        reviewCount: 112,
        hasPromo: true,
        promoText: "SAVE $20",
        tags: ["all-terrain", "suv", "truck", "all-weather"]
      },
      {
        name: "Dunlop Winter Maxx 2",
        description: "Winter Performance Tire",
        price: "149.99",
        imageUrl: "https://pixabay.com/get/g66da2d03d5e48af8c42c3a9af41c5e28b8cc2825cd1feb9b6efd3da05d2ae22d03d64a9d0b16a6f66ad6dab97a0d9bcc12eccc992f27e55ee11f8e6ffa31e649_1280.jpg",
        size: "205/55R16",
        type: "winter",
        brand: "Dunlop",
        vendorId: 1,
        isFeatured: true,
        stock: 40,
        rating: 4.6,
        reviewCount: 95,
        tags: ["winter", "snow", "ice", "passenger"]
      },
      {
        name: "Hankook Ventus V12 evo2",
        description: "Summer Ultra High Performance Tire",
        price: "179.99",
        discountedPrice: "159.99",
        imageUrl: "https://pixabay.com/get/g2aed27d1d4d27c53b31d865f097e7c9a5f92d5398df16ac4dd5f18dbb1f2f8d7edc2c26a9c67fb41e1b9c8e7dbbf29bbabb91cb03b7b9d17ec15d6c33fa93e7d_1280.jpg",
        size: "225/45R18",
        type: "performance",
        brand: "Hankook",
        vendorId: 3,
        isFeatured: true,
        stock: 25,
        rating: 4.4,
        reviewCount: 87,
        hasPromo: true,
        promoText: "LIMITED TIME",
        tags: ["summer", "sports", "performance", "grip"]
      },
      {
        name: "Toyo Open Country A/T III",
        description: "All-Terrain Light Truck/SUV Tire",
        price: "189.99",
        imageUrl: "https://pixabay.com/get/gc0e8bdcb9ad9befdba0c1afb9f0057c78f98cccb49f823fe18d08b7d02e6a1ba00d2a6ed72c4bca4fa3ff71c02d5efb72efe99eb97c07f9fd0a9d55de82aeb47_1280.jpg",
        size: "275/60R20",
        type: "all-terrain",
        brand: "Toyo",
        vendorId: 2,
        isFeatured: true,
        stock: 22,
        rating: 4.8,
        reviewCount: 115,
        isNewArrival: true,
        tags: ["all-terrain", "rugged", "truck", "suv"]
      },
      // Adding more tires
      {
        name: "Firestone Winterforce 2",
        description: "Winter Studdable Passenger Tire",
        price: "129.99",
        imageUrl: "https://pixabay.com/get/g59b2c0f3ffbd2f2323e10c8e8a66a88b6d02ad01c84a9f74d20ae21b86c6b42e02e74c7387f99c24f4ca2d3e8e5fa92c6d4ddac13a36ae43e9b6bae889c6bb91_1280.jpg",
        size: "195/65R15",
        type: "winter",
        brand: "Firestone",
        vendorId: 1,
        isFeatured: true,
        stock: 30,
        rating: 4.3,
        reviewCount: 76,
        hasPromo: true,
        promoText: "WINTER READY",
        tags: ["winter", "studdable", "snow", "passenger"]
      },
      {
        name: "Cooper Discoverer AT3 4S",
        description: "All-Terrain All-Season Truck & SUV Tire",
        price: "179.99",
        discountedPrice: "159.99",
        imageUrl: "https://pixabay.com/get/g4f6c3e25a8ad0f1b50c2af747ed9ea3d7a7b72d17aea40fa8f9a0b03ed0c6e22ec4e87d6d6d5b8d15b1e8651e1b4780c10c8d1d7ed21eb4a6cebb8a8dd30c057_1280.jpg",
        size: "265/70R17",
        type: "all-terrain",
        brand: "Cooper",
        vendorId: 2,
        isFeatured: true,
        stock: 25,
        rating: 4.6,
        reviewCount: 118,
        hasPromo: true,
        promoText: "TOP RATED",
        tags: ["all-terrain", "all-season", "truck", "suv"]
      },
      {
        name: "General Grabber APT",
        description: "All-Purpose Terrain SUV & Light Truck Tire",
        price: "159.99",
        imageUrl: "https://pixabay.com/get/g8c29db65f4e4f85ce79ced8a9adb1a28b6c0f0d66d1b4a1f44fc2b9e9b6d08c7c9c72dc53e9c7bcd2a9dac389d1ef31ec8053b3fa1a34db4c4bb72f7b7aa4d90_1280.jpg",
        size: "245/65R17",
        type: "all-terrain",
        brand: "General",
        vendorId: 2,
        isFeatured: true,
        stock: 32,
        rating: 4.4,
        reviewCount: 89,
        tags: ["all-purpose", "terrain", "suv", "light-truck"]
      },
      {
        name: "Nitto Ridge Grappler",
        description: "Hybrid Terrain Light Truck Tire",
        price: "289.99",
        imageUrl: "https://pixabay.com/get/ge0f40de8a583eb8ada22a87e7e69fa81b4a0c72ddb33c7d92a89e95c4fe4a60da27a3a82172267e30b10dc5b55e6dd73358d8d20566c3fdacff3db8e5e5f2fb0_1280.jpg",
        size: "305/55R20",
        type: "all-terrain",
        brand: "Nitto",
        vendorId: 2,
        isFeatured: true,
        stock: 18,
        rating: 4.8,
        reviewCount: 156,
        isNewArrival: true,
        tags: ["hybrid-terrain", "off-road", "truck", "premium"]
      },
      {
        name: "Michelin Pilot Sport 4S",
        description: "Max Performance Summer Tire",
        price: "299.99",
        imageUrl: "https://pixabay.com/get/g01e1ba5b9a0fe7b32fedd520d81f7d4659b3e2f70f53de5b47f8b12cd42b1d5acffa72d6b08d0dd6b35c6e4c7e1c48b37ab5c8d5b7a051defc32c5c03aedddc6_1280.jpg",
        size: "255/35R19",
        type: "performance",
        brand: "Michelin",
        vendorId: 3,
        isFeatured: true,
        stock: 15,
        rating: 4.9,
        reviewCount: 221,
        hasPromo: true,
        promoText: "PREMIUM CHOICE",
        tags: ["max-performance", "summer", "sports", "high-end"]
      },
      {
        name: "BFGoodrich g-Force COMP-2 A/S PLUS",
        description: "Ultra High Performance All-Season Tire",
        price: "169.99",
        discountedPrice: "149.99",
        imageUrl: "https://pixabay.com/get/g60ca2ae0e639bbd8c7a92e1e1c67d70e57fbe4b47fca566caada84eefcdcadb25d456d22aa55a59aac50adff56d09c30af51edab4d0dc73a4fe6a1e5d8bf7352_1280.jpg",
        size: "225/45R17",
        type: "performance",
        brand: "BFGoodrich",
        vendorId: 3,
        isFeatured: true,
        stock: 28,
        rating: 4.6,
        reviewCount: 103,
        hasPromo: true,
        promoText: "SAVE $20",
        tags: ["ultra-high-performance", "all-season", "grip", "handling"]
      },
      {
        name: "Kumho Road Venture MT71",
        description: "Maximum Traction Off-Road Tire",
        price: "219.99",
        imageUrl: "https://pixabay.com/get/g8a2dc3c9fedc2f27e9ea452a72ed8d5d8f8cd84a9b30a1f01cbcfad9c19a6cd9d53c4444aa2b2a5d16a5b5b8ef1adb7a9cc1d13d0c50f57d8b8bcbb0cb0ed3d1_1280.jpg",
        size: "295/70R17",
        type: "off-road",
        brand: "Kumho",
        vendorId: 2,
        isFeatured: true,
        stock: 12,
        rating: 4.5,
        reviewCount: 68,
        isNewArrival: true,
        tags: ["mud-terrain", "off-road", "maximum-traction", "rock-climbing"]
      },
      {
        name: "Continental TrueContact Tour",
        description: "Grand Touring All-Season Tire",
        price: "139.99",
        discountedPrice: "119.99",
        imageUrl: "https://pixabay.com/get/g7e95c67a5c1b02e2a0fcf2b80c0fa3ab5c5eb0f2baed7f1db347eee85df9c9f7f7c45a2ea2fbf9d24a4f12f4b621bda21ba4ecbedbd4bf2ed7eab12b2e8f07c0_1280.jpg",
        size: "205/65R16",
        type: "all-season",
        brand: "Continental",
        vendorId: 1,
        isFeatured: true,
        stock: 45,
        rating: 4.7,
        reviewCount: 194,
        hasPromo: true,
        promoText: "FUEL EFFICIENT",
        tags: ["touring", "all-season", "fuel-efficient", "comfortable"]
      },
      {
        name: "Goodyear Eagle F1 Asymmetric 6",
        description: "Ultra High Performance Summer Tire",
        price: "249.99",
        imageUrl: "https://pixabay.com/get/g3a3e92fed6cd7a8cba38d50aa1ea6bf72b44c8c7b9f99c48da14e1ddccbcb4dfcb46d3686a8c7a7654be3e0f1abd4a452a1a3b7d1f44c0abb73dbcd64b90f6ad_1280.jpg",
        size: "245/40R19",
        type: "performance",
        brand: "Goodyear",
        vendorId: 3,
        isFeatured: true,
        stock: 22,
        rating: 4.8,
        reviewCount: 112,
        isNewArrival: true,
        tags: ["ultra-high-performance", "summer", "sports", "wet-grip"]
      },
      {
        name: "Firestone Firehawk Indy 500",
        description: "Ultra High Performance Summer Tire",
        price: "169.99",
        discountedPrice: "149.99",
        imageUrl: "https://pixabay.com/get/gec7a7a2c5e0aedb9dfdf89ab5da5b0e5a5c64ca28f60dae4be5e16a5647ff736ea06923fea4c13e8f4e48fc23ea3c37b17af7a6abc29b4ad40bcd8f1a27b7ebd_1280.jpg",
        size: "225/40R18",
        type: "performance",
        brand: "Firestone",
        vendorId: 3,
        isFeatured: true,
        stock: 26,
        rating: 4.5,
        reviewCount: 135,
        hasPromo: true,
        promoText: "SAVE $20",
        tags: ["ultra-high-performance", "summer", "street", "racing"]
      }
    ];
    
    // Add all tires to the database
    console.log(`Adding ${tires.length} base tires and ${additionalTires.length} additional tires...`);
    const allTires = [...tires, ...additionalTires];
    
    // Clear any existing tires before adding
    this.tires.clear();
    this.tireId = 1;
    
    // Add each tire with proper type conversion
    for (const tire of allTires) {
      this.createTire({
        ...tire,
        rating: String(tire.rating), // Convert rating to string
        isFeatured: tire.isFeatured === undefined ? true : tire.isFeatured,
      });
    }

    // Seed promotions
    const promotions = [
      {
        title: "Winter Tires",
        description: "Designed for optimal performance in snow, ice, and cold temperatures.",
        imageUrl: "https://pixabay.com/get/g18a3dd74cc0a77cfde5b08c7d7de50d30a69e5d1e0ee2bbfee47ba7f0608bc7c30c8df5bd06cf73fb0aaa27ff2d40c10f7e9c19e3efad9daa17bc4a4ca5ed1c2_1280.jpg",
        type: "winter",
        linkUrl: "/category/winter-tires",
        isActive: true
      },
      {
        title: "All-Season Tires",
        description: "Versatile performance across most weather conditions throughout the year.",
        imageUrl: "https://pixabay.com/get/gad48d2e242773e3ba5b3f4867952736138f07e0d548cb8b87f139f47a8d020db8718be8015a35ca26e6262a9d6599fb9dbca5008a82aed4baf9d71dd352a402f_1280.png",
        type: "all-season",
        linkUrl: "/category/all-season-tires",
        isActive: true
      },
      {
        title: "Summer Tires",
        description: "Maximum grip and handling in warm, dry and wet conditions.",
        imageUrl: "https://pixabay.com/get/ga9de5399b3b34a1e5b77a4afd43c4a9b5af7ffe69d5c02d6a9f1c4a9d60e59e4d90ee9bb60f9953353fb0f2835c6da4c9064657eabecf4ea3c4ad6eabaeab254_1280.jpg",
        type: "summer",
        linkUrl: "/category/summer-tires",
        isActive: true
      },
      {
        title: "All-Terrain Tires",
        description: "Balanced on-road comfort with off-road capability for trucks and SUVs.",
        imageUrl: "https://pixabay.com/get/ga239456d73d5f14f0a4728cb39f8584fcf52e3dc16d4c942a4e046c2e9d081f9f31ee03a269f18206891a22a4b344ae7b22a44be58e3c90e8adaa6ff73ccde55_1280.jpg",
        type: "all-terrain",
        linkUrl: "/category/all-terrain-tires",
        isActive: true
      }
    ];
    
    promotions.forEach(promotion => this.createPromotion(promotion));

    // Seed services
    const services = [
      {
        name: "Tire Mounting",
        description: "Professional mounting of tires to your vehicle's wheels.",
        price: "15.99",
        imageUrl: "https://pixabay.com/get/gfdb2e29a22df50f65abb28f7e9b59f7e9d42d24b1aca8c4cc4e9c18d8b7df1b9eb67fd09dae57f9a70e6e18c5e13ddf1c36a51f8bf34d65cad9da3a40889efd9_1280.jpg",
        type: "mounting"
      },
      {
        name: "Wheel Balancing",
        description: "Ensure smooth rides with properly balanced wheels.",
        price: "12.99",
        imageUrl: "https://pixabay.com/get/gd2e7445ed2f7c37bd938805208b64a0ca3484db308eea8d162c389fc6ddef87bdde0a164f0c6f825f9ccf800df446b214971946db01131ea3356e1cadd1d9b25_1280.jpg",
        type: "balancing"
      },
      {
        name: "Wheel Alignment",
        description: "Proper alignment for better handling and tire longevity.",
        price: "89.99",
        imageUrl: "https://pixabay.com/get/g2e3c5f4aad2a88f0d8f47f7af30b52d5cebfd3d2ca8ef4b9bab0a3a9b9f70cce7dfa7577398de74a0e7dfea066b1db44b01e42d8f5b0cd79dcf22c1ea8b4e682_1280.jpg",
        type: "alignment"
      },
      {
        name: "Tire Rotation",
        description: "Extend your tires' life with regular rotation service.",
        price: "29.99",
        imageUrl: "https://pixabay.com/get/g323ee8f56f97115cd08d01941565b147004bf4e5dd0a918a67bc7ce04212d64728eec407fd55beb3e98615161581341bb6dead6c9992c4a7093eba78c90c2c67_1280.jpg",
        type: "rotation"
      }
    ];
    
    services.forEach(service => this.createService(service));

    // Seed reviews
    const reviews = [
      {
        tireId: 1,
        rating: 5,
        comment: "My Michelin Defender tires have been exceptional in all weather conditions. The grip on wet roads is impressive and they're surprisingly quiet. Worth every penny for the peace of mind.",
        userName: "John D.",
        userVehicle: "Honda CR-V Owner"
      },
      {
        tireId: 2,
        rating: 4,
        comment: "The Bridgestone Blizzak tires transformed my winter driving experience. No more slipping on icy roads! They were easy to order and the installation service was professional and quick.",
        userName: "Sarah M.",
        userVehicle: "Toyota Camry Owner"
      },
      {
        tireId: 4,
        rating: 5,
        comment: "Finding tires for my F-150 used to be a hassle until I discovered TireHub. The BF Goodrich All-Terrains I bought have been incredible on my camping trips. Great traction off-road and comfortable on highways.",
        userName: "Mike R.",
        userVehicle: "Ford F-150 Owner"
      }
    ];
    
    reviews.forEach(review => this.createReview(review));

    // Seed vehicles
    const vehicles = [
      { year: 2023, make: "Toyota", model: "Camry", trim: "LE", tireSize: "215/55R17" },
      { year: 2023, make: "Toyota", model: "Camry", trim: "SE", tireSize: "215/55R17" },
      { year: 2023, make: "Toyota", model: "Camry", trim: "XLE", tireSize: "235/45R18" },
      { year: 2023, make: "Honda", model: "Accord", trim: "LX", tireSize: "225/50R17" },
      { year: 2023, make: "Honda", model: "Accord", trim: "Sport", tireSize: "235/40R19" },
      { year: 2023, make: "Ford", model: "F-150", trim: "XLT", tireSize: "275/65R18" },
      { year: 2023, make: "Ford", model: "F-150", trim: "Lariat", tireSize: "275/55R20" },
      { year: 2023, make: "Chevrolet", model: "Silverado", trim: "LT", tireSize: "275/60R20" }
    ];
    
    vehicles.forEach(vehicle => this.createVehicle(vehicle));
    
    // Using a pre-computed password hash for test user
    // This is a properly pre-hashed "password123" using our scrypt algorithm with 64-byte output
    const testUser = {
      username: "testuser",
      email: "test@example.com",
      password: "58f60c4953e0a52f941c17d13f2172ecd9316156aa0c0df2d801b5139516938676903e053c20441ae1d49cfd8f293826aebcf76d17753719f2556c01c1448344.a6570ca38bdbdfa1fab850359308c470", // pre-hashed "password123"
      firstName: "Test",
      lastName: "User",
      zipCode: "12345",
      phone: "555-123-4567",
      address: "123 Test St",
      city: "Testville",
      state: "TS"
    };
    
    const user = this.createUser(testUser);
    
    // Seed sample orders for the test user
    const sampleOrders = [
      {
        sessionId: "test-session-1",
        totalAmount: "439.97",
        status: "delivered",
        userId: 1, // The first user will have ID 1
        customerEmail: "test@example.com",
        customerName: "Test User",
        shippingAddress: "123 Test St, Testville, TS 12345",
        paymentIntentId: "pi_mock_1234567890"
      },
      {
        sessionId: "test-session-2",
        totalAmount: "289.98",
        status: "shipped",
        userId: 1,
        customerEmail: "test@example.com",
        customerName: "Test User",
        shippingAddress: "123 Test St, Testville, TS 12345",
        paymentIntentId: "pi_mock_0987654321"
      },
      {
        sessionId: "test-session-3",
        totalAmount: "159.99",
        status: "processing",
        userId: 1,
        customerEmail: "test@example.com",
        customerName: "Test User",
        shippingAddress: "123 Test St, Testville, TS 12345",
        paymentIntentId: "pi_mock_2468135790"
      }
    ];
    
    sampleOrders.forEach(order => this.createOrder(order));
  }

  // Tire methods
  async getTires(): Promise<Tire[]> {
    return Array.from(this.tires.values());
  }

  async getTireById(id: number): Promise<Tire | undefined> {
    return this.tires.get(id);
  }

  async getTiresByType(type: string): Promise<Tire[]> {
    return Array.from(this.tires.values()).filter(tire => tire.type === type);
  }

  async getTiresByBrand(brand: string): Promise<Tire[]> {
    return Array.from(this.tires.values()).filter(tire => tire.brand === brand);
  }

  async getTiresByVendor(vendorId: number): Promise<Tire[]> {
    return Array.from(this.tires.values()).filter(tire => tire.vendorId === vendorId);
  }

  async getFeaturedTires(): Promise<Tire[]> {
    return Array.from(this.tires.values()).filter(tire => tire.isFeatured);
  }

  async searchTires(query: string): Promise<Tire[]> {
    // Normalize the search query
    const lowerQuery = query.toLowerCase().trim();
    
    // Search across all fields
    return Array.from(this.tires.values()).filter(tire => 
      tire.name.toLowerCase().includes(lowerQuery) ||
      tire.description.toLowerCase().includes(lowerQuery) ||
      tire.brand.toLowerCase().includes(lowerQuery) ||
      tire.type.toLowerCase().includes(lowerQuery) ||
      tire.size.toLowerCase().includes(lowerQuery) ||
      (tire.tags && tire.tags.some(tag => tag.toLowerCase().includes(lowerQuery)))
    );
  }

  async createTire(tire: InsertTire): Promise<Tire> {
    const id = this.tireId++;
    // Convert numeric rating to string to match schema requirement
    const ratingStr = tire.rating !== undefined ? String(tire.rating) : "0";
    
    // Create new tire with correct types for schema
    const newTire: Tire = { 
      ...tire, 
      id,
      createdAt: new Date(),
      rating: ratingStr
    };
    
    this.tires.set(id, newTire);
    return newTire;
  }

  // Vendor methods
  async getVendors(): Promise<Vendor[]> {
    return Array.from(this.vendors.values());
  }

  async getVendorById(id: number): Promise<Vendor | undefined> {
    return this.vendors.get(id);
  }

  async getFeaturedVendors(): Promise<Vendor[]> {
    return Array.from(this.vendors.values()).filter(vendor => vendor.isFeatured);
  }

  async createVendor(vendor: InsertVendor): Promise<Vendor> {
    const id = this.vendorId++;
    const newVendor: Vendor = { ...vendor, id };
    this.vendors.set(id, newVendor);
    return newVendor;
  }

  // Brand methods
  async getBrands(): Promise<Brand[]> {
    return Array.from(this.brands.values());
  }

  async getBrandById(id: number): Promise<Brand | undefined> {
    return this.brands.get(id);
  }

  async getFeaturedBrands(): Promise<Brand[]> {
    return Array.from(this.brands.values()).filter(brand => brand.isFeatured);
  }

  async createBrand(brand: InsertBrand): Promise<Brand> {
    const id = this.brandId++;
    const newBrand: Brand = { ...brand, id };
    this.brands.set(id, newBrand);
    return newBrand;
  }

  // Review methods
  async getReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values());
  }

  async getReviewById(id: number): Promise<Review | undefined> {
    return this.reviews.get(id);
  }

  async getReviewsByTireId(tireId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(review => review.tireId === tireId);
  }

  async getReviewsByVendorId(vendorId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(review => review.vendorId === vendorId);
  }
  
  async getReviewsByUserId(userId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(review => review.userId === userId);
  }

  async createReview(review: InsertReview): Promise<Review> {
    const id = this.reviewId++;
    const newReview: Review = { ...review, id, createdAt: new Date() };
    this.reviews.set(id, newReview);
    return newReview;
  }
  
  async updateReview(id: number, reviewData: Partial<InsertReview>): Promise<Review | undefined> {
    const review = this.reviews.get(id);
    
    if (!review) {
      return undefined;
    }
    
    const updatedReview: Review = { ...review, ...reviewData };
    this.reviews.set(id, updatedReview);
    
    return updatedReview;
  }
  
  async deleteReview(id: number): Promise<boolean> {
    return this.reviews.delete(id);
  }
  
  // Admin review methods
  async getPendingReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.isApproved === false);
  }
  
  async updateReviewModeration(id: number, update: { isApproved: boolean, moderationNotes: string | null }): Promise<Review | undefined> {
    const review = await this.getReviewById(id);
    if (!review) {
      return undefined;
    }
    
    const updatedReview = {
      ...review,
      isApproved: update.isApproved,
      moderationNotes: update.moderationNotes
    };
    
    this.reviews.set(id, updatedReview);
    return updatedReview;
  }

  // Cart Item methods
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
  }

  async addCartItem(cartItem: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemId++;
    // Ensure quantity is set to at least 1
    const quantity = cartItem.quantity || 1;
    const newCartItem: CartItem = { 
      ...cartItem, 
      id, 
      quantity, 
      createdAt: new Date() 
    };
    this.cartItems.set(id, newCartItem);
    return newCartItem;
  }

  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem: CartItem = { ...cartItem, quantity };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }

  async removeCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const cartItems = Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
    cartItems.forEach(item => this.cartItems.delete(item.id));
    return true;
  }

  // Service methods
  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async getServiceById(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }

  async createService(service: InsertService): Promise<Service> {
    const id = this.serviceId++;
    const newService: Service = { ...service, id };
    this.services.set(id, newService);
    return newService;
  }

  // Promotion methods
  async getPromotions(): Promise<Promotion[]> {
    return Array.from(this.promotions.values());
  }

  async getActivePromotions(): Promise<Promotion[]> {
    return Array.from(this.promotions.values()).filter(promotion => promotion.isActive);
  }

  async createPromotion(promotion: InsertPromotion): Promise<Promotion> {
    const id = this.promotionId++;
    const newPromotion: Promotion = { ...promotion, id };
    this.promotions.set(id, newPromotion);
    return newPromotion;
  }

  // Order methods
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }
  
  // Admin method to get all orders
  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersBySessionId(sessionId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.sessionId === sessionId);
  }
  
  async getOrdersByUserId(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.userId === userId);
  }
  
  // Check if a user has purchased a specific tire
  async hasUserPurchasedTire(userId: number, tireId: number): Promise<boolean> {
    // Get all orders for the user
    const userOrders = await this.getOrdersByUserId(userId);
    
    // Check each order for the tire
    for (const order of userOrders) {
      // Cast items as any since it might not be in the type but is used in the application
      const items = (order as any).items || [];
      
      // Check if any item in the order matches the tireId
      if (items.some((item: any) => item.tireId === tireId)) {
        return true;
      }
    }
    
    return false;
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    const newOrder: Order = { ...order, id, createdAt: new Date() };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder: Order = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
  
  // Admin method to update order shipping details
  async updateOrderShipping(id: number, update: {
    status?: string;
    trackingNumber?: string | null;
    carrier?: string | null;
    estimatedDeliveryDate?: Date | null;
    shippingNotes?: string | null;
    lastUpdated: Date;
  }): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder: Order = { 
      ...order,
      status: update.status || order.status,
      trackingNumber: update.trackingNumber !== undefined ? update.trackingNumber : order.trackingNumber,
      carrier: update.carrier !== undefined ? update.carrier : order.carrier,
      estimatedDeliveryDate: update.estimatedDeliveryDate !== undefined ? 
        update.estimatedDeliveryDate : order.estimatedDeliveryDate,
      shippingNotes: update.shippingNotes !== undefined ? update.shippingNotes : order.shippingNotes,
      lastUpdated: update.lastUpdated
    };
    
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Vehicle methods
  async getVehicles(): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values());
  }

  async getVehiclesByParams(year: string, make: string, model: string): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values()).filter(vehicle => 
      vehicle.year.toString() === year &&
      vehicle.make.toLowerCase() === make.toLowerCase() &&
      vehicle.model.toLowerCase() === model.toLowerCase()
    );
  }

  async createVehicle(vehicle: InsertVehicle): Promise<Vehicle> {
    const id = this.vehicleId++;
    const newVehicle: Vehicle = { ...vehicle, id };
    this.vehicles.set(id, newVehicle);
    return newVehicle;
  }

  // User methods
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUserById(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }
  
  async getUserByResetToken(token: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => 
      user.resetToken === token && 
      user.resetTokenExpiry && 
      new Date(user.resetTokenExpiry) > new Date()
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { 
      ...user, 
      id,
      resetToken: null,
      resetTokenExpiry: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) {
      return undefined;
    }
    
    const updatedUser: User = { 
      ...existingUser, 
      ...userData,
      updatedAt: new Date() 
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    const exists = this.users.has(id);
    if (!exists) {
      return false;
    }
    
    // Delete user from the users map
    this.users.delete(id);
    
    // Also clean up any related data for this user (reviews, orders, wishlist, cart)
    // This ensures we don't have orphaned data pointing to a deleted user
    
    // Delete user's cart items
    const cartItems = Array.from(this.cartItems.values())
      .filter(item => item.userId === id);
    cartItems.forEach(item => this.cartItems.delete(item.id));
    
    // Delete user's reviews
    const reviews = Array.from(this.reviews.values())
      .filter(review => review.userId === id);
    reviews.forEach(review => this.reviews.delete(review.id));
    
    // Delete user's wishlist items
    const wishlistItems = Array.from(this.wishlistItems.values())
      .filter(item => item.userId === id);
    wishlistItems.forEach(item => this.wishlistItems.delete(item.id));
    
    // Mark user's orders as "customer account deleted" but keep the order history
    const orders = Array.from(this.orders.values())
      .filter(order => order.userId === id);
    orders.forEach(order => {
      const updatedOrder = {
        ...order,
        customerName: "Account deleted",
        customerEmail: null
      };
      this.orders.set(order.id, updatedOrder);
    });
    
    // Delete user's payment methods
    const paymentMethods = Array.from(this.paymentMethods.values())
      .filter(pm => pm.userId === id);
    paymentMethods.forEach(pm => this.paymentMethods.delete(pm.id));
    
    return true;
  }

  async setResetToken(email: string, token: string, expiryHours: number): Promise<User | undefined> {
    const user = await this.getUserByEmail(email);
    
    if (!user) {
      return undefined;
    }
    
    // Set expiry time - current time plus specified hours
    const expiryDate = new Date();
    expiryDate.setHours(expiryDate.getHours() + expiryHours);
    
    const updatedUser: User = {
      ...user,
      resetToken: token,
      resetTokenExpiry: expiryDate,
      updatedAt: new Date()
    };
    
    this.users.set(user.id, updatedUser);
    
    return updatedUser;
  }

  // Method already defined with improved implementation above
  
  // Payment Methods methods
  async getPaymentMethods(userId: number): Promise<PaymentMethod[]> {
    return Array.from(this.paymentMethods.values())
      .filter(pm => pm.userId === userId);
  }
  
  async getPaymentMethodById(id: number): Promise<PaymentMethod | undefined> {
    return this.paymentMethods.get(id);
  }
  
  async addPaymentMethod(paymentMethod: InsertPaymentMethod): Promise<PaymentMethod> {
    const id = this.paymentMethodId++;
    
    // If this is the first payment method for the user, set it as default
    const userPaymentMethods = await this.getPaymentMethods(paymentMethod.userId);
    const isDefault = userPaymentMethods.length === 0 ? true : paymentMethod.isDefault || false;
    
    // If this new card is default, remove default from other cards
    if (isDefault) {
      for (const pm of userPaymentMethods) {
        if (pm.isDefault) {
          const updatedPm = { ...pm, isDefault: false };
          this.paymentMethods.set(pm.id, updatedPm);
        }
      }
    }
    
    const newPaymentMethod: PaymentMethod = {
      ...paymentMethod,
      id,
      isDefault,
      createdAt: new Date()
    };
    
    this.paymentMethods.set(id, newPaymentMethod);
    return newPaymentMethod;
  }
  
  async updatePaymentMethod(id: number, paymentMethod: Partial<InsertPaymentMethod>): Promise<PaymentMethod | undefined> {
    const existingPaymentMethod = this.paymentMethods.get(id);
    
    if (!existingPaymentMethod) {
      return undefined;
    }
    
    // If we're setting this to default, unset all other payment methods for this user
    if (paymentMethod.isDefault) {
      const userPaymentMethods = await this.getPaymentMethods(existingPaymentMethod.userId);
      for (const pm of userPaymentMethods) {
        if (pm.id !== id && pm.isDefault) {
          const updatedPm = { ...pm, isDefault: false };
          this.paymentMethods.set(pm.id, updatedPm);
        }
      }
    }
    
    const updatedPaymentMethod: PaymentMethod = {
      ...existingPaymentMethod,
      ...paymentMethod
    };
    
    this.paymentMethods.set(id, updatedPaymentMethod);
    return updatedPaymentMethod;
  }
  
  async deletePaymentMethod(id: number): Promise<boolean> {
    const paymentMethod = this.paymentMethods.get(id);
    
    if (!paymentMethod) {
      return false;
    }
    
    // If this was the default payment method and there are others,
    // make another one the default
    if (paymentMethod.isDefault) {
      const userPaymentMethods = await this.getPaymentMethods(paymentMethod.userId);
      
      // Filter out the one being deleted
      const otherMethods = userPaymentMethods.filter(pm => pm.id !== id);
      
      if (otherMethods.length > 0) {
        // Make the first one default
        const newDefault = otherMethods[0];
        const updatedDefault = { ...newDefault, isDefault: true };
        this.paymentMethods.set(newDefault.id, updatedDefault);
      }
    }
    
    return this.paymentMethods.delete(id);
  }
  
  async setDefaultPaymentMethod(id: number, userId: number): Promise<boolean> {
    const paymentMethod = this.paymentMethods.get(id);
    
    if (!paymentMethod || paymentMethod.userId !== userId) {
      return false;
    }
    
    // Unset default for all other payment methods for this user
    const userPaymentMethods = await this.getPaymentMethods(userId);
    for (const pm of userPaymentMethods) {
      if (pm.id !== id) {
        const updatedPm = { ...pm, isDefault: false };
        this.paymentMethods.set(pm.id, updatedPm);
      }
    }
    
    // Set this payment method as default
    const updatedPaymentMethod = { ...paymentMethod, isDefault: true };
    this.paymentMethods.set(id, updatedPaymentMethod);
    
    return true;
  }

  // Wishlist Methods
  async getWishlistItems(userId: number): Promise<(WishlistItem & { tire: Tire })[]> {
    const wishlistItems: (WishlistItem & { tire: Tire })[] = [];
    
    for (const wishlistItem of this.wishlistItems.values()) {
      if (wishlistItem.userId === userId) {
        const tire = await this.getTireById(wishlistItem.tireId);
        if (tire) {
          wishlistItems.push({
            ...wishlistItem,
            tire,
          });
        }
      }
    }
    
    return wishlistItems;
  }
  
  async getWishlistItemById(id: number): Promise<WishlistItem | undefined> {
    return this.wishlistItems.get(id);
  }
  
  async getWishlistItemByUserAndTire(userId: number, tireId: number): Promise<WishlistItem | undefined> {
    for (const wishlistItem of this.wishlistItems.values()) {
      if (wishlistItem.userId === userId && wishlistItem.tireId === tireId) {
        return wishlistItem;
      }
    }
    return undefined;
  }
  
  async addWishlistItem(wishlistItem: InsertWishlistItem): Promise<WishlistItem> {
    // Check if this user already has this tire in their wishlist
    const existingItem = await this.getWishlistItemByUserAndTire(wishlistItem.userId, wishlistItem.tireId);
    if (existingItem) {
      return existingItem;
    }
    
    const id = this.wishlistItemId++;
    const newWishlistItem: WishlistItem = {
      ...wishlistItem,
      id,
      addedAt: new Date(),
    };
    
    this.wishlistItems.set(id, newWishlistItem);
    return newWishlistItem;
  }
  
  async removeWishlistItem(id: number): Promise<boolean> {
    if (!this.wishlistItems.has(id)) {
      return false;
    }
    
    this.wishlistItems.delete(id);
    return true;
  }
  
  async clearWishlist(userId: number): Promise<boolean> {
    const wishlistItemsToRemove: number[] = [];
    
    for (const [id, wishlistItem] of this.wishlistItems.entries()) {
      if (wishlistItem.userId === userId) {
        wishlistItemsToRemove.push(id);
      }
    }
    
    wishlistItemsToRemove.forEach(id => this.wishlistItems.delete(id));
    return true;
  }
}

export const storage = new MemStorage();

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { usePaymentMethods } from '@/hooks/usePaymentMethods';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { FaCcVisa, FaCcMastercard, FaCcAmex, FaCcDiscover, FaCreditCard } from "react-icons/fa";

// Payment method validation schema
const formSchema = z.object({
  cardholderName: z.string().min(2, { message: "Name must be at least 2 characters" }),
  cardNumber: z
    .string()
    .min(13, { message: "Card number must be at least 13 digits" })
    .max(19, { message: "Card number cannot exceed 19 digits" })
    .regex(/^[0-9]+$/, { message: "Card number must contain only digits" }),
  expiryMonth: z
    .string()
    .min(1, { message: "Month is required" })
    .max(2, { message: "Month should be 1-2 digits" })
    .regex(/^(0?[1-9]|1[0-2])$/, { message: "Month must be between 1-12" }),
  expiryYear: z
    .string()
    .min(2, { message: "Year is required" })
    .max(4, { message: "Year should be 2-4 digits" })
    .refine((val) => {
      const year = parseInt(val);
      const currentYear = new Date().getFullYear();
      return year >= currentYear;
    }, { message: "Year must not be in the past" }),
  cvv: z
    .string()
    .min(3, { message: "CVV must be at least 3 digits" })
    .max(4, { message: "CVV cannot exceed 4 digits" })
    .regex(/^[0-9]+$/, { message: "CVV must contain only digits" }),
  isDefault: z.boolean().default(false),
});

type FormValues = z.infer<typeof formSchema>;

interface PaymentMethodFormProps {
  isOpen: boolean;
  onClose: () => void;
}

const PaymentMethodForm = ({ isOpen, onClose }: PaymentMethodFormProps) => {
  const { addPaymentMethodMutation } = usePaymentMethods();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cardType, setCardType] = useState<string | null>(null);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cardholderName: '',
      cardNumber: '',
      expiryMonth: '',
      expiryYear: '',
      cvv: '',
      isDefault: false,
    },
  });
  
  // Detect card type based on the first digits
  const detectCardType = (cardNumber: string) => {
    // Remove spaces and non-digit characters
    const cleanNumber = cardNumber.replace(/\D/g, '');
    
    // Visa: Starts with 4
    if (/^4/.test(cleanNumber)) return 'visa';
    
    // Mastercard: Starts with 51-55 or 2221-2720
    if (/^5[1-5]/.test(cleanNumber) || /^(222[1-9]|22[3-9]|2[3-6]|27[0-1]|2720)/.test(cleanNumber)) return 'mastercard';
    
    // American Express: Starts with 34 or 37
    if (/^3[47]/.test(cleanNumber)) return 'amex';
    
    // Discover: Starts with 6011, 622126-622925, 644-649, or 65
    if (/^(6011|65|64[4-9]|622(12[6-9]|1[3-9]|[2-8]|9[0-1][0-9]|92[0-5]))/.test(cleanNumber)) return 'discover';
    
    // Unknown card type or not enough digits yet
    return null;
  };
  
  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    
    try {
      // Get last four digits of card number
      const lastFourDigits = data.cardNumber.slice(-4);
      
      // Use detected card type or fallback to 'card'
      const detectedCardType = cardType || 'card';
      
      // Add cardType and lastFourDigits to the data for submission
      await addPaymentMethodMutation.mutateAsync({
        ...data,
        cardType: detectedCardType,
        lastFourDigits,
      });
      
      onClose();
      form.reset();
      setCardType(null); // Reset card type for next use
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add Payment Method</DialogTitle>
          <DialogDescription>
            Add a new credit or debit card to your account
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="cardholderName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cardholder Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Smith" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="cardNumber"
              render={({ field }) => {
                // Update card type whenever the card number changes
                useEffect(() => {
                  setCardType(detectCardType(field.value));
                }, [field.value]);
                
                return (
                  <FormItem>
                    <FormLabel>Card Number</FormLabel>
                    <div className="relative">
                      <FormControl>
                        <Input 
                          placeholder="4111 1111 1111 1111" 
                          maxLength={16} 
                          inputMode="numeric" 
                          pattern="[0-9]*"
                          onKeyPress={(e) => {
                            if (!/[0-9]/.test(e.key)) {
                              e.preventDefault();
                            }
                          }}
                          {...field} 
                        />
                      </FormControl>
                      {/* Card logo display */}
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                        {cardType === 'visa' && <FaCcVisa size={24} className="text-blue-600" />}
                        {cardType === 'mastercard' && <FaCcMastercard size={24} className="text-blue-500" />}
                        {cardType === 'amex' && <FaCcAmex size={24} className="text-blue-400" />}
                        {cardType === 'discover' && <FaCcDiscover size={24} className="text-orange-500" />}
                        {!cardType && field.value && <FaCreditCard size={24} />}
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                );
              }}
            />
            
            <div className="grid grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="expiryMonth"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Month</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="MM" 
                        maxLength={2} 
                        inputMode="numeric" 
                        pattern="[0-9]*"
                        onKeyPress={(e) => {
                          if (!/[0-9]/.test(e.key)) {
                            e.preventDefault();
                          }
                        }}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="expiryYear"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Year</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="YYYY" 
                        maxLength={4} 
                        inputMode="numeric" 
                        pattern="[0-9]*"
                        onKeyPress={(e) => {
                          if (!/[0-9]/.test(e.key)) {
                            e.preventDefault();
                          }
                        }}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="cvv"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CVV</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="123" 
                        maxLength={4} 
                        inputMode="numeric" 
                        pattern="[0-9]*"
                        onKeyPress={(e) => {
                          if (!/[0-9]/.test(e.key)) {
                            e.preventDefault();
                          }
                        }}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="isDefault"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <FormLabel>Set as default payment method</FormLabel>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Saving...' : 'Save Card'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentMethodForm;